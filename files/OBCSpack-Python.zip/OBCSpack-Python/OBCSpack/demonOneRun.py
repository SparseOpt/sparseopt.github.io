import numpy as np
from OBCSpack import OBCSpack, PlotRecovery, random1bcs

n  = 1000                      # Signal dimension
m  = int(np.ceil(0.5 * n))     # Number of measurements
s  = int(np.ceil(0.01 * n))    # Sparsity level
nf = 0.05                      # Noisy ratio
r  = 0.02                      # Flipping ratio
k  = int(np.ceil(r * m))

A, b, bo, xo = random1bcs('Ind', m, n, s, r, nf) # or 'Cor'

solver = ['GPSP', 'NM01']
out    = OBCSpack(A, b, s, k, solver[0])

print(f" Time:                  {out['time']:6.3f} sec")
print(f" Absolute error:        {np.linalg.norm(xo - out['sol']) * 100:6.2f} %")
print(f" Signal-to-noise ratio: {-10 * np.log10(np.linalg.norm(xo - out['sol']) **2):6.2f}")
print(f" Hamming distance:      {np.count_nonzero(np.sign(A @ out['sol']) - b) / m:6.3f}")
print(f" Hamming error:         {np.count_nonzero(np.sign(A @ out['sol']) - bo) / m:6.3f}")

PlotRecovery(xo, out['sol'], [700, 0, 600, 250], 1)
