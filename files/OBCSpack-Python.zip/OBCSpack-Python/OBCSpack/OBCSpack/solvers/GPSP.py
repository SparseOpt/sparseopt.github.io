import numpy as np
import scipy.sparse as sp
import time


def GPSP(A, b, s, k, pars=None):
    r"""
    Inputs:------------------------------------------------------------------
        A:    The sensing matrix \in R^{m-by-n},                   (REQUIRED)
        b:    The binary observation \in R^m, b_i\in{-1,1}         (REQUIRED)
        s:    Sparsity level of x, an integer \in[1,n]             (REQUIRED)
        k:    Upper bound of sign flips of sign(A*x + noise)       (REQUIRED)
              An integer in [0,m], e.g., k = int(np.ceil(0.01 * m))
        pars: Parameters are all optional                          (OPTIONAL)
              pars['eps']   -- The parameter in the model      (default,1e-4)
              pars['eta']   -- The penalty parameter      (default,.01/ln(n))
              pars['acc']   -- Acceleration is used if acc=1      (default,0)
              pars['big']   -- Start with a bigger s if big=1     (default,1)
              pars['maxit'] -- Maximum number of iterations     (default,1e3)
              pars['tol']   -- Tolerance of halting condition  (default,1e-8)
    Outputs:-----------------------------------------------------------------
        out['sol']  : The sparse solution with respect to x in \R^n
        out['soly'] : The solution with respect to y in \R^m
        out['time'] : CPU time
        out['iter'] : Number of iterations
        out['obj']  : Objective function value at (out['sol'], out['soly'])
    -------------------------------------------------------------------------
    This code is written by Shenglong Zhou
    It was programmed based on the algorithm proposed in

    Shenglong Zhou, Ziyan Luo, Naihua Xiu, Geoffrey Ye Li, Computing one-bit
    compressed sensing via double sparsity constrained optimization,
    IEEE Transactions on Signal Processing, vol. 70, pp. 1593-1608, 2022.

    Send your comments and suggestions to <<< slzhou2021@163.com >>>
    Warning: Accuracy may not be guaranteed !!!!!
    """
    t0 = time.time()
    if pars is None:
        pars = {}

    if len(A.shape) != 2 or len(b.shape) != 1:
        print('Input dimension error!')
        return None
    m, n = A.shape
    if b.shape[0] != m:
        print('Dimensions of A and b do not match!')
        return None

    if n < 10000:
        Ab = b[:, np.newaxis] * A
    else:
        Ab = sp.diags(b) @ A

    def Fnorm(var):
        return np.linalg.norm(var, ord=None) ** 2

    maxit, tol, eta, eps, acc, big, disp = GetParameters(m, n, pars)

    s0 = s
    if big:
        sn = s / n
        if 0.01 < sn < 0.1:
            s = int(np.ceil((1 + min(1, m / n)) * s))
        elif 0.005 <= sn <= 0.01:
            s = int(np.ceil(1.2 * s))

    x     = np.zeros(n)
    y     = np.zeros(m)
    a     = 1.0
    barx  = x.copy()
    bary  = y.copy()

    T     = np.arange(s)
    I     = np.array([], dtype=int)
    Axy   = y - eps
    obj   = Fnorm(Axy)

    HAM   = np.zeros(maxit)
    OBJ   = np.zeros(maxit)
    stop0 = np.zeros(maxit)

    if disp:
        print('\nStart running solver: GPSP')
        print('------------------------------------------')
        print("  Iter           HamDist          CPUTime ")
        print('------------------------------------------')

    for iter in range(maxit):
        alpha = max(1e-3, 10 / n)
        T0   = T.copy()
        I0   = I.copy()
        x0   = x.copy()
        y0   = y.copy()
        obj0 = obj
        v    = Axy.copy()
        u    = Ab.T @ v + eta * barx

        TT   = np.arange(s)
        xT   = None

        for j in range(20):
            x, xT, T = ProS(barx - alpha * u, s)
            y = ProK(bary - alpha * v, k)

            if not np.array_equal(T, TT):
                AT = Ab[:, T]

            Ax  = AT @ xT
            Axy = Ax - eps + y
            obj = Fnorm(Axy) + eta * Fnorm(xT)
            gap = Fnorm(x - barx) + Fnorm(y - bary)

            if obj < obj0 - 1e-6 * gap:
                break
            alpha *= 0.5
            TT = T.copy()

        flag = (len(T) == len(T0) and np.setdiff1d(T, T0).size == 0) or (Fnorm(u) < tol)
        if flag:
            I = np.where(y != 0)[0]
            if len(I) == len(I0):
                flag = (np.setdiff1d(I, I0).size == 0)

        if flag and len(I) < m:
            if iter > 5 and np.min(stop0[iter - 5:iter]) == 1:
                break

            AT0 = AT[y == 0, :] if AT.size > 0 else np.array([])
            if AT0.size > 0:
                # Solve linear system (AT0'*AT0 + eta*I) * tmp1 = eps*sum(AT0, 1)'
                lhs  = AT0.T @ AT0 + eta * np.eye(s)
                rhs  = eps * np.sum(AT0, axis=0).T
                tmp1 = np.linalg.solve(lhs, rhs)

                tmp2 = eps - AT[I, :] @ tmp1 if len(I) > 0 else np.array([])
                Ax1  = AT @ tmp1
                Axy1 = Ax1 - eps
                if len(I) > 0:
                    Axy1[I] += tmp2

                obj1 = Fnorm(Axy1) + eta * Fnorm(tmp1)
                gap  = Fnorm(xT - tmp1) + (Fnorm(y[I] - tmp2) if len(I) > 0 else 0)
                stop0[iter] = 1

                if obj1 <= obj - 1e-6 * gap and (np.sum(tmp2 > 0) <= k if len(tmp2) > 0 else True):
                    x    = np.zeros(n)
                    y    = np.zeros(m)
                    x[T] = tmp1
                    if len(I) > 0 and len(tmp2) > 0:
                        y[I] = tmp2
                    Axy = Axy1
                    obj = obj1

        # Calculate Hamming distance
        Ax          = AT @ x[T] if AT.size > 0 else np.zeros(m)
        sb          = np.sign(-b * Ax)
        sb[sb == 0] = -1
        ham         = 1 - np.sum(sb == b) / m
        HAM[iter]   = ham
        OBJ[iter]   = obj

        if disp:
            print(f'  {iter + 1:3d}          {ham * 100:8.2f}           {time.time() - t0:.3f}')

        # Check stopping conditions
        if iter > 5:
            stop1 = gap < tol
            stop2 = np.std(HAM[iter - 5:iter + 1]) < 1e-6 * np.log(n)
            stop3 = np.std(OBJ[iter - 5:iter + 1]) < 1e-6 * np.log(n)
            stop4 = stop0[iter] * (1 if n < 1e4 else 0) + (1 if n >= 1e4 else 0)
            stop5 = (ham == 1) and (gap < 1e-4)

            if (stop1 and (stop2 or stop3) and stop4) or stop5:
                break

        # Adjust k every 50 iterations
        if (iter + 1) % 50 == 0:
            k = int(np.ceil(k / 2))

        # Acceleration step
        if acc:
            a0       = a
            a        = (1 + np.sqrt(4 * a0 ** 2 + 1)) / 2
            barx_new = x + ((a0 - 1) / a) * (x - x0)
            bary_new = y + ((a0 - 1) / a) * (y - y0)

            if stop0[iter]:
                Ax_bar = AT @ barx_new[T] if AT.size > 0 else np.zeros(m)
            else:
                T_bar  = np.where(barx_new != 0)[0]
                Ax_bar = Ab[:, T_bar] @ barx_new[T_bar] if len(T_bar) > 0 else np.zeros(m)

            barAxy = Ax_bar - eps + bary_new
            barobj = Fnorm(barAxy) + eta * Fnorm(barx_new[np.where(barx_new != 0)[0]] if np.any(barx_new) else 0)

            if barobj > obj:
                barx = x.copy()
                bary = y.copy()
                a    = a0
            else:
                Axy  = barAxy.copy()
                barx = barx_new.copy()
                bary = bary_new.copy()
        else:
            barx = x.copy()
            bary = y.copy()

    if disp:
        print('------------------------------------------')

    if np.sum(x != 0) > s0:
        abs_x = np.abs(x)
        T     = np.argpartition(abs_x, -s0)[-s0:]
        xn    = np.zeros(n)
        xn[T] = x[T]
        x     = xn

    x_norm = np.linalg.norm(x)
    if x_norm > 0:
        x /= x_norm

    out = {
        'sol': x,
        'soly': y,
        'obj': obj,
        'OBJ': OBJ[:iter + 1],
        'time': time.time() - t0,
        'iter': iter + 1  # Iteration count starts from 1
    }

    return out


def GetParameters(m, n, pars):
    """Get algorithm parameters with default values"""
    maxit = pars.get('maxit', 1000)
    tol   = pars.get('tol', 1e-9 * np.sqrt(min(m, n)))
    eta   = pars.get('eta', 1e-4)
    eps   = pars.get('eps', 0.01 * ((1 if n < 1e4 else 0) + (1 / np.log(n) if n >= 1e4 else 0)))
    acc   = pars.get('acc', 0)
    big   = pars.get('big', 1 if m < 2.1 * n else 0)
    disp  = pars.get('disp', 1)
    return maxit, tol, eta, eps, acc, big, disp


def ProS(x, s):
    """Sparse projection: retain the s elements with the largest absolute values in x"""
    if s <= 0:
        return np.zeros_like(x), np.array([]), np.array([], dtype=int)
    # Get indices of the s elements with the largest absolute values (0-based)
    idx     = np.argpartition(np.abs(x), -s)[-s:]
    idx     = np.sort(idx)  # Sort indices
    xT      = x[idx]
    xs      = np.zeros_like(x)
    xs[idx] = xT
    return xs, xT, idx


def ProK(y, k):
    """Project to non-negative part with at most k positive elements retained"""
    if k <= 0:
        y[y > 0] = 0
        return y
    if len(y) == 0:
        return y
    pos_mask = y > 0
    pos_vals = y[pos_mask]
    if len(pos_vals) <= k:
        return y
    threshold   = np.partition(pos_vals, -k)[-k]
    y[pos_mask] = np.where(pos_vals >= threshold, pos_vals, 0)
    return y