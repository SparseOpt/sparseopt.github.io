import numpy as np
import time
from scipy.sparse import diags

def NM01(A, b, sp, pars=None):
    r"""
    Inputs:-------------------------------------------------------------------------
        A   : The sample data in \R^{m-by-n}                              (REQUIRED)
        b   : The binary observation in R^m, b_i in {-1,1}                (REQUIRED)
        sp  : Sparsity of the ture signal if known                        (REQUIRED)
              Set it as [] if unknown
        pars: Parameters are all optional                                 (OPTIONAL)
              pars['x0']      --  The initial point             (default zeros(n,1))
              pars['vareps']  --  Parameter in the objective           (default 0.5)
              pars['q']       --  Parameter in the objective           (default 0.5)
              pars['epsilon'] --  Parameter in the objective          (default 0.15)
              pars['lam']     --  The penalty parameter                  (default 1)
              pars['tau']     --  A useful parameter                     (default 1)
              pars['maxit']   --  Maximum number of iterations        (default 1000)
    Outputs:------------------------------------------------------------------------
        Out['x']     --  The solution
        Out['obj']   --  The objective function value
        Out['time']  --  CPU time
        Out['iter']  --  Number of iterations
    --------------------------------------------------------------------------------
    Written by Shenglong Zhou on 27/06/2021 based on the algorithm proposed in
        Shenglong Zhou, Lili Pan, Naihua Xiu, Houduo Qi, SIOPT,
        Quadratic convergence of smoothing Newton's method for 0/1 loss optimization
        SIAM Journal on Optimization, 31(4): 3184-3211, 2021
    Send your comments and suggestions to <<< slzhou2021@163.com >>>
    WARNING: Accuracy may not be guaranteed!!!!!
    """
    t0 = time.time()
    if pars is None:
        pars = {}

    if len(A.shape) != 2:
        print("Input A must be a 2D array!!!")
        return None
    m, n = A.shape
    negb = -b

    if n < 1e4:
        Ab = negb[:, np.newaxis] * A
    else:
        Ab = diags(negb) @ A
        Ab = Ab.toarray()

    maxit, lam, tau, mu, epsilon, vareps, cgtol, x0, disp = GetParameters(m, n, pars)
    lam = max(lam, (epsilon**2) / (2 * tau))

    grad, hess = def_func(pars)

    Fnorm  = lambda var: np.linalg.norm(var) **2
    z      = np.ones(m)
    ACC    = np.zeros(maxit)
    maxAcc = 0
    maxx   = None

    if np.linalg.norm(x0) == 0:
        Ax = epsilon * np.ones(m)
    else:
        Ax = Ab @ x0 + epsilon
    x   = x0.copy()
    Axz = Ax.copy()
    
    if disp:
        print("\nStart to run the solver: NM01")
        print("------------------------------------------")
        print("  Iter           HamDist          CPUTime ")
        print("------------------------------------------")
    
    for iter_num in range(1, maxit + 1):
        T, empT = Ttau(Axz, Ax, tau, lam)

        g  = grad(x, vareps)
        nT = np.count_nonzero(T) if not empT else 0

        if empT:
            tmp1 = g
            raw  = 0.0
            err  = Fnorm(g) + raw + Fnorm(z)
        else:
            P    = Ab[T, :]
            zT   = z[T]
            tmp1 = g + (zT @ P).reshape(-1)
            tmp2 = Ax[T]
            raw  = Fnorm(tmp2)
            err  = Fnorm(tmp1) + raw + (Fnorm(z) - Fnorm(zT))

        sb          = np.sign(negb * (Ax - epsilon))
        sb[sb == 0] = -1
        acc         = 1 - np.count_nonzero(sb + negb) / m
        x0_current  = x.copy()

        if iter_num > 1 and acc < min(0.5, ACC[iter_num - 2]):
            acc        = 1 - acc
            x0_current = -x
        
        ACC[iter_num - 1] = acc

        if ACC[iter_num - 1] > maxAcc:
            maxAcc = ACC[iter_num - 1]
            maxx   = x0_current

        stop1 = False
        if iter_num > 5:
            stop1 = (acc < ACC[iter_num - 2] and np.min(ACC[iter_num - 3:iter_num - 1]) == 1)
        
        stop2 = False
        if iter_num > 5:
            stop2 = (acc > 0.99995 and raw < 1e-5 * np.sqrt(n) and n > 500)

        if not stop1 and disp:
            print(f"  {iter_num:3d}          {acc*100:8.2f}           {time.time()-t0:.3f}sec")

        if (err < 1e-4 and stop2) or stop1:
            break

        if empT:
            u = -g
            v = -z
        else:
            H = hess(x, vareps)
            
            if nT < n:
                H1  = 1.0 / H
                rhs = tmp2 - P @ (H1 * tmp1)
                
                if nT < 2000:
                    D  = P @ (H1[:, np.newaxis] * P.T)
                    np.fill_diagonal(D, D.diagonal() + mu)
                    vT = np.linalg.solve(D, rhs)
                else:
                    def fx(var):
                        return mu * var + P @ (H1[:, np.newaxis] * (var @ P).T).flatten()
                    vT = my_cg(fx, rhs, cgtol, 30, np.zeros(nT))
                
                v    = -z.copy()
                v[T] = vT
                u    = -H1 * (tmp1 + (vT @ P).flatten())
            else:
                rhs = -mu * tmp1 - (tmp2 @ P).flatten()
                
                if n < 2000:
                    D = P.T @ P
                    np.fill_diagonal(D, D.diagonal() + mu * H)
                    u = np.linalg.solve(D, rhs)
                else:
                    def fx(var):
                        return mu * (H * var) + (P @ var @ P).flatten()
                    u = my_cg(fx, rhs, cgtol, 50, np.zeros(n))
                
                v    = -z.copy()
                v[T] = (tmp2 + P @ u) / mu

        x  += u
        z  += v
        Ax  = Ab @ x + epsilon
        Axz = Ax + tau * z

        vareps = max(1e-5, vareps / 2)
        if iter_num % 5 == 0:
            mu = max(1e-10, mu / 2)
    
    if disp:
        print("------------------------------------------")

    if acc < ACC[0]:
        x = maxx

    if sp is not None and sp != []:
        K     = 6
        abs_x = np.abs(x)
        Ts    = np.argpartition(-abs_x, sp + K - 1)[:sp + K - 1]
        Ts    = Ts[np.argsort(-abs_x[Ts])]
        sx    = abs_x[Ts]
        
        HD    = np.ones(K)
        X     = np.zeros((n, K))
        
        if len(sx) > sp and (sx[sp-1] - sx[sp]) <= 2e-4:
            tem = Ts[sp-1:]
            for i in range(K):
                X[:, i] = np.zeros(n)
                X[Ts[:sp-1], i] = x[Ts[:sp-1]]
                if i < len(tem):
                    X[tem[i], i] = x[tem[i]]
                X[:, i] /= np.linalg.norm(X[:, i])
                pred     = np.sign(A @ X[:, i])
                HD[i]    = np.count_nonzero(pred - b) / m
            
            best_idx = np.argmin(HD)
            sol      = X[:, best_idx]
        else:
            sol         = np.zeros(n)
            top_sp      = Ts[:sp]
            sol[top_sp] = x[top_sp]
            sol        /= np.linalg.norm(sol[top_sp])
    else:
        x_sparse = SparseApprox(x)
        sol      = x_sparse / np.linalg.norm(x_sparse)
    
    return {'sol': sol, 'lam': z, 'time': time.time() - t0, 'iter': iter_num }

def GetParameters(m, n, pars):
    """Get algorithm parameters with defaults"""
    maxit   = 1000
    lam     = 1.0
    tau     = 1.0
    mu      = 0.05
    epsilon = 0.15
    vareps  = 0.5
    tolcg   = 1e-10 * np.sqrt(max(m, n))
    x0      = np.zeros(n)
    disp    = 1
    
    if 'maxit' in pars:
        maxit   = pars['maxit']
    if 'lam' in pars:
        lam     = pars['lam']
    if 'tau' in pars:
        tau     = pars['tau']
    if 'mu' in pars:
        mu      = pars['mu']
    if 'epsilon' in pars:
        epsilon = pars['epsilon']
    if 'vareps' in pars:
        vareps  = pars['vareps']
    if 'x0' in pars:
        x0      = pars['x0']
    if 'disp' in pars:
        disp    = pars['disp']

    return maxit, lam, tau, mu, epsilon, vareps, tolcg, x0, disp

def Ttau(Axz, Ax, tau, lam):
    """Select index set T"""
    tl   = np.sqrt(tau * lam / 2)
    T    = np.where(np.abs(Axz - tl) < tl)[0]
    empT = len(T) == 0
    
    if empT:
        zp = Ax[Ax >= 0]
        T  = np.array([], dtype=int)
        if np.count_nonzero(zp) > 0:
            s = int(np.ceil(0.01 * np.count_nonzero(zp)))
            if s < len(zp):
                sorted_zp = np.sort(zp)[::-1]
                tau_val   = (sorted_zp[s])**2 / (2 * lam)
                tl_new    = np.sqrt(tau_val * lam / 2)
                T         = np.where(np.abs(Ax - tl_new) < tl_new)[0]
        empT = len(T) == 0
    
    return T, empT

def def_func(pars):
    """Define gradient and Hessian functions"""
    q  = pars.get('q', 0.5)
    q1 = q / 2 - 1
    q2 = q / 2 - 2
    q3 = q - 1
    
    def grad(t, e):
        return t * ((t**2 + e)** q1)
    
    def hess(t, e):
        return ((t**2 + e)** q2) * (q3 * t**2 + e)
    
    return grad, hess

def my_cg(fx, b, cgtol, cgit, x):
    """Conjugate gradient method"""
    r  = b.copy()
    e  = np.dot(r, r)
    t  = e
    e0 = 0.0
    
    for i in range(cgit):
        if e < cgtol * t:
            break
        if i == 0:
            p = r.copy()
        else:
            beta = e / e0
            p = r + beta * p
        
        w     = fx(p)
        alpha = e / np.dot(p, w)
        x    += alpha * p
        r    -= alpha * w
        e0    = e
        e     = np.dot(r, r)
    
    return x

def SparseApprox(x):
    """Get sparse approximation of x"""
    n    = len(x)
    xo   = x.copy()
    x_sq = x**2
    T    = np.where(x_sq > 1e-2 / n)[0]
    
    if len(T) == 0:
        return np.zeros(n)

    sx        = x_sq[T]
    idxs      = np.argsort(-sx)
    sorted_sx = sx[idxs]
    
    y  = 0.0
    nx = np.sum(sorted_sx)
    nT = len(sorted_sx)
    t  = np.zeros(nT - 1) if nT > 1 else np.array([])
    
    i  = 0
    while i < nT and y <= 0.5 * nx:
        y += sorted_sx[i]
        if i < nT - 1:
            t[i] = sorted_sx[i] / sorted_sx[i + 1]
        i += 1
    i -= 1
    
    if i < nT - 1 and len(t) > 0:
        max_t = np.max(t[:i])
        j     = np.where(t[:i] == max_t)[0]
        if len(j) > 0:
            i = j[0]
    else:
        i = nT - 1
    
    if i > 0:
        i = min(nT - 1, 10 * (i + 1)) - 1
    else:
        i = nT - 1

    sx           = np.zeros(n)
    selected     = T[idxs[:i + 1]]
    sx[selected] = xo[selected]
    
    return sx
