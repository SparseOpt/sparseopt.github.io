import numpy as np

def random1bcs(type_mat, m, n, s, r=0, nf=0.05, v=0.5):
    r"""
    Generate experimental data for 1-bit compressive sensing (Gaussian sample matrix, sparse signal, observation labels, and flipped labels)

    Inputs:-------------------------------------------------------------------------------
        type_mat: Matrix type, 'Ind' (independent Gaussian) or 'Cor' (correlated Gaussian)
        m: Number of samples (number of rows)
        n: Number of features (number of columns)
        s: Sparsity of the true signal
        r: Label flipping ratio (0~1), default 0
        nf: Noise factor, default 0.05
        v: Correlation coefficient (only used for 'Cor' type), default 0.5

    Outputs:------------------------------------------------------------------------------
        X: m×n sample matrix
        yf: Flipped labels (m-dimensional array)
        y: Original labels (m-dimensional array)
        xopt: True sparse signal (n-dimensional array)
    """

    if type_mat == 'Ind':
        X = np.random.randn(m, n)
    elif type_mat == 'Cor':
        i, j = np.meshgrid(np.arange(n), np.arange(n))
        S    = v ** np.abs(i - j)  # Covariance matrix
        X    = np.random.multivariate_normal(np.zeros(n), S, size=m)
    else:
        raise ValueError("type_mat must be 'Ind' or 'Cor'")

    xopt, T = sparse(n, s)

    noise = nf * np.random.randn(m)
    y     = np.sign(X[:, T] @ xopt[T] + noise)

    y[y == 0] = 1

    yf = flip(y, r)

    print("Done generation of sample data with:")
    print(f"1) Sample size: {m} x {n}")
    print(f"2) Sparsity level: {s}")
    print(f"3) Sign flipping ratio: {r:.2f}")
    print(f"4) Noise ratio: {nf:.2f}")

    return X, yf, y, xopt


def sparse(n, s):
    """Generate a sparse signal (internal helper function)"""
    T = np.random.permutation(n)[:s]  # Randomly select s non-zero positions
    x = np.zeros(n)

    x[T]  = (0.5 + np.random.rand(s)) * np.sign(np.random.randn(s))

    x[T] /= np.linalg.norm(x[T])
    return x, T


def flip(yopt, r):
    """Randomly flip some labels (internal helper function)"""
    yf = yopt.copy()
    m  = len(yopt)
    if r <= 0:
        return yf
    num_flip = int(np.ceil(r * m))
    T        = np.random.permutation(m)[:num_flip]
    yf[T]    = -yf[T]
    return yf