import numpy as np
# for macOS users, you might need the following codes
# import matplotlib
# matplotlib.use("TkAgg")
import matplotlib.pyplot as plt


def PlotRecovery(xo, x, pos, ind):
    """
    xo: Ground-truth signal (NumPy array).
    x: Recovered signal (NumPy array).
    pos: Figure position [left, bottom, width, height] in pixels.
    ind: Boolean flag to display title and legend.
    """
    fig, ax = plt.subplots(figsize=(pos[2] / 100, pos[3] / 100),
                           constrained_layout=True, dpi=100)
    mngr = plt.get_current_fig_manager()
    try:
        if hasattr(mngr.window, "wm_geometry"):
            mngr.window.wm_geometry(f"+{pos[0]}+{pos[1]}")
        else:
            mngr.window.move(int(pos[0]), int(pos[1]))
    except Exception:
        pass

    xo_flat    = xo.flatten();
    x_flat     = x.flatten()
    idx_xo     = np.where(xo_flat != 0)[0];
    vals_xo    = xo_flat[idx_xo]
    m1, s1, b1 = ax.stem(idx_xo, vals_xo, linefmt='-', markerfmt='o', basefmt=' ')
    plt.setp(s1, 'color', '#f26419', 'linewidth', 1)
    plt.setp(m1, 'color', '#f26419', 'markersize', 7, 'markerfacecolor', 'none')

    idx_x      = np.where(x_flat != 0)[0];
    vals_x     = x_flat[idx_x]
    m2, s2, b2 = ax.stem(idx_x, vals_x, linefmt=':', markerfmt='o', basefmt=' ')
    plt.setp(s2, 'color', '#1c8ddb', 'linewidth', 1)
    plt.setp(m2, 'color', '#1c8ddb', 'markersize', 4)

    ax.grid(True)
    xx   = np.concatenate((xo_flat, x_flat))
    ymin = np.min(xx) - 0.1 if np.any(xx < 0) else -0.1
    ymax = np.max(xx) + 0.1 if np.any(xx > 0) else 0.2
    ax.set_xlim([0, len(x_flat)])
    ax.set_ylim([ymin, ymax])

    if ind:
        snr            = -10 * np.log10(np.linalg.norm(x_flat - xo_flat) ** 2)
        st1            = f"SNR={snr:.4g}"
        true_positives = np.count_nonzero((x_flat != 0) & (xo_flat != 0))
        wrong          = np.count_nonzero(xo_flat) - true_positives
        st2            = f", Number of mis-supports ={wrong}"
        ax.set_title(st1 + st2, fontweight='normal')
        ax.legend(['Ground-Truth', 'Recovered'], loc='upper right')

    plt.show()
