import warnings
from typing import Dict, Any, Optional
from .solvers.GPSP import GPSP
from .solvers.NM01 import NM01


def OBCSpack(A, b, s, k, solver: str, pars: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    r"""
    One-bit compressed sensing problem aims to recover sparse signal x from

                   b = Diag(h) .* sign(A * x + noise)

    1) The double sparsity constrained optimization (DSCO)

       min  ||Diag(b)*A*x + y - epsilon||^2 + eta||x||^2
       s.t. ||x||_0 <= s, ||y_+||_0 <= k

    where (epsilon, eta) > 0, s ∈ [1, n], k ∈ [0, m] are given.

    2) The step function regularized optimization (SFRO)

       min ||x.*x + vareps||^(q/2)_{q/2} + lam*||(epsilon - Diag(b)*A*x)_+||_0

    where (vareps, lam, epsilon) > 0, q ∈ (0, 1).
    Inputs:----------------------------------------------------------------------------------
     A:       The sensing matrix (NumPy array) with shape (m, n),                  (REQUIRED)
     b:       The binary observation (NumPy array) with shape (m,), b_i ∈ {-1, 1}  (REQUIRED)
     s:       Sparsity level of x, an integer ∈ [1, n]                             (REQUIRED)
     k:       An integer in [0, m], e.g., k = int(np.ceil(0.01 * m))               (REQUIRED)
     solver:  A string, can be one of {'GPSP', 'NM01'}                             (REQUIRED)
     pars:    Optional parameter dictionary                                        (OPTIONAL)
              ------------- For GPSP solving (DSCO)------------------------------------------
              pars['eps']     - The parameter in the model                     (default 1e-4)
              pars['eta']     - The penalty parameter              (default 0.01 / np.log(n))
              pars['acc']     - Acceleration is used if acc=1                     (default 0)
              pars['big']     - Start with a bigger s if big=1                    (default 1)
              pars['maxit']   - Maximum number of iterations                   (default 1000)
              pars['tol']     - Tolerance of halting condition                 (default 1e-8)
              -------------  For NM01 solving (SFRO)-----------------------------------------
              pars['x0']      - The initial point                       (default np.zeros(n))
              pars['q']       - Parameter in the objective                      (default 0.5)
              pars['vareps']  - Parameter in the objective                      (default 0.5)
              pars['epsilon'] - Parameter in the objective                     (default 0.15)
              pars['lam']     - The penalty parameter                             (default 1)
              pars['tau']     - A useful parameter                                (default 1)
              pars['maxit']   - Maximum number of iterations                   (default 1000)
    Outputs:---------------------------------------------------------------------------------
        out['sol']:   The sparse solution x (NumPy array)
        out['time']:  CPU time (seconds)
        out['iter']:  Number of iterations
        out['obj']:   Objective function value at out['sol']
    -----------------------------------------------------------------------------------------
    Send your comments and suggestions to <slzhou2021@163.com>
    Warning: Accuracy may not be guaranteed !!!!!
    """
    warnings.filterwarnings('ignore')

    if len(locals()) < 5:
        print('Insufficient input parameters!')
        return {}

    if pars is None:
        pars = {'disp': 1}

    if s is None or s == []:
        solver = 'NM01'

    if solver == 'GPSP':
        out = GPSP(A, b, s, k, pars)
    elif solver == 'NM01':
        out = NM01(A, b, s, pars)
    else:
        print(f"Unsupported solver: {solver}, available solvers are 'GPSP' and 'NM01'")
        out = {}

    return out