import numpy as np
import matplotlib.pyplot as plt
from OBCSpack import OBCSpack,random1bcs

n    = 500                        # Signal dimension
m    = int(np.ceil(0.5 * n))      # Number of measurements
s    = int(np.ceil(0.01 * n))     # Sparsity level
r    = 0.05                       # Flipping ratio
k    = int(np.ceil(r * m))        # Upper bound of sign flips
v    = 0.5                        # Correlation parameter

Type = 'Ind'  # or 'Cor'
test = 's'    # change 'test' to see effect of GPSP to
              # factors {'s','m','r','v','n'}

if test   == 'm':
    test0 = np.linspace(0.2, 2, 10)
elif test == 's':
    test0 = np.arange(2, 11)
elif test == 'r':
    test0 = np.arange(0.01, 0.11, 0.01)
elif test == 'v':
    test0 = np.arange(0.1, 1.0, 0.1)
    Type  = 'Cor'
elif test == 'n':
    test0 = (np.arange(5, 21, 5) * 1000)

f = (test == 'n')
S = 20 * (1 - f) + 10 * f
S = int(S)

recd = np.zeros((len(test0), 4))
pars = {'disp': 0}

for j in range(len(test0)):
    if test == 'm':
        m = int(np.ceil(test0[j] * n))
    elif test == 's':
        s = int(test0[j])
    elif test == 'r':
        r = test0[j]
    elif test == 'v':
        v = test0[j]
    elif test == 'n':
        n = int(test0[j])
        s = int(np.ceil(0.01 * n))
        m = int(np.ceil(n / 2))
    k = int(np.ceil(r * m))

    for ii in range(S):
        A, b, bo, xo = random1bcs(Type, m, n, s, r, 0.01, v)
        out = OBCSpack(A, b, s, k, 'GPSP', pars)

        recd[j, 0] -= 20 * np.log10(np.linalg.norm(xo - out['sol']))  # SNR
        recd[j, 1] += np.count_nonzero(np.sign(A @ out['sol']) - b) / m  # HD
        recd[j, 2] += np.count_nonzero(np.sign(A @ out['sol']) - bo) / m  # HE
        recd[j, 3] += out['time']

recd /= S

plt.close('all')
fig, axes = plt.subplots(1, 4, figsize=(9, 2), dpi=100)
ylabal    = ['SNR', 'HD', 'HE', 'TIME']

for j in range(4):
    ax = axes[j]
    ax.plot(test0, recd[:, j], 'b.-', linewidth=0.75)
    ax.grid(True)
    ax.set_xlabel(test)
    ax.set_ylabel(ylabal[j], labelpad=2)

    x_min, x_max = min(test0), max(test0)
    if j == 0:
        ax.set_ylim(0 - 2, 0.35 + 35)
    elif j == 3:
        ax.set_ylim(0 - 0.1, recd[:, j].max() + 0.1)
    else:
        ax.set_ylim(0 - 0.1, 0.35)

plt.tight_layout()
plt.show()
