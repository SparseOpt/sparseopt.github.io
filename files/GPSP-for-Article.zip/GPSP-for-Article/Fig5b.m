clc, clear all, close all, warning off
addpath(genpath(pwd));

n     = 500;           % signal dimension 
m     = ceil(.5*n);    % number of measurements
s     = ceil(.01*n);   % signal sparsity
r     = 0.05;          % sign flipping ratio
v     = 0.5;           % correlation parameter
S     = 200;           % number of trials

test  = 'm/n';         % test \in {'s_*','m/n','r','v','n'}
type  = 'Cor';         % type \in {'Ind', 'Cor'}

switch test
    case 's_*', test0 = ceil(2:10);
    case 'm/n', test0 = 0.1:0.2:2;
    case 'r',   test0 = 0.02:0.02:0.2;
    case 'v',   test0 = 0.1:0.1:0.9; type = 'Cor';
    case 'n',   test0 = (5000:5000:20000); S  = 20;
end

SNR   = [];
TIME  = [];
HD    = [];
HE    = [];
SPA   = [];
algo  = 7;
for j = 1:nnz(test0)
    switch test
        case 's_*',   s=test0(j);
        case 'm/n',   m=ceil(test0(j)*n);
        case 'r',     r=test0(j);
        case 'v',     v=test0(j);    
        case 'n',     n=test0(j); s=ceil(0.01*n); m=ceil(n/2);    
    end
    rand('seed',0);    
    randn('seed',0);  
    snr   = zeros(algo,1);
    time  = zeros(algo,1);
    hd    = zeros(algo,1);
    he    = zeros(algo,1);
    spa   = zeros(algo,1);
    for ii = 1 : S    
        % --------- Generate data ---------------------
       [A0,c,ctrue,xtrue]...
             =  random1bcs(type,m,n,s,0.1,r,v);
        x0   = zeros(n,1); 
        X    = zeros(n,algo);

        in   = 1;   
        fprintf('------ GPSP----------\n') 
        k        = ceil(0.01*m); 
        out      = GPSP(A0,c,s,k); 
        X(:,in)  = out.x/norm(out.x);
        time(in) = time(in) + out.time;

        fprintf('------ BIHT  ----------\n')
        in       = in+1;
        t        = tic;
        xb       = BIHT(c, A0, s,x0);
        time(in) = time(in) + toc(t); 
        X(:,in)  = xb/norm(xb); 
        L0       = ceil(nnz(sign(A0*xb)-ctrue));

        fprintf('------ PIHT  ------\n')
        in       = in+1;
        t        = tic;
        xih      = PIHT(c, A0, s, L0,-0.2,1,1,x0);
        time(in) = time(in) + toc(t); 
        X(:,in)  = xih/norm(xih);

        fprintf('------ AOP  ------\n')
        in       = in+1;
        L        = L0; 
        t        = tic;
        xa       = BIHT_AOP_flip(c, A0, x0, s, L, 1, 100, 1);
        time(in) = time(in) + toc(t); 
        X(:,in)  = xa/norm(xa);

        fprintf('------ PinBalAOP  ------\n')
        in       = in+1;
        t        = tic;
        xpi      = PIHT_AOP_flip(c, A0, x0, s, L, 1, 100, 1, .05); 
        time(in) = time(in) + toc(t); 
        X(:,in)  = xpi/norm(xpi);

        fprintf('------  PDASC  ------\n')
        in       = in+1;
        t        = tic;
        xpd      = pdasc(A0,A0',c,x0,s);
        time(in) = time(in) + toc(t ); 
        X(:,in)  = xpd/(norm(xpd)+1e-10); 

        fprintf('------ WPDASC ------\n') 
        in       = in+1;
        t        = tic;
        xw       = wpdasc(A0,A0',c,s);
        time(in) = time(in) + toc(t ); 
        X(:,in)  = xw/(norm(xw)+1e-10); 

        for alg=1:algo
            snr(alg)  = snr(alg) - 20*log10(norm(xtrue-X(:,alg)));    
            hd(alg)   = hd(alg)  + nnz(sign(A0*X(:,alg))-c)/m;
            he(alg)   = he(alg)  + nnz(sign(A0*X(:,alg))-ctrue)/m;
            spa(alg)  = spa(alg) + nnz(X(:,alg)==0&xtrue~=0)/s;
            spa(alg)  = spa(alg) + nnz(X(:,alg)==0&xtrue~=0)/s;
        end

     clc; [snr time]

    end

    SNR = [SNR; snr'/ii];
    TIME= [TIME; time'/ii];
    HD  = [HD;hd'/ii];
    HE  = [HE;he'/ii];  
    SPA = [SPA;spa'/ii]; 
end

RES=[SNR;HD;HE;TIME];


% plot results
algs  = {'GPSP','BIHT','PIHT','AOPF','PAOPF','PDASC','WPDASC'}; 
ylab  = {'SNR','HD','HE','SMR'};
mark  = {'--','*:','+:','x:','*-.','+-.','x-.'};
loc   = { 'SouthWest','NorthWest'};
color = {'#4a4e4d','#f6cd61','#0e9aa7','#fe8a71','#f6cd61','#3da4ab','#fe8a71'};
figure('Renderer', 'painters', 'Position', [600 100 900 300])

I    = [-0.10 -0.05 0.00];
for j= 1:3
    
    sub  = subplot(1,3,j);
    pos1 = get(sub, 'Position'); 
    P    = RES((j-1)*nnz(test0)+1:j*nnz(test0),:);
    for i= 1:algo
        p= plot(test0,P(:,i),mark{i}); hold on; grid on
        p.Color      = color{i};
        p.LineWidth  = 1.5;  
        p.MarkerSize = 5;  
    end
    
    if j==1  
        legend(algs,'NumColumns',1); 
    else
        legend(algs,'NumColumns',1);
        yticks([0 0.1 0.2 0.3 0.4])
        yticklabels({'0','0.1','0.2','0.3','0.4'})
    end   
    
    set(0,'DefaultAxesTitleFontWeight','normal')
    xlabel(test), title(ylab{j}) 
    j0 = (j==1)*0.1+(j~=1)*0.02;
    axis([min(test0) max(test0) min(P(:))-j0 max(P(:))*1.01])
    set(sub, 'Position',pos1+[I(j),0.04,0.07,-0.04] )
    set(gca,'FontSize',10, 'FontWeight','normal'); 
    
end

if isequal(test, 's_*'); test = 's'; end
if isequal(test, 'm/n'); test = 'm'; end
path = strcat('outputs\',type,'-effect-',test);  
saveas(figure(1), strcat(path,'.fig')); 