clc; close all; clear; warning off
addpath(genpath(pwd));

n     = 500;           % signal dimension 
m     = ceil(.5*n);    % number of measurements
s     = ceil(.01*n);   % signal sparsity
r     = 0.01;          % sign flipping ratio
v     = 0.5;           % correlation parameter
type  = 'Ind';         % or 'Cor',matrix type

[A,c,co,xo]= random1bcs(type,m,n,s,0.1,r,v);  
k          = ceil(0.01*m);
out        = GPSP(A,c,s,k);
nx         = out.x/norm(out.x);
fprintf('Time: %6.3f\n',out.time);
fprintf('SNR:  %6.3f\n',-20*log10(norm(nx-xo)));
fprintf('HD:   %6.3f\n',nnz(sign(A*nx)-c)/m)
fprintf('HE:   %6.3f\n',nnz(sign(A*nx)-co)/m)

RecoverShow(xo,nx,[1000, 500, 450 250]),pause(0.5)

