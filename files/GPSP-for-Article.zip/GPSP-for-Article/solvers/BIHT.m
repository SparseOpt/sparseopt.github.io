function x = BIHT(y, Phi, K,x0)
% Modeified by Yuling Jiao to work when Phi is a function handle
implicit = isa(Phi,'function_handle');
if implicit == 0
    N  = size(Phi,2);
    A = @(in) sign(Phi*in);
    Phit = Phi';

else
    if ~exist('Phit','var')
        disp('error, funtion handle Phit is not defined')
    end
    N = length(Phit(y));
    A = @(in) sign(Phi(in));
end
if K >=100
   maxiter = 200;
else
   maxiter = 100;
end
htol = 0;
if nargin<4
x = zeros(N,1);
else
 x = x0;
end
hd = Inf;
aidx = find(x);
ii=0;
Ax = sign(Phi(:,aidx)*x(aidx));
while(htol < hd)&&(ii < maxiter)
	% Get gradient
    if implicit == 0
	 %  g = Phit*(A(x) - y);
       g = Phit*(Ax-y);
    else
       g = Phit(A(x) - y);
    end
	% Step
	a = x - g;

	% Best K-term (threshold)
% 	[trash, aidx] = sort(abs(a), 'descend');
% 	a(aidx(K+1:end)) = 0;
    [~, aidx] = maxk(abs(a), K);
    a0 =zeros(N,1);
    a0(aidx)=a(aidx);
   % a       = a0;
    
	% Update x
	x = a0;

	% Measure hammning distance to original 1bit measurements
    Ax = sign(Phi(:,aidx)*x(aidx));
	hd = nnz(y - Ax);
	ii = ii+1;
end
% Now project to sphere
x = x/norm(x);











