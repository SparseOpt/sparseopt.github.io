import numpy as np
from scipy.linalg import lstsq
from CSpack import GPNP, IIHT, NHTP, MIRL1, NL0R, PSNP

def CSpack(A, At, b, n, s, solver, pars=None):
    r"""
        This solver solves compressive sensing (CS) in one of the following forms

        1) The sparsity constrained compressive sensing (SCCS)

                min_{x\in R^n} 0.5||Ax-b||^2  s.t. ||x||_0<=s

        2) The L0 regularized compressive sensing (LqCS)

                min_{x\in R^n} 0.5||Ax-b||^2 + lambda * ||x||_q^q,  0<=q<1

        3) The reweighted L1-regularized compressive sensing (RL1CS)

                min_{x\in R^n} 0.5||Ax-b||^2 + lambda||Wx||_1

        where s << n is the given sparsity and lambda>0
              A\in\R{m by n} the measurement matrix
              b\in\R{m by 1} the observation vector
              W\in\R{n by n} is a diagonal matrix to be updated iteratively
        --------------------------------------------------------------------------
        Inputs:
          A  :     The measurement matrix, A\in\R{m by n}              (REQUIRED)
          At :     The transpose of A and can be [] if A is a matrix   (REQUIRED)
                   But At is REQUIRED if A is a function handle
                   i.e., A*x = A(x); A'*y = At(y);
          b:       The observation vector  b\in\R{m by 1}              (REQUIRED)
          n:       Dimension of the solution x,                        (REQUIRED)
          s:       The sparsity level, if unknown, put it as []        (REQUIRED)
          solver:  A text string, can be one of                        (REQUIRED)
                   {'NHTP','GPNP','PSNP','NL0R','IIHT','MILR1'}

                  --------------------------------------------------------------------------------
                           |  'NHTP'   |  'GPNP'   |  'PSNP'   |  'NL0R'   |  'IIHT'   |  'MIRL1'
                  --------------------------------------------------------------------------------
                  Model    |   SCCS    |   SCCS    |   LqRCS   |   L0RCS   |   SCCS    |   RL1CS
                  Method   | 2nd-order | 2nd-order | 2nd-order | 2nd-order | 1st-order | 1st-order
                  Sparsity | required  | required  |  no need  |  no need  | required  |  no need
                  --------------------------------------------------------------------------------

          pars  : ----------------For all solvers -------------------------------------
                    pars['x0']     --  Starting point of x       (default, zeros(n,1))
                    pars['disp']   --  =1, show results for each step      (default,1)
                                       =0, not show results for each step
                    pars['maxit']  --  Maximum number of iterations     (default, 2e3)
                    pars['tol']    --  Tolerance of stopping criteria   (default,1e-6)
                    ----------------Particular for NHTP ------------------------------
                    pars['eta']    --  A positive scalar for 'NHTP'       (default, 1)
                                       Tuning pars.eta may improve solution quality.
                    ----------------Particular for PSNP ------------------------------
                    pars['q']      --  Decide Lq norm                  (default,  0.5)
                    pars['lambda'] --  An initial penalty parameter    (default,  0.1)
                    pars['obj']    --  A predefined lower bound of f(x)(default,1e-20)
                    ----------------Particular for NL0R ------------------------------
                    pars['tau']    --  A positive scalar for 'NL0R'    (default,    1)
                    pars['lambda'] --  An initial penalty parameter    (default,  0.1)
                    pars['obj']    --  A predefined lower bound of f(x)(default,1e-20)
                    ----------------Particular for IIHT ------------------------------
                    pars['neg']    --  =0, Compute SCCS without x>=0       (default,0)
                                       =1, Compute SCCS with x>=0
        ------------------------------------------------------------------------------
          Outputs:
                    out['sol']:   The sparse solution x
                    out['sp']:    Sparsity level of Out.sol
                    out['time']:  CPU time
                    out['iter']:  Number of iterations
                    out['obj']:   Objective function value at Out.sol
        ------------------------------------------------------------------------------
        """

    pars = {} if pars is None else dict(pars)

    # --- Basic checks ---
    if callable(A) and (At is None or not callable(At)):
        raise ValueError("When A is a function handle, its transpose At (also a function handle) must be provided.")

    # Sparsity s handling (consistent with MATLAB: if missing and algorithm requires s, switch to PSNP)
    if s is None or (isinstance(s, float) and np.isnan(s)):
        if solver in ['NHTP', 'GPNP', 'IIHT']:
            print(" Since no sparsity level is provided, change solver to <PSNP>")
            solver = 'PSNP'
        s_int = None
    else:
        s_int = int(np.ceil(s))

    # --- Default parameters ---
    pars.setdefault('disp',    1)
    pars.setdefault('x0',      np.zeros(n, dtype=float))
    pars.setdefault('maxit',   2000)
    pars.setdefault('tol',     1e-6)

    # --- Standardize b to 1D ---
    b = np.asarray(b, dtype=float).ravel()

    # --- Assemble data (n is needed for operator form) ---
    if callable(A):
        data = {'A': A, 'At': At, 'b': b, 'n': int(n)}
    else:
        A = np.asarray(A, dtype=float)
        data = {'A': A, 'At': None, 'b': b}

    # --- Default setting for λ: strictly replicate MATLAB version ---
    if 'lambda' in pars:
        lambda_base  = float(pars['lambda'])
        lambda_NL0R  = lambda_base
    else:
        if callable(A):
            # Function handle: lambda = 0.005 * ||At(b)||_inf
            gvec        = At(b)
            lambda_base = 0.005 * np.max(np.abs(gvec))
        else:
            # Matrix: lambda = 0.005 * ||b' * A||_inf
            # b is (m,), b' * A -> (n,)
            gvec        = b @ A
            lambda_base = 0.005 * np.max(np.abs(gvec))
        lambda_NL0R = 10.0 * lambda_base

    # --- Route to solver ---
    solver_map = {
        'NHTP': lambda d, n_, s_, p: NHTP(d, n_, s_, p),
        'GPNP': lambda d, n_, s_, p: GPNP(d, n_, s_, p),
        'IIHT': lambda d, n_, s_, p: IIHT(d, n_, s_, p),
        'NL0R': lambda d, n_, lam_, p: NL0R(d, n_, lam_, p),
        'PSNP': lambda d, n_, lam_, p: PSNP(d, n_, lam_, p),
        'MIRL1': lambda d, n_, lam_, p: MIRL1(d, n_, lam_, p),
    }
    if solver not in solver_map:
        raise ValueError(f"Unknown solver {solver}, available options: {list(solver_map.keys())}")

    if solver in ['NHTP', 'GPNP', 'IIHT']:
        if s_int is None:
            raise ValueError(f"{solver} requires sparsity level s.")
        out      = solver_map[solver](data, n, s_int, pars)
    else:
        lam_used = lambda_NL0R if solver == 'NL0R' else lambda_base
        out      = solver_map[solver](data, n, lam_used, pars)

    if solver in {'NL0R', 'PSNP', 'MIRL1'} and (not callable(A)):
        # Threshold (default 0): estimate threshold only when out.error > 1e-2
        thresh = 0.0
        if out.get('error', 0) > 1e-2:
            if s_int is None:
                # No s: ratio method (fully replicate MATLAB's indexing and normalization)
                nz = out['sol'][out['sol'] != 0]
                if nz.size >= 2:
                    sx     = np.sort(np.abs(nz))  # Ascending order
                    ratios = sx[1:] / sx[:-1]
                    nr     = np.linalg.norm(ratios)
                    if nr > 0:
                        ratios_n   = ratios / nr
                        it         = int(np.argmax(ratios_n))  # 0-based, corresponding to MATLAB's it
                        if it < sx.size:
                            thresh = float(sx[it])
            else:
                abs_sol = np.abs(out['sol'])
                if abs_sol.size >= (s_int + 1):
                    top    = np.partition(abs_sol, -(s_int + 1))[-(s_int + 1):]
                    thresh = float(np.min(top))

        Ts = np.flatnonzero(out['sol'])
        if Ts.size > 0:
            A_Ts      = A[:, Ts]
            xs        = np.zeros(n, dtype=float)
            xs_Ts, *_ = lstsq(A_Ts, b)
            xs[Ts]    = xs_Ts
            obj_ls    = 0.5 * np.linalg.norm(A_Ts @ xs[Ts] - b) ** 2
            if obj_ls <= out.get('obj', np.inf):
                out['sol'] = xs
                out['obj'] = obj_ls
        else:
            Ts = np.array([], dtype=int)

        # Obtain T using threshold and perform least squares again
        T = np.flatnonzero(np.abs(out['sol']) > thresh)
        if T.size > 0:
            A_T      = A[:, T]
            x_ref    = np.zeros(n, dtype=float)
            xT, *_   = lstsq(A_T, b)
            x_ref[T] = xT
            obj_ref  = 0.5 * np.linalg.norm(A_T @ x_ref[T] - b) ** 2
            # Replacement criterion consistent with MATLAB
            if (obj_ref < out['obj']) or (Ts.size > 0 and abs(T.size - Ts.size) < 0.75 * Ts.size):
                out['sol'] = x_ref
                out['obj'] = obj_ref

    print(' -------------------------------------')
    if out.get('obj', np.inf) < 1e-10:
        print(' A global minimizer may be found')
        print(f" since (1/2)||Ax-b||^2 = {out['obj']:.2e}")
        print(' -------------------------------------')

    return out
