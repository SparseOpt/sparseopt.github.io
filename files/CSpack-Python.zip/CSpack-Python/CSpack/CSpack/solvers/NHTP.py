from __future__ import annotations
import time
from typing import Callable, Dict, Optional, Tuple, Union
import numpy as np

try:
    import scipy.sparse as sp
except Exception:
    sp = None

Array    = np.ndarray
LinOp    = Union[Array, Callable[[Array], Array]]
DataDict = Dict[str, object]


def NHTP(data: DataDict, n: int, s: int, pars: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    r"""
    Solve:  min_x 0.5*||A x - b||^2  s.t. ||x||_0 <= s
    data:
      - matrix form: {'A': A (m,n), 'b': b (m,)} or scipy.sparse
      - operator form: {'A': Ax(x)->Ax, 'At': AT(y)->A^T y, 'b': b (m,), 'n': n}
    n: dimension, s: sparsity level
    pars (optional): {'x0','eta','disp','draw','maxit','tol','obj'}
    Returns dict: sol, sp, time, iter, obj, error
    """
    t0 = time.perf_counter()

    # ---- Input checks ----
    if data is None or 'A' not in data or 'b' not in data:
        raise ValueError("data must contain 'A' and 'b'")
    A = data['A']
    b = np.asarray(data['b'], dtype=np.float64).ravel()
    if callable(A) and 'At' not in data:
        raise ValueError("When A is callable, data must contain 'At'")
    if callable(A) and 'n' not in data:
        data      = dict(data)
        data['n'] = int(n)

    pars  = {} if pars is None else dict(pars)
    disp  = int(pars.get('disp', 1))
    itmax = int(pars.get('maxit', 2000))
    tol   = float(pars.get('tol', 1e-6))
    tolF  = float(pars.get('obj', 1e-20))
    x0    = np.asarray(pars.get('x0', np.zeros(n, dtype=np.float64)), dtype=np.float64).ravel()
    if x0.size != n:
        raise ValueError("x0 size mismatch")

    func            = lambda x, T1, T2: CS(x, T1, T2, data)
    x0, obj, g, eta = getparameters(n, s, x0, func, pars)

    x     = x0.copy()
    beta  = 0.5
    sigma = 5e-5
    delta = 1e-10
    T0    = np.array([], dtype=np.int64)
    Error = np.zeros(itmax, dtype=np.float64)
    Obj   = np.zeros(itmax, dtype=np.float64)
    FNorm = lambda v: float(np.dot(v, v))
    xo    = np.zeros(n, dtype=np.float64)

    if disp:
        print("\n Start to run the solver -- NHTP ")
        print(" -------------------------------------")
        print(" Iter          ObjVal         CPUTime ")
        print(" -------------------------------------")

    # Initial check
    if FNorm(g) < 1e-20 and np.count_nonzero(x) <= s:
        if disp:
            print(" Starting point is a good solution. Stop NHTP")
        return {
            'sol': x.copy(),
            'obj': float(obj),
            'sp': int(np.count_nonzero(x)),
            'iter': 0,
            'time': time.perf_counter() - t0,
            'error': 0.0,
        }

    if np.isnan(g).any():
        x0                               = np.zeros(n, dtype=np.float64)
        x0[np.random.randint(0, n)] = np.random.rand()
        obj, g                           = func(x0, None, None)

    # ---- Main loop ----
    for it in range(itmax):
        xtg = x0 - eta * g

        if s <= 0:
            T = np.array([], dtype=np.int64)
        elif s >= n:
            T = np.arange(n, dtype=np.int64)
        else:
            idx = np.argpartition(-np.abs(xtg), s - 1)[:s]
            T = np.sort(idx)

        TTc               = np.setdiff1d(T0, T, assume_unique=False)
        flag_same_support = (TTc.size == 0)
        gT                = g[T]

        max_abs_g         = float(np.max(np.abs(g))) if g.size else 0.0
        min_abs_xT        = float(np.min(np.abs(x[T]))) if T.size and np.any(x[T] != 0) else 0.0
        xtaus             = max(0.0, max_abs_g - (min_abs_xT / (eta if eta != 0 else 1.0)))

        if flag_same_support:
            FxT       = np.sqrt(FNorm(gT))
            Error[it] = xtaus + FxT
        else:
            FxT       = np.sqrt(FNorm(gT) + abs(FNorm(x) - FNorm(x[T])))
            Error[it] = xtaus + FxT

        if disp:
            print(f"{it+1:4d}          {obj:5.2e}      {time.perf_counter() - t0:6.3f}sec")

        # Stopping
        if (Error[it] < tol) or (obj <= tolF):
            break

        # Update next iterate
        if it == 0 or flag_same_support:
            H   = func(x0, T, None)[0]  # H(T,T)
            d   = solve_on_support(H, -gT, it, mode='nhtp')
            dg  = float(np.dot(d, gT))
            ngT = FNorm(gT)
            if (dg > max(-delta * FNorm(d), -ngT)) or np.isnan(dg):
                d  = -gT.copy()
                dg = ngT
        else:
            H, D   = func(x0, T, TTc)  # H(T,T) and D(T,TTc)
            Dx     = apply_D(D, x0[TTc])
            rhs    = Dx - gT
            d      = solve_on_support(H, rhs, it, mode='nhtp')
            Fnz    = FNorm(x[TTc]) / (4.0 * (eta if eta != 0 else 1.0)) if TTc.size else 0.0
            dgT    = float(np.dot(d, gT))
            dg     = dgT - float(np.dot(x0[TTc], g[TTc])) if TTc.size else dgT
            delta0 = 1e-4 if (Fnz > 1e-4) else delta
            ngT    = FNorm(gT)
            if (dgT > max(-delta0 * FNorm(d) + Fnz, -ngT)) or np.isnan(dg):
                d  = -gT.copy()
                dg = ngT

        alpha   = 1.0
        x       = xo.copy()  # zeros, consistent with MATLAB
        obj0    = obj
        Obj[it] = obj

        for _ in range(6):
            x[T]   = x0[T] + alpha * d
            obj    = float(func(x,None,None)[0])
            if obj < obj0 + alpha * sigma * dg:
                break
            alpha *= beta

        fhtp     = 0
        if obj > obj0:
            x[T] = xtg[T]
            obj  = float(func(x,None,None)[0])
            fhtp = 1

        # Second stopping criterion
        flag1 = (abs(obj - obj0) < 1e-6 * (1.0 + abs(obj)) and fhtp == 1)
        flag2 = (abs(obj - obj0) < 1e-10 * (1.0 + abs(obj)) and Error[it] < 1e-2)
        if (it + 1) > 10 and (flag1 or flag2):
            if obj > obj0:
                # rollback
                it -= 1
                x   = x0.copy()
                T   = T0.copy()
            break

        T0     = T.copy()
        x0     = x.copy()
        obj, g = func(x, None, None)

        # Update eta
        if (it + 1) % 50 == 0:
            if Error[it] > 1.0 / (it + 1) ** 2:
                eta = eta / (1.05 if (it + 1) < 1500 else 1.5)
            else:
                eta = eta * 1.25

    # ---- Results ----
    out = {
        'sol': x.copy(),
        'sp': int(np.count_nonzero(x)),
        'time': time.perf_counter() - t0,
        'iter': it + 1 if 'it' in locals() else 0,
        'obj': float(obj),
        'error': FNorm(np.asarray(g, dtype=np.float64).ravel()),
    }
    return out

def solve_on_support(H: Union[Array, Callable[[Array], Array]],
                      rhs: Array, iter_idx: int, mode: str = 'nhtp') -> Array:
    """
    Solve H d = rhs using direct solve if ndarray small, otherwise CG.
    """
    if callable(H):
        cgit  = max(1, min(50, 10 * (iter_idx + 1)))
        cgtol = max(1e-6 / (iter_idx + 1), 1e-20)
        return my_cg(H, rhs, cgtol, cgit, np.zeros_like(rhs))
    else:
        H = np.asarray(H, dtype=np.float64)
        s = H.shape[0]
        if s <= 3000:
            # direct solve
            try:
                return np.linalg.solve(H, rhs)
            except np.linalg.LinAlgError:
                # robust fallback
                return np.linalg.lstsq(H, rhs, rcond=None)[0]
        else:
            Hop = lambda v: H @ v
            return my_cg(Hop, rhs, 1e-20, min(50, 10 * (iter_idx + 1)), np.zeros_like(rhs))


def apply_D(D: Union[Array, Callable[[Array], Array]], v: Array) -> Array:
    if callable(D):
        return D(v)
    else:
        return np.asarray(D, dtype=np.float64) @ v


def my_cg(fx: Union[Array, Callable[[Array], Array]],
           b: Array, cgtol: float, cgit: int, x0: Array) -> Array:
    """
    Conjugate Gradient on linear operator fx (callable or matrix).
    """
    op = (fx if callable(fx) else (lambda vv, M=np.asarray(fx, dtype=np.float64): M @ vv))
    x  = x0.copy()
    r  = b - op(x) if np.count_nonzero(x) else b.copy()
    e  = float(np.dot(r, r))
    t  = e
    p  = r.copy()
    for _ in range(cgit):
        if e < cgtol * t:
            break
        w  = op(p)
        pw = float(np.dot(p, w))
        if pw == 0.0:
            break
        a  = e / pw
        x += a * p
        r -= a * w
        e0 = e
        e  = float(np.dot(r, r))
        p  = r + (e / e0) * p
    return x


# ---------- Objective/gradient/Hessian blocks (matrix or operator A) ----------

def CS(x: Array,
        T1: Optional[Array],
        T2: Optional[Array],
        data: DataDict) -> Tuple[object, Optional[object]]:
    """
    If T1/T2 are None -> returns (f, grad)
    Else -> returns ( H(T1,T1) , D(T1,T2) ) where D is either array or callable
    """
    A = data['A']
    b = np.asarray(data['b'], dtype=np.float64).ravel()
    x = np.asarray(x, dtype=np.float64).ravel()

    # Matrix A (dense or scipy.sparse)
    if not callable(A):
        is_sparse = (sp is not None and sp.issparse(A))

        if T1 is None and T2 is None:
            nnz = np.count_nonzero(x)
            if nnz >= 0.025 * x.size:
                Axb   = (A @ x) - b if not is_sparse else (A.dot(x) - b)
            else:
                Tx    = np.flatnonzero(x)
                Axb = (A[:, Tx] @ x[Tx])-b if not is_sparse else A[:, Tx].dot(x[Tx])-b
            f = 0.5 * float(np.dot(Axb, Axb))
            g = (A.T @ Axb) if not is_sparse else A.T.dot(Axb)
            return f, g

        AT = A[:, T1] if not is_sparse else A[:, T1]
        if T1.size <= 1000:
            H = (AT.T @ AT) if not is_sparse else (AT.T @ AT)
        else:
            H = (lambda v, AT=AT: AT.T @ (AT @ v)) if not is_sparse else (lambda v, AT=AT: AT.T @ (AT @ v))
        if T2 is None:
            return H, None
        else:
            A_T2  = A[:, T2] if not is_sparse else A[:, T2]
            if (T1.size <= 1000) and (T2.size <= 1000):
                D = AT.T @ A_T2
            else:
                D = (lambda v, AT=AT, A_T2=A_T2: AT.T @ (A_T2 @ v))
            return H, D

    if 'At' not in data or 'n' not in data:
        raise ValueError("operator form requires 'At' and 'n' in data")
    Aop: Callable[[Array], Array] = A  # type: ignore
    ATop: Callable[[Array], Array] = data['At']  # type: ignore
    n = int(data['n'])

    if T1 is None and T2 is None:
        Axb = Aop(x) - b
        f   = 0.5 * float(np.dot(Axb, Axb))
        g   = ATop(Axb)
        return f, g

    def fgH(z: Array, t1: Array, t2: Array) -> Array:
        vec     = np.zeros(n, dtype=np.float64)
        vec[t2] = z
        return ATop(Aop(vec))[t1].copy()

    H = (lambda v, t1=T1: fgH(v, t1, T1))
    if T2 is None:
        return H, None
    D = (lambda v, t1=T1, t2=T2: fgH(v, t1, t2))
    return H, D


# ---------- Parameter initialization (getparameters) ----------

def getparameters(n: int, s: int, x0: Array,
                   func: Callable[[Array, Optional[Array], Optional[Array]], Tuple[object, Optional[object]]],
                   pars: Dict[str, object]) -> Tuple[Array, float, Array, float]:
    x0     = np.asarray(x0, dtype=np.float64).ravel()
    obj, g = func(x0, None, None)

    # If user provided x0 and it's nonzero, compare with zero-start
    if 'x0' in pars and np.linalg.norm(x0) > 0:
        obj0, g0     = func(np.zeros(n, dtype=np.float64), None, None)
        obj_x0, g_x0 = obj, g
        if obj0 < obj_x0 / 10.0:
            x0       = np.zeros(n, dtype=np.float64)
            obj, g   = obj0, g0
        else:
            ns0 = int(np.count_nonzero(x0))
            if ns0 == s:
                # top-s indices of |x0|
                if s <= 0:
                    T   = np.array([], dtype=np.int64)
                elif s >= n:
                    T   = np.arange(n, dtype=np.int64)
                else:
                    idx = np.argpartition(-np.abs(x0), s - 1)[:s]
                    T   = np.sort(idx)
                # eta = min(|x0(T)|) / (1 + max(|g(setdiff)|))
                others      = np.setdiff1d(np.arange(n, dtype=np.int64), T)
                denom       = 1.0 + (np.max(np.abs(g[others])) if others.size else 0.0)
                numer       = float(np.min(np.abs(x0[T]))) if T.size else 0.0
                pars['eta'] = numer / denom if denom != 0 else 1.0
            elif ns0 < s:
                # eta = max(x0(x0>0.1)) / (1 + max(|g|))
                mask        = (x0 > 0.1)
                numer       = float(np.max(x0[mask])) if np.any(mask) else float(np.max(np.abs(x0))) if np.any(x0) else 0.0
                denom       = 1.0 + float(np.max(np.abs(g))) if g.size else 1.0
                pars['eta'] = numer / denom if denom != 0 else 1.0
            else:
                # keep top-s of x0
                if s <= 0:
                    T   = np.array([], dtype=np.int64)
                elif s >= n:
                    T   = np.arange(n, dtype=np.int64)
                else:
                    idx = np.argpartition(-np.abs(x0), s - 1)[:s]
                    T   = np.sort(idx)
                x0_new      = np.zeros(n, dtype=np.float64)
                x0_new[T]   = x0[T]
                x0          = x0_new
                mask        = (x0 > 0.1)
                numer       = float(np.max(x0[mask])) if np.any(mask) else float(np.max(np.abs(x0))) if np.any(x0) else 0.0
                denom       = 1.0 + float(np.max(np.abs(g))) if g.size else 1.0
                pars['eta'] = numer / denom if denom != 0 else 1.0

            if 'eta' not in pars or pars['eta'] is None:
                denom       = 1.0 + float(np.max(np.abs(g))) if g.size else 1.0
                numer       = float(np.max(np.abs(x0))) if np.any(x0) else 0.0
                pars['eta'] = numer / denom if denom != 0 else 1.0

    # If eta provided, use it; else set heuristic as MATLAB
    if 'eta' in pars and pars['eta'] is not None:
        eta = float(pars['eta'])
    else:
        # compute g at ones(n)
        _, g1 = func(np.ones(n, dtype=np.float64), None, None)
        abg1 = np.abs(g1)
        T = np.flatnonzero(abg1 > 1e-8)
        if T.size == 0:
            eta = 10.0 * (1.0 + s / n) / min(10.0, np.log(n))
        else:
            maxe = float(np.sum(1.0 / (abg1[T] + np.finfo(float).eps)) / T.size)
            if maxe > 2.0:
                eta = (np.log2(1.0 + maxe) / np.log2(maxe)) * np.exp((s / n) ** (1.0 / 3.0))
            elif maxe < 1.0:
                eta = (np.log2(1.0 + maxe)) * (n / s) ** 0.5
            else:
                eta = (np.log2(1.0 + maxe)) * np.exp((s / n) ** (1.0 / 3.0))

    # Ensure outputs consistent
    obj = float(obj)
    g = np.asarray(g, dtype=np.float64).ravel()
    return x0, obj, g, float(eta)