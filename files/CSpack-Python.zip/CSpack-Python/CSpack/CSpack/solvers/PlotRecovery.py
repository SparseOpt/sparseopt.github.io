import numpy as np
import matplotlib.pyplot as plt

# for macOS users, you might need the following two lines
# import matplotlib
# matplotlib.use("TkAgg")

def PlotRecovery(xo, x, pos, ind):
    """
    xo: Ground-truth signal (NumPy array).
    x: Recovered signal (NumPy array).
    pos: Figure position [left, bottom, width, height] in pixels.
    ind: Boolean flag to display title and legend.
    """
    fig = plt.figure(figsize=(pos[2] / 100, pos[3] / 100), dpi=100)
    ax  = fig.add_axes([0.05, 0.1, 0.9, 0.8])

    xo_flat = xo.flatten()
    x_flat = x.flatten()

    idx_xo = np.where(xo_flat != 0)[0]
    vals_xo = xo_flat[idx_xo]

    markerline, stemlines, baseline = ax.stem(idx_xo, vals_xo, linefmt='-', markerfmt='o', basefmt=' ')
    plt.setp(stemlines, 'color', '#f26419', 'linewidth', 1)
    plt.setp(markerline, 'color', '#f26419', 'markersize', 7, 'markerfacecolor', 'none')

    idx_x = np.where(x_flat != 0)[0]
    vals_x = x_flat[idx_x]

    markerline, stemlines, baseline = ax.stem(idx_x, vals_x, linefmt=':', markerfmt='o', basefmt=' ')
    plt.setp(stemlines, 'color', '#1c8ddb', 'linewidth', 1)
    plt.setp(markerline, 'color', '#1c8ddb', 'markersize', 4)

    ax.grid(True)  # equivalent to 'grid on'
    ymin = -0.1
    ymax = 0.2

    xx = np.concatenate((xo_flat, x_flat))

    if np.any(xx < 0):  # nnz(xx<0)>0 becomes np.any(xx < 0)
        ymin = np.min(xx[xx < 0]) - 0.1

    if np.any(xx > 0):  # nnz(xx>0)>0 becomes np.any(xx > 0)
        ymax = np.max(xx[xx > 0]) + 0.1

    ax.set_xlim([0, len(x_flat)])
    ax.set_ylim([ymin, ymax])

    if ind:
        snr = np.linalg.norm(x_flat - xo_flat) / (np.linalg.norm(x_flat) + 1e-15)
        st1 = f"Recovery accuracy ={snr:.4g}"  # num2str(..., 4) for significant digits

        wrong = np.count_nonzero(xo_flat) - np.count_nonzero((x_flat != 0) & (xo_flat != 0))
        st2 = f", Number of mis-supports ={wrong}"

        ax.set_title(st1 + st2, fontweight='normal')
        ax.legend(['Ground-Truth', 'Recovered'])

    plt.show()