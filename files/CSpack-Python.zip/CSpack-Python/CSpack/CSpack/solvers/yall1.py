import numpy as np

def yall1(A0, b0, opts):
    """
    Python version of YALL1 (simplified to the functionality needed by MIRL1: weighted L1 + (1/2*rho)||Ax-b||^2)
    Supports:
      - A is a matrix or an operator {'times': f, 'trans': ft}
      - weights: weight w
      - rho: L1/L2 penalty; if 0, equivalent to BP (no noise)
      - tol, maxit, nonorth, nonneg (optional)
    """
    # Linear operator encapsulation
    A, At, b, opts = _linear_operators(A0, b0, opts)
    m              = b.size
    rho            = float(opts.get('rho', 0.0))
    # Compatible with opts.pho in MIRL1.m
    if 'pho' in opts and 'rho' not in opts:
        rho = float(opts['pho'])
    w       = opts.get('weights', 1.0)
    if np.isscalar(w):
        w   = float(w)
    else:
        w   = np.asarray(w).ravel().astype(float)
    tol     = float(opts.get('tol', 1e-4))
    maxit   = int(opts.get('maxit', 5000))
    nonorth = int(opts.get('nonorth', 0))
    nonneg  = int(opts.get('nonneg', 0))
    gamma   = float(opts.get('gamma', 1.0))

    x0      = opts.get('x0', None)
    z0      = opts.get('z0', None)

    Atb     = At(b)
    if np.linalg.norm(b, np.inf) < tol:
        n   = Atb.size
        return np.zeros(n, dtype=float)
    bmax    = max(np.linalg.norm(b, np.inf), 1.0)
    b       = b / bmax
    if rho > 0:
        rho = rho / bmax

    # Main loop initialization
    if x0 is None:
        x   = At(b).astype(float)
    else:
        x   = np.asarray(x0, dtype=float).ravel()
    if z0 is None:
        z   = np.zeros_like(x)
    else:
        z   = np.asarray(z0, dtype=float).ravel()

    # y, Aty needed for non-orthogonal case
    if nonorth:
        y   = np.zeros(m, dtype=float)
        Aty = np.zeros_like(x)

    mu      = np.mean(np.abs(b))  # data scaling (maintain consistent magnitude with yall1.m)
    bdmu    = b / mu
    rdmu    = rho / mu
    rdmu1   = rdmu + 1.0

    xp      = x.copy()
    for it in range(1, maxit + 1):
        xdmu = x / mu
        if not nonorth:
            # A with orthogonal rows: y = (A(z - x/mu) + b/mu) / (1 + rho/mu)
            y = A(z - xdmu) + bdmu
            if rho > 0:
                y = y / rdmu1
            Aty = At(y)
        else:
            # Non-orthogonal: perform first-order correction
            ry = A(Aty - z + xdmu) - bdmu
            if rho > 0:
                ry = ry + rdmu * y
            Atry  = At(ry)
            denom = np.dot(Atry, Atry) + (rdmu * np.dot(ry, ry) if rho > 0 else 0.0)
            denom = max(denom, 1e-30)
            stp   = np.dot(ry, ry) / denom
            y     = y - stp * ry
            Aty   = Aty - stp * Atry

        z      = Aty + xdmu
        z      = _proj2box(z, w, nonneg)
        rd     = Aty - z
        xp[:]  = x
        x      = x + (gamma * mu) * rd

        xchg   = np.linalg.norm(x - xp) / max(np.linalg.norm(x), 1.0)
        rel_rd = np.linalg.norm(rd) / max(np.linalg.norm(z), 1.0)
        if xchg < tol and rel_rd < tol:
            break

    x = x * bmax
    if np.isscalar(w):
        return x
    else:
        return x


def _linear_operators(A0, b0, opts):
    b = np.asarray(b0, dtype=float).ravel()
    if isinstance(A0, np.ndarray):
        A0 = np.asarray(A0, dtype=float)
        A  = lambda x: A0 @ x
        At = lambda y: (y @ A0).T
    elif isinstance(A0, dict) and ('times' in A0) and ('trans' in A0):
        A  = A0['times']
        At = A0['trans']
    elif callable(A0):
        A  = lambda x: A0(x)
        At = lambda y: A0(y)
        raise ValueError("For operator A, please pass {'times': A, 'trans': At} dict.")
    else:
        raise ValueError("A must be a matrix or a dict {'times','trans'}")

    if 'nonorth' not in opts:
        opts['nonorth'] = _check_orth(A, At, b)
    return A, At, b, opts


def _check_orth(A, At, b):
    s1  = np.random.randn(b.size)
    s2  = A(At(s1))
    err = np.linalg.norm(s1 - s2) / max(np.linalg.norm(s1), 1.0)
    return 1 if err > 1e-12 else 0


def _proj2box(z, w, nonneg):
    """
    Weighted "box projection" (consistent with proj2box in original yall1_solve):
    nonneg=0: z <- z * w / max(w, |z|)
    nonneg=1: z <- min(w, Re(z)), no L1/L1 extension (not used by MIRL1)
    """
    z = z.astype(float, copy=True)
    if nonneg:
        if np.isscalar(w):
            z = np.minimum(w, np.real(z))
        else:
            z = np.minimum(w, np.real(z))
        return z
    if np.isscalar(w):
        # Synchronize scalar weight
        den = max(abs(z).max(), w, 1e-16)
        return z * (w / den)
    w = np.asarray(w, dtype=float)
    den = np.maximum(w, np.abs(z))
    den[den < 1e-16] = 1e-16
    return z * (w / den)