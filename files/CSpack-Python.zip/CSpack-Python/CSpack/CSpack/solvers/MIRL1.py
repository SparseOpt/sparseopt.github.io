import numpy as np
import time
from .yall1 import yall1  # If placed in the same directory, change to from yall1 import yall1


def MIRL1(data, n, mu, pars=None):
    r"""
    Reweighted L1 (MIRL1) solver (Python version)
    Objective: min 0.5||Ax - b||^2 + mu * ||w .* x||_1
    """
    if pars is None:
        pars = {}

    if 'A' not in data:
        print("<data.A> is missing, unable to run the solver ...")
        return
    if 'b' not in data:
        print("<data.b> is missing, unable to run the solver ...")
        return
    A = data['A']
    b = np.asarray(data['b']).ravel()
    m = b.size

    # Parameter settings
    itmax, rate, tol, disp, i0, theta = get_parameters(m, n, mu, pars)
    thresh_zero                       = pars.get('thresh_zero', 1e-6)  # Small signal threshold

    # Initialization
    x = np.zeros(n, dtype=float)
    w = np.ones(n, dtype=float)

    # Prepare linear operator interface
    if callable(A):
        if 'At' not in data:
            print("<data.At> is missing, unable to run the solver ...")
            return
        Aya = {'times': data['A'], 'trans': data['At']}
    else:
        Aya = np.asarray(A, dtype=float)

    # Configure yall1 options
    opts_ya = {}
    opts_ya['tol']      = tol
    if 'rho' in pars:
        opts_ya['rho']  = float(pars['rho'])
    else:
        opts_ya['rho']  = float(pars.get('pho', 0.0))

    t_start = time.perf_counter()

    if disp:
        print("\n Start to run the solver -- MIRL1 ")
        print(" -------------------------------------")
        print(" Iter          ObjVal         CPUTime ")
        print(" -------------------------------------")

    # Main iteration loop
    for it in range(1, itmax + 1):
        x0 = x.copy()
        w0 = w.copy()

        opts_ya['weights'] = w
        opts_ya['x0']      = x0
        x                  = yall1(Aya, b, opts_ya)

        dx     = x - x0
        denom  = max(np.linalg.norm(x0), 1.0)
        Error  = np.linalg.norm(dx) / denom

        # Print information
        if disp:
            fx = fx_val(A, x, b)
            print(f"{it:4d}          {fx:5.2e}      {time.perf_counter() - t_start:6.3f}sec")

        # Check termination condition
        if (np.count_nonzero(x) > 0 and Error < 1e-4 * np.sqrt(n)) or it == itmax:
            # Least squares refinement
            if not callable(A):
                T = np.flatnonzero(np.abs(x) >= 1e-3)
                if T.size > 0:
                    B        = A[:, T]
                    x_ref    = np.zeros(n, dtype=float)
                    lst      = np.linalg.lstsq(B, b, rcond=None)
                    x_ref[T] = lst[0]
                    x        = x_ref

            # Set small signals to zero
            x[np.abs(x) < thresh_zero] = 0.0

            # Calculate return results
            Axb = Ax(A, x) - b
            out = {
                'sol':   x,
                'sp':    int(np.count_nonzero(x)),
                'iter':  it,
                'time':  time.perf_counter() - t_start,
                'obj':   0.5 * np.dot(Axb, Axb),
                'error': float(np.linalg.norm(AT(A, data, Axb)) **2),
            }
            return out

        # Calculate threshold and sparsity
        sx = np.sort(np.abs(x))[::-1]
        idx_cut = min(i0 - 1, sx.size - 1) if sx.size > 0 else 0
        eps2    = max(1e-3, sx[idx_cut] if sx.size > 0 else 1e-3)

        if 's' in pars:
            s = int(pars['s'])
        else:
            s = sparsity(sx, rate)

        # Update weights and mu
        theta = 1.005 * theta
        w     = mod_weight(x, np.abs(dx), theta, s, eps2)

        beta  = np.sum(w0 * np.abs(x)) / max(np.sum(w * np.abs(x)), 1e-16)
        if (beta > 1) or (np.count_nonzero(x) == 0):
            mu = 0.2 * mu
        else:
            mu = beta * mu

    # Final processing
    x[np.abs(x) < thresh_zero] = 0.0

    Axb = Ax(A, x) - b
    out = {
        'sol':   x,
        'sp':    int(np.count_nonzero(x)),
        'iter':  itmax,
        'time':  time.perf_counter() - t_start,
        'obj':   0.5 * np.dot(Axb, Axb),
        'error': float(np.linalg.norm(AT(A, data, Axb))** 2),
    }
    return out


def get_parameters(m, n, mu, opts):
    if n < 1000:
        itmax = 1000
    else:
        itmax = 100
    rate  = 0.7 if np.log(n / m) <= 1 else 1.0 / np.log(n / m)
    rate  = opts.get('rate', rate)
    tol   = opts.get('tol', 1e-4)
    disp  = opts.get('disp', 1)
    i0    = int(np.ceil(m / (4 * np.log(n / m))))
    theta = mu * m / n / 10.0
    return itmax, rate, tol, disp, i0, theta


def mod_weight(x, h, theta, k, eps2):
    n    = x.size
    w    = np.ones(n, dtype=float)
    eps1 = 1e-10

    if k <= 0:
        return 1.0 / (np.abs(x) + eps2)

    if h.size == 0:
        return w
    idx     = np.argsort(-h)
    k       = min(k, n)
    top     = idx[:k]
    rest    = idx[k:]

    denom   = max(np.sum(h[top]), 1e-16)
    val_top = eps1 + theta * np.sum(h[top[1:]]) / denom if k > 1 else eps1 + theta * 0.0
    w[top]  = val_top
    if rest.size > 0:
        w[rest] = eps1 + theta + 1.0 / (np.abs(x[rest]) + eps2)
    return w


def sparsity(sx_desc, rate):
    if sx_desc.size == 0:
        return 0
    target   = rate * np.sum(sx_desc)
    s        = 0
    acc      = 0.0
    for val in sx_desc:
        acc += val
        s   += 1
        if acc >= target:
            break
    return s


def Ax(A, x):
    return A(x) if callable(A) else (A @ x)


def AT(A, data, v):
    if callable(A):
        return data['At'](v)
    else:
        return (v @ A).T


def fx_val(A, x, b):
    r = Ax(A, x) - b
    return 0.5 * float(np.dot(r, r))