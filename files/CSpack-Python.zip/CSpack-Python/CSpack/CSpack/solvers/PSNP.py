import numpy as np
import time
from scipy.sparse.linalg import LinearOperator


def PSNP(data, n, lambda_reg, pars=None):
    """
    This code aims at solving the Lq norm regularized optimization problem:
        min_{x in R^n} 0.5 * ||Ax - b||^2 + lambda * ||x||_q^q,
    where lambda > 0 and q in [0, 1).

    Args:
        data (dict): A dictionary containing the required data.
                     - If A is a matrix: {'A': A_matrix, 'b': b_vector}
                     - If A is a function handle: {'A': A_func, 'b': b_vector, 'At': At_func}
        n (int): The dimension of the solution x (required).
        lambda_reg (float): The penalty parameter lambda (required).
        pars (dict, optional): Optional parameters.
            - 'x0': The starting point for x. Default is a zero vector.
            - 'q': The Lq norm parameter. Default is 0.5.
            - 'cond': Conditional or unconditional Newton method. Default is 1 (conditional).
            - 'show': Whether to display results at each iteration. Default is True.
            - 'maxit': The maximum number of iterations. Default is 2000.
            - 'tol': The tolerance for the stopping condition. Default is 1e-6.

    Returns:
        dict: A dictionary containing the solution, time, iterations, and objective value.
    """
    t0 = time.perf_counter()
    if pars is None:
        pars = {}

    # --- Set up parameters ---
    params = set_parameters(n, lambda_reg, pars)
    sig1, sig2, q, q1, q2, lamq, lamq1, alpha0, cg_tol, cg_it, x0, tol, \
        maxit, newton, show, cond, rate, i0 = params

    # --- Define helper functions and operators ---
    funCS = lambda xT, T, key: func_CS(xT, T, key,  n, data)


    def ProxLq(x_vec, t):
        return prox_lq(x_vec, t, q)

    # --- Initialization ---
    error = np.zeros(maxit)
    x     = x0.copy()
    T     = np.where(x != 0)[0]
    sT    = T.size
    w     = x[T]

    if sT > 0:
        absw     = np.abs(w)
        obj      = funCS(w, T, 'f') + lambda_reg * np.sum(absw ** q)
        grad     = funCS(w, T, 'g')
        grad[T] += lamq * np.sign(w) * (absw ** q1)
    else:
        obj      = funCS(x, np.array([]), 'f')
        grad     = funCS(x, np.array([]), 'g')

    if show:
        solver_name = 'PCSNP' if cond else 'PSNP'
        print(f'\nStart to run the solver -- {solver_name}\n')
        print(' -------------------------------------\n')
        print(' Iter     ObjVal    Sparsity     Time \n')
        print(' -------------------------------------\n')
        print(f'{0:4d}     {obj:5.2e}    {sT:4d}    {time.perf_counter() - t0:6.2f}sec')

    # --- Main Loop ---
    for iter_num in range(1, maxit + 1):
        alpha = alpha0
        Told  = T

        # --- Proximal Gradient Step with Line Search ---
        for i in range(i0):
            w, T  = ProxLq(x - alpha * grad, alpha * lambda_reg)
            absw  = np.abs(w)
            fx    = funCS(w, T, 'f')
            obj_w = fx + lambda_reg * np.sum(absw ** q)

            if T.size == 0 or obj_w < obj - sig1 * np.sum((w - x[T]) ** 2):
                break
            alpha *= rate

        if T.size == 0 and i == i0 - 1:  # Check if loop finished without break
            alpha /= rate
            w, T   = ProxLq(x - alpha * grad, alpha * lambda_reg)
            absw   = np.abs(w)
            fx     = funCS(w, T, n, 'f', data)
            obj_w  = fx + lambda_reg * np.sum(absw ** q)

        x.fill(0)
        x[T]      = w
        obj_old   = obj
        obj       = obj_w
        sT_old    = sT
        sT        = T.size

        ident     = (sT == sT_old and np.array_equal(T, Told))
        switch_on = ident if cond else ((sT < 0.25 * n or ident) and (i != i0 - 1 or iter_num >= 5))

        # --- (Conditional) Newton Step ---
        if newton and sT > 0 and switch_on:
            grad_n, hess_n = funCS(w, T, 'gh')
            gradT          = grad_n[T]

            if q > 0:
                gradT += lamq * np.sign(w) * (absw ** q1)
                dw     = lamq1 * (absw ** q2)
                if isinstance(hess_n, LinearOperator):
                    # to prevent the lambda from recursively calling the new operator.
                    hess_n = LinearOperator(hess_n.shape, matvec=lambda v, op=hess_n: op.matvec(v) + dw * v)
                else:
                    np.fill_diagonal(hess_n, hess_n.diagonal() + dw)

            if isinstance(hess_n, LinearOperator):
                if iter_num > 10:
                    cg_tol = max(cg_tol / 10, 1e-15 * sT)
                    cg_it  = min(cg_it + 5, 25)
                d = my_cg(hess_n, gradT, cg_tol, cg_it, np.zeros(sT))
            else:
                try:
                    d = np.linalg.solve(hess_n, gradT)
                except np.linalg.LinAlgError:
                    d = my_cg(hess_n, gradT, cg_tol, cg_it, np.zeros(sT))

            beta       = 1.0
            fd_norm_sq = np.sum(d ** 2)
            for _ in range(5):
                v     = w - beta * d
                absv  = np.abs(v)
                fx_v  = funCS(v, T, 'f')
                obj_v = fx_v + lambda_reg * np.sum(absv ** q)

                if obj_v <= obj - sig2 * beta ** 2 * fd_norm_sq:
                    x[T], w, absw, obj = v, v, absv, obj_v
                    break
                beta *= 0.25

        # --- Update Gradient and Check Stopping Criteria ---
        grad  = funCS(w, T, 'g')
        gradT = grad[T]
        if q > 0 and w.size > 0:
            gradT += lamq * np.sign(w) * (absw ** q1)

        if iter_num > 1 and T.size == 0:
            err_grad_T  = 1e10
            lambda_reg /= 1.5
            lamq        = lambda_reg * q
            lamq1       = lamq * q1
        else:
            err_grad_T  = np.linalg.norm(gradT, np.inf) if gradT.size > 0 else 0

        err_obj             = abs(obj - obj_old) / (1 + abs(obj))
        error[iter_num - 1] = err_grad_T / np.sqrt(n) if n > 0 else err_grad_T

        if show:
            print(f'{iter_num:4d}     {obj:5.2e}    {sT:4d}    {time.perf_counter() - t0:6.2f}sec')

        is_large_func = (n > 5e4 and callable(data.get('A')))
        if (is_large_func or ident) and max(error[iter_num - 1], err_obj) < tol:
            break

    return {
        'time': time.perf_counter() - t0,
        'iter': iter_num,
        'sol': x,
        'obj': obj,
        'error': np.sum(grad ** 2)
    }


def set_parameters(n, lambda_reg, pars):
    """Set up parameters for the PSNP solver."""
    x0     = pars.get('x0', np.zeros(n))
    q      = pars.get('q', 0.5)
    tol    = pars.get('tol', 1e-6)
    maxit  = int(pars.get('maxit', 2000))
    newton = pars.get('newton', 1)
    show   = pars.get('show', True)
    cond   = pars.get('cond', 1)

    sig1   = 1e-6
    sig2   = 1e-10
    q1     = q - 1
    q2     = q - 2
    lamq   = lambda_reg * q
    lamq1  = lamq * q1

    alpha0 = 1 - q / 2
    cg_tol = 1e-8
    cg_it  = 10
    rate   = 0.5
    i0     = 6

    return sig1, sig2, q, q1, q2, lamq, lamq1, alpha0, cg_tol, cg_it, \
        x0, tol, maxit, newton, show, cond, rate, i0


def func_CS(xT, T, key, n, data):
    """Calculates objective, gradient, and Hessian for the CS problem part."""
    A, b      = data['A'], data['b']
    is_A_func = callable(A)
    At        = data.get('At')

    if At is None and not is_A_func:
        At = lambda v: A.T @ v
    elif At is None and is_A_func:
        raise ValueError("data['At'] must be provided when data['A'] is a function.")

    if T.size == 0:
        Axb  = -b
        if key == 'f':
            return 0.5 * (Axb @ Axb)
        grad = At(Axb)
        return (grad, None) if key == 'gh' else grad
    else:
        if not is_A_func:
            if T.size <= 0.025*n:
                Axb  = A[:, T] @ xT - b
            else:
                x_full     = np.zeros(n)
                x_full [T] = xT
                Axb        = A @ x_full  - b
        else:
            x_full     = np.zeros(n)
            x_full [T] = xT
            Axb        = A(x_full ) - b

        if key == 'f':
            return 0.5 * (Axb @ Axb)

        grad = At(Axb)
        if key == 'gh':
            sT = T.size
            if not is_A_func:
                if sT < 1000 and A.shape[0] < 1000:
                    hess = A[:, T].T @ A[:, T]
                else:
                    AT   = A[:, T]
                    hess = LinearOperator((sT, sT), matvec=lambda v: AT.T @ (AT @ v))
            else:
                def hess_matvec(v):
                    v_full    = np.zeros(n)
                    v_full[T] = v
                    return At(A(v_full))[T]
                hess = LinearOperator((sT, sT), matvec=hess_matvec)
            return grad, hess
        return grad


def prox_lq(a, lam, q):
    """Proximal operator for Lq norm."""
    if q == 0:
        t  = np.sqrt(2 * lam)
        T  = np.where(np.abs(a) > t)[0]
        px = a[T]
    elif q == 0.5:
        t  = (1.5) * (lam ** (2 / 3))
        T  = np.where(np.abs(a) > t)[0]
        if T.size == 0:
            return np.array([]), T
        aT  = a[T]
        phi = np.arccos((lam / 4) * (3. / (np.abs(aT) + 1e-12)) ** (1.5))
        px  = (4 / 3) * aT * (np.cos((np.pi - phi) / 3)) ** 2
    elif q == 2 / 3:
        t = 2 * (2 * lam / 3) ** (0.75)
        T = np.where(np.abs(a) > t)[0]
        if T.size == 0:
            return np.array([]), T
        aT                     = a[T]
        tmp1                   = aT ** 2 / 2
        radicand               = tmp1 ** 2 - (8 * lam / 9) ** 3
        radicand[radicand < 0] = 0
        tmp2                   = np.sqrt(radicand)
        phi_term               = np.cbrt(tmp1 + tmp2) + np.cbrt(tmp1 - tmp2)

        phi                          = phi_term + 1e-12
        px_radicand                  = 2 * np.abs(aT) / np.sqrt(phi) - phi
        px_radicand[px_radicand < 0] = 0

        px                           = np.sign(aT) / 8. * (np.sqrt(phi) + np.sqrt(px_radicand)) ** 3
    else:
        px, T = newton_lq(a, lam, q)
    return px, T


def newton_lq(a, alam, q):
    """Newton method for the proximal of Lq norm."""
    if q >= 1 or q < 0:
        raise ValueError("q must be in [0, 1)")
    if alam <= 0:
        raise ValueError("lambda must be positive")

    # The threshold below which the solution is zero
    thresh = (2 - q) * alam ** (1 / (2 - q)) * (2 * (1 - q)) ** ((1 - q) / (q - 2))
    T = np.where(np.abs(a) > thresh)[0]

    if T.size > 0:
        zT          = a[T]
        w           = zT.copy()
        q1, q2      = q - 1, q - 2
        lamq, lamq1 = alam * q, alam * q * q1
        for _ in range(100):
            absw    = np.abs(w) + 1e-12  # Add epsilon for stability
            g       = w - zT + lamq * np.sign(w) * (absw ** q1)
            if np.linalg.norm(g) < 1e-8:
                break

            h      = 1 + lamq1 * (absw ** q2)
            d      = -g / h

            alpha  = 1.0
            w0     = w.copy()
            fx_ref = 0.5 * np.sum((w0 - zT) ** 2) + alam * np.sum(np.abs(w0) ** q)

            for _ in range(10):  # Backtracking line search
                w       = w0 + alpha * d
                fx_cand = 0.5 * np.sum((w - zT) ** 2) + alam * np.sum(np.abs(w) ** q)

                if fx_cand < fx_ref - 1e-4 * alpha * np.sum(d ** 2):
                    break
                alpha  *= 0.5
        return w, T
    else:
        return np.array([]), np.array([], dtype=int)


def my_cg(A, b, tol=1e-8, max_iter=10, x0=None):
    """A simple conjugate gradient solver."""
    x      = np.zeros_like(b) if x0 is None else x0.copy()

    r      = b - A(x)
    p      = r.copy()
    rs_old = r @ r

    for _ in range(max_iter):
        if np.sqrt(rs_old) < tol:
            break

        Ap     = A(p)
        alpha  = rs_old / (p @ Ap)
        x     += alpha * p
        r     -= alpha * Ap
        rs_new = r @ r

        p      = r + (rs_new / rs_old) * p
        rs_old = rs_new

    return x