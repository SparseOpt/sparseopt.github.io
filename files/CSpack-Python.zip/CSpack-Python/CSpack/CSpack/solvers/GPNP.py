from __future__ import annotations
import time
from typing import Callable, Dict, Optional, Tuple, Union
import numpy as np

try:
    from scipy.sparse import issparse, csr_matrix
except Exception:
    issparse = None  # type: ignore

Array    = np.ndarray
LinOp    = Union[Array, Callable[[Array], Array]]
DataDict = Dict[str, object]


def GPNP(data: DataDict, n: int, s: int, pars: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    r"""
    Solve:  min_x 0.5*||A x - b||^2,  s.t. ||x||_0 <= s
    data:
      - matrix form: {'A': A (m,n), 'b': b (m,)} (A can be ndarr or scipy.sparse)
      - operator form: {'A': Ax(x)->Ax, 'At': AT(y)->A^T y, 'b': b (m,), 'n': n}
    n: dimension, s: sparsity level
    pars: optional dict {'x0','disp','maxit','tol','obj'}
    returns dict: {'sol','obj','sp','iter','time','error'}
    """
    t0 = time.perf_counter()

    if not isinstance(data, dict) or ('A' not in data) or ('b' not in data):
        raise ValueError("data must be a dict and contain 'A' and 'b'.")
    A     = data['A']
    b     = np.asarray(data['b'], dtype=np.float64).ravel()
    funhd = callable(A)
    if funhd and ('At' not in data):
        raise ValueError("<data['At']> is missing for operator form.")
    m     = b.size

    pars  = {} if pars is None else dict(pars)
    x0, sigma, J, flag, m_chk, alpha0, gamma, thd, disp, tol, tolF, maxit = _set_parameters(s, n, b, pars)

    Fnorm   = lambda v: float(np.dot(v, v))            # squared 2-norm
    support = lambda subx, T: _support(subx, n, T)     # construct n-dim vector from subset
    x       = np.asarray(x0, dtype=np.float64).ravel()

    if funhd:
        funAv: Callable[[Array], Array] = data['A']
        At_obj = data['At']
        if callable(At_obj):
            funAtv = lambda v: At_obj(np.asarray(v, dtype=np.float64).ravel())
        else:
            funAtv = lambda v: np.asarray(At_obj, dtype=np.float64) @ v
        OBJ = np.zeros(3, dtype=np.float64)

        # subH(z, T) = [A^T A (e_T z)]_T
        def subH(z: Array, T: Array) -> Array:
            vec    = np.zeros(n, dtype=np.float64)
            vec[T] = z
            return funAtv(funAv(vec))[T]
    else:
        A_mat = A
        is_sp = (issparse is not None) and issparse(A_mat)  # type: ignore
        if is_sp:
            A_mat = A_mat.tocsr()  # type: ignore
        else:
            A_mat = np.asarray(A_mat, dtype=np.float64, order='C')

        def funAv_sub(v: Array, v_sub: Array, T: Array) -> Array:
            if len(T) >= 0.025 * n:
                return A_mat @ v - b
            else:
                if len(T) == 0:
                    return -b
                else:
                    return A_mat[:, T] @ v_sub - b

        if 'At' in data and data['At'] is not None:
            At_obj = data['At']
            if callable(At_obj):
                funAtv = lambda v: At_obj(np.asarray(v, dtype=np.float64).ravel())
            else:
                At_arr = np.asarray(At_obj, dtype=np.float64, order='C')
                funAtv = lambda v: At_arr @ v
        else:
            funAtv = (lambda v: (A_mat.T.dot(v) if is_sp else A_mat.T @ v))
        OBJ = np.zeros(5, dtype=np.float64)

    gx        = funAtv(b)
    Atb       = gx.copy()
    fx        = Fnorm(b)
    Tu_init   = _top_s(np.abs(gx), s)
    Tx        = np.sort(Tu_init)

    minobj    = np.zeros(maxit + 1, dtype=np.float64)
    minobj[0] = fx
    xmin      = x.copy()
    fmin      = fx

    if disp:
        print("\n Start to run the solver -- GPNP ")
        print(" -------------------------------------")
        print(" Iter          ObjVal         CPUTime ")
        print(" -------------------------------------")

    for iter_idx in range(1, maxit + 1):
        alpha = alpha0
        for _ in range(J):
            vec  = x - alpha * gx
            Tu   = _top_s(np.abs(vec), s)
            Tu.sort()
            subu = vec[Tu]
            u    = support(subu, Tu)

            if funhd:
                Aub = funAv(u) - b
            else:
                Aub = funAv_sub(u,subu, Tu)

            fu    = Fnorm(Aub)
            if fu < fx - sigma * Fnorm(u - x):
                break
            alpha *= gamma

        gx    = funAtv(Aub)
        normg = Fnorm(gx)
        x     = u
        fx    = fu

        sT    = Tu
        mark  = np.array_equal(sT, Tx)
        Tx    = sT.copy()
        eps   = 1e-4

        if (mark or normg < 1e-4 or alpha0 == 1) and (s <= 5e4):
            if funhd:
                cgit  = min(25, 5 * iter_idx)
                cgtol = max(1e-6 / (iter_idx**2), 1e-20)
                subv  = _my_cg(lambda z: subH(z, Tu), Atb[Tu], cgtol, cgit, np.zeros(s, dtype=np.float64))
            else:
                ATu   = (A_mat[:, Tu] if is_sp else A_mat[:, Tu])
                if s <= 500 and m <= 10000:
                    subv = _lstsq(ATu, b)
                    eps  = 1e-10
                else:
                    if is_sp:
                        cgit = 30 + (s / n >= 0.05) * 20 + (s / n >= 0.1) * 20
                    else:
                        cgit = min(20, 2 * iter_idx)
                    cg_func  = (lambda v, ATu=ATu: ATu.T.dot(ATu.dot(v)) if is_sp else ATu.T @ (ATu @ v))
                    subv     = _my_cg(cg_func, Atb[Tu], 1e-20, int(cgit), np.zeros(s, dtype=np.float64))
            v = support(subv, Tu)

            if funhd:
                Avb = funAv(v) - b
            else:
                Avb = funAv_sub(v,subv, Tu)
            fv = Fnorm(Avb)

            if fv <= fu - sigma * Fnorm(subu - subv):
                x     = v
                fx    = fv
                subu  = subv
                gx    = funAtv(Avb)
                normg = Fnorm(gx)

        error = Fnorm(gx[Tu]) if Tu.size else 0.0
        obj   = np.sqrt(fx)
        OBJ   = np.concatenate([OBJ[1:], np.array([obj])])

        if disp:
            print(f"{iter_idx:4d}          {fx:5.2e}      {time.perf_counter() - t0:6.3f}sec")

        maxg  = float(np.max(np.abs(gx))) if gx.size else 0.0
        minx  = float(np.min(np.abs(subu))) if subu.size else 0.0
        J     = 8
        if (error < tol * 1e3) and (normg > 1e-2) and (iter_idx < maxit - 10) and (minx > 0.0):
            J = int(min(8, max(1, np.ceil(maxg / minx) - 1)))

        if ('obj' in pars) and (obj <= tolF) and flag:
            maxit = int(iter_idx + 100 * s / n)
            flag  = 0

        minobj[iter_idx] = min(minobj[iter_idx - 1], fx)
        if fx < minobj[iter_idx - 1]:
            xmin = x.copy()
            fmin = fx

        if iter_idx > thd:
            window = minobj[(iter_idx - thd):(iter_idx + 1)]
            count  = (np.std(window) < 1e-10)
        else:
            count  = False

        if (normg < tol) or (fx < tolF) or count or (np.std(OBJ) < eps * (1.0 + obj)):
            if count and (fmin < fx):
                x  = xmin
                fx = fmin
            break

    out = {
        'sol': x.copy(),
        'obj': float(fx),
        'sp': int(np.count_nonzero(x)),
        'iter': int(iter_idx),
        'time': float(time.perf_counter() - t0),
        'error': float(normg),
    }
    return out


# ----------------------- helpers -----------------------

def _top_s(abs_vec: Array, s: int) -> Array:
    """Return indices of top-s by absolute value using argpartition (O(n))."""
    n = abs_vec.size
    if s <= 0:
        return np.empty(0, dtype=np.int64)
    if s >= n:
        return np.arange(n, dtype=np.int64)
    idx = np.argpartition(-abs_vec, s - 1)[:s]
    return idx.astype(np.int64, copy=False)


def _support(x_subset: Array, n: int, T: Array) -> Array:
    """Create n-dim vector whose entries on T are x_subset; rest zeros."""
    z = np.zeros(n, dtype=np.float64)
    if T.size:
        z[T] = x_subset
    return z


def _set_parameters(s: int, n: int, b: Array, pars: Dict[str, object]):
    sigma = 1e-4
    J     = 1
    m     = int(len(b))
    flag  = 1

    if (m / n >= 1.0 / 6.0) and (s / n <= 0.05) and (n >= 1e4):
        alpha0, gamma = 1.0, 0.1
    else:
        alpha0, gamma = 5.0, 0.5

    sn   = s / n
    tmp  = 500 * (sn > 0.1) + 200 * (sn > 0.075) + 100 * (sn > 0.05) + 20 * (sn > 0.025) + 5 * (sn <= 0.025)
    thd  = int(np.ceil(np.log2(2 + s) * tmp))

    x0   = np.asarray(pars.get('x0', np.zeros(n, dtype=np.float64)), dtype=np.float64).ravel()
    disp = int(pars.get('disp', 1))
    tol  = float(pars.get('tol', 1e-10))
    tolF = float(pars.get('obj', 1e-20))

    if 'maxit' in pars:
        maxit = int(pars['maxit'])
    else:
        maxit = int((n <= 1e4) * 2e4 + (n > 1e4) * 5e3)

    return x0, sigma, J, flag, m, alpha0, gamma, thd, disp, tol, tolF, maxit


def _my_cg(fx: Union[Array, Callable[[Array], Array]],
           b: Array, cgtol: float, cgit: int, x0: Array) -> Array:
    """Conjugate Gradient on linear operator fx (callable or matrix)."""
    if callable(fx):
        op = fx
    else:
        M  = np.asarray(fx, dtype=np.float64)
        op = lambda v: M @ v

    x = x0.copy()
    r = b - op(x) if np.count_nonzero(x) else b.copy()
    e = float(np.dot(r, r))
    t = e
    p = r.copy()
    for _ in range(int(cgit)):
        if e < cgtol * t:
            break
        w  = op(p)
        pw = float(np.dot(p, w))
        if pw == 0.0:
            break
        a  = e / pw
        x += a * p
        r -= a * w
        e0 = e
        e  = float(np.dot(r, r))
        p  = r + (e / e0) * p
    return x


def _lstsq(A_sub, b: Array) -> Array:

    if (issparse is None) or (not issparse(A_sub)):  # type: ignore
        A_sub = np.asarray(A_sub, dtype=np.float64, order='C')
        return np.linalg.lstsq(A_sub, b, rcond=None)[0]

    A_sub = A_sub.tocsr()  # type: ignore
    rhs   = A_sub.T.dot(b)

    def Hop(v):
        return A_sub.T.dot(A_sub.dot(v))

    x0 = np.zeros(A_sub.shape[1], dtype=np.float64)
    return _my_cg(Hop, rhs, 1e-12, 200, x0)