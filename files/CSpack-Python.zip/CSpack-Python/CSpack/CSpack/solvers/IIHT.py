import numpy as np
import time

def IIHT(data, n, s, pars=None):
    r"""
    This code aims to solve the sparsity-constrained Compressed Sensing (CS) problem:
        min_{x in R^n} 0.5 * ||Ax - b||^2,  s.t. ||x||_0 <= s,
    or the sparsity and non-negative constrained problem:
        min_{x in R^n} 0.5 * ||Ax - b||^2,  s.t. ||x||_0 <= s, x >= 0.

    Args:
        data (dict): A dictionary containing the required data.
                     - If A is a matrix: {'A': A_matrix, 'b': b_vector}
                     - If A is a function handle: {'A': A_func, 'b': b_vector, 'At': At_func}
        n (int): The dimension of the solution x (required).
        s (int): The sparsity level of x, an integer between 1 and n-1 (required).
        pars (dict, optional): Optional parameters.
            - 'neg': bool, whether to enforce the non-negative constraint (x>=0). Default is False.
            - 'x0': The starting point for x (not used in this algorithm, but kept for interface consistency).
            - 'disp': bool, whether to display results at each iteration. Default is True.
            - 'maxit': int, the maximum number of iterations. Default is 5000.
            - 'tol': float, the tolerance for the stopping condition. Default is 1e-6 * sqrt(n).

    Returns:
        dict: A dictionary containing the solution, objective value, sparsity, time, number of iterations, and error.
    """
    if not isinstance(data, dict) or 'A' not in data or 'b' not in data:
        print("<data.A> or <data.b> is missing, unable to run the solver...")
        return None
    if callable(data.get('A')) and 'At' not in data:
        print("When A is a function, <data.At> must be provided, unable to run the solver...")
        return None

    if pars is None:
        pars = {}

    disp  = pars.get('disp', True)
    maxit = pars.get('maxit', 5000)
    tol   = pars.get('tol', 1e-6 * np.sqrt(n))
    neg   = pars.get('neg', False)  # Using a boolean is more Pythonic

    data['n'] = n

    def func(x):
        return compressed_sensing(x, data)

    t0     = time.perf_counter()  # Record the start time
    sigma0 = 1e-4

    # Initialize x vector. 'xo' in the MATLAB code is always a zero vector, so it's optimized away here.
    x      = np.zeros(n)

    if disp:
        print(' \n Starting solver -- IIHT \n')
        print(' -------------------------------------\n')
        print(' Iter          ObjVal         CPUTime \n')
        print(' -------------------------------------\n')

    # --- Initialize Objective Value and Gradient ---
    f, g         = func(x)
    scale_factor = n if max(f, np.linalg.norm(g)) > n else 1.0
    fs           = f / scale_factor
    gs           = g / scale_factor

    for iter_num in range(1, maxit + 1):

        x_old  = x.copy()
        fx_old = fs

        alpha  = np.sqrt(iter_num)  # Initial step size
        for _ in range(15):
            tp = x_old - alpha * gs

            # --- Hard Thresholding Step ---
            if neg:  # If there is a non-negative constraint
                tp[tp < 0] = 0
                T          = np.argpartition(-tp, s)[:s]
            else:
                T          = np.argpartition(-np.abs(tp), s)[:s]

            mx   = tp[T]
            x    = np.zeros(n)
            x[T] = mx

            fs_new, _ = func(x)
            fs        = fs_new / scale_factor

            # Armijo-like line search condition
            if fs < fx_old - 0.5 * sigma0 * np.sum((x - x_old) ** 2):
                break  # Step size condition is met, exit the line search
            alpha /= 2.0  # Reduce the step size

        # Using the final x found, recalculate the objective value and gradient
        f, g = func(x)
        fs   = f / scale_factor
        gs   = g / scale_factor

        # --- Stopping Criteria ---
        # Calculate the residual. Note that gs[T] and mx come from different calculation steps but correspond to the same support set T.
        norm_gs_T = np.linalg.norm(gs[T])
        norm_mx   = np.linalg.norm(mx)
        residual  = scale_factor * norm_gs_T / max(1.0, norm_mx)

        if disp:  # In MATLAB, mod(iter,1)==0 is always true, simplified here.
            print(f'{iter_num:4d}          {fs * scale_factor:5.2e}      {time.perf_counter() - t0:6.3f}sec')

        # Stop if the residual is small enough, or if the change in the objective function is negligible.
        if residual < tol or abs(fs - fx_old) < 1e-12 * (1 + abs(fs)):
            break

    # --- Output Results ---
    return {
        'sol': x,
        'obj': fs * scale_factor,
        'iter': iter_num,
        'time': time.perf_counter() - t0,
        'sp': np.count_nonzero(x),
        'error': np.linalg.norm(g) ** 2
    }


def compressed_sensing(x, data):
    """
    Calculates the objective function value and gradient for the compressed sensing problem.

    Args:
        x (np.ndarray): The current solution vector.
        data (dict): A dictionary containing the matrix A, its transpose At, and the vector b.

    Returns:
        tuple: (objective value, gradient vector)
    """
    A = data['A']
    b = data['b']

    # --- Branch 1: A is a function handle (callable) ---
    if callable(A):
        At        = data['At']
        Axb       = A(x) - b
        # Objective value: 0.5 * ||Ax - b||^2
        objective = 0.5 * (Axb @ Axb)  # Using inner product is faster than np.sum(Axb**2)
        # Gradient: A^T * (Ax - b)
        gradient  = At(Axb)
        return objective, gradient

    else:
        # Optimization: For a sparse x, use only non-zero elements for matrix multiplication.
        Tx = np.where(x != 0)[0]
        if Tx.size == 0:
            Axb   = -b
        else:
            if Tx.size < 0.025*len(x):
                Axb   = A[:, Tx] @ x[Tx] - b
            else:
                Axb = A @ x - b


        # Objective value
        objective = 0.5 * (Axb @ Axb)
        # Gradient
        gradient  = A.T @ Axb
        return objective, gradient