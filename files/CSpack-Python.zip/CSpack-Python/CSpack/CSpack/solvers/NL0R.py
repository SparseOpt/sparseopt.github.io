from __future__ import annotations
import time
from typing import Callable, Dict, Optional, Tuple, Union
import numpy as np

try:
    import scipy.sparse as sp
except Exception:
    sp = None  # Allow running without scipy environment（but only for dense matrix A）

Array    = np.ndarray
LinOp    = Union[Array, Callable[[Array], Array]]
DataDict = Dict[str, object]


def NL0R(data: DataDict, n: int, lam: float, pars: Optional[Dict[str, object]] = None) -> Dict[str, object]:
    r"""
    Solve:  min_x  0.5*||A x - b||^2 + λ ||x||_0,  with iterative λ update.
    data:
      - matrix form: {'A': A (m,n), 'b': b (m,)}  or  sparse A (scipy.sparse)
      - operator form: {'A': Ax(x)->Ax, 'At': AT(y)->A^T y, 'b': b (m,), 'n': n}
    n: dimension of x
    lam: initial lambda
    pars (optional):
      x0, tau, rate, disp, maxit, tol, obj
    Returns dict: sol, sp, time, iter, obj, error
    """
    t0 = time.time()
    if data is None or 'A' not in data or 'b' not in data:
        raise ValueError("data must contain 'A' and 'b'")

    A = data['A']
    b = np.asarray(data['b'], dtype=np.float64).ravel()

    # curry the objective/grad/hess subroutines
    def func(x: Array, T1: Optional[Array], T2: Optional[Array]) -> Tuple[object, Optional[object]]:
        return CS(x, T1, T2, data)

    pars  = pars or {}
    rate0 = 0.5 if n <= 1_000 else 1.0 / np.exp(3.0 / np.log10(n))
    tau0  = 1.0 if n <= 1_000 else 0.5

    x     = np.asarray(pars.get('x0', np.zeros(n, dtype=np.float64)), dtype=np.float64).ravel()
    if x.size != n:
        raise ValueError("x0 size mismatch")

    tau   = float(pars.get('tau', tau0))
    rate  = float(pars.get('rate', rate0))
    disp  = int(pars.get('disp', 1))
    itmax = int(pars.get('maxit', 2000))
    pobj  = float(pars.get('obj', 1e-20))
    tol   = float(pars.get('tol', 1e-10))

    Err   = np.zeros(itmax, dtype=np.float64)
    Obj   = np.zeros(itmax, dtype=np.float64)
    Nzx   = np.zeros(itmax, dtype=np.int64)
    FNorm = lambda v: float(np.dot(v, v))  # squared 2-norm

    if disp:
        print("\n Start to run the solver -- NL0R")
        print(" -------------------------------------")
        print(" Iter     ObjVal    Sparsity     Time ")
        print(" -------------------------------------")

    # Initial check
    obj, g = func(x, None, None)
    g      = np.asarray(g, dtype=np.float64).ravel()
    if FNorm(g) == 0.0:
        if disp:
            print("Starting point is a good stationary point, stop !!!")
        return {
            'sol': x.copy(),
            'sp': int(np.count_nonzero(x)),
            'time': time.time() - t0,
            'iter': 0,
            'obj': float(obj),
            'error': 0.0,
        }
    else:
        maxlam = (np.max(np.abs(g)) ** 2) * tau / 2.0

    if np.isnan(g).any():
        x.fill(0.0)
        x[np.random.randint(0, n)] = np.random.rand()
        obj, g = func(x, None, None)
        g = np.asarray(g, dtype=np.float64).ravel()

    pcgit  = 5
    pcgtol = 1e-5
    beta   = 0.5
    sigma  = 5e-5
    delta  = 1e-10
    T0     = np.array([], dtype=np.int64)
    nx     = 0

    # Main loop
    for it in range(itmax):
        x0  = x.copy()
        xtg = x0 - tau * g
        # thresholding support
        T   = np.flatnonzero(np.abs(xtg) > np.sqrt(2.0 * tau * lam))
        nT  = T.size

        # heuristic support refinement (SparseApprox)
        if nT > max(0.12, 0.2 / np.log2(1 + (it + 1))) * n:
            Tnew   = SparseApprox(xtg[T], T)
            nTnew  = Tnew.size
            if nTnew > 0 and (nT / nTnew) < 20:
                T  = Tnew
                nT = nTnew

        # TTc = T0 \cap complement(T)
        TTc               = np.setdiff1d(T0, T, assume_unique=False)
        flag_same_support = (TTc.size == 0)

        # Stopping criteria metrics
        FxT               = np.sqrt(FNorm(g[T]) + (FNorm(x[TTc]) if TTc.size else 0.0))
        Err[it]           = FxT / np.sqrt(n)
        Nzx[it]           = nx

        if disp:
            print(f"{it+1:4d}     {obj:5.2e}    {nT:4d}    {time.time()-t0:6.2f}sec")

        # stopping conditions
        stop0 = (it > 0 and abs(obj - Obj[it-1]) < 1e-6 * (1.0 + obj))
        stop1 = (Err[it] < tol and nx == nT and stop0 and flag_same_support)
        stop2 = (it > 3 and obj < pobj and nx <= np.ceil(n / 4))
        if it >= 9:
            e = Err[it-9:it+1]
            o = Obj[it-9:it+1]
            k = Nzx[it-9:it+1]
            stop3 = (
                np.std(k) <= 0 and
                (np.std(e) ** 2) <= np.min(e) and
                (np.std(o) ** 2) <= np.min(o[:-1])
            )
        else:
            stop3 = False
        stop4 = (np.linalg.norm(g) < tol and nx <= np.ceil(n / 4))
        if stop1 or stop2 or stop3 or stop4:
            break

        # update direction on support
        if it == 0 or flag_same_support:
            H   = func(x0, T, None)[0]  # H(T,T)
            d   = solve_on_support(H, -g[T], pcgtol, pcgit)
            dg  = float(np.dot(d, g[T]))
            ngT = FNorm(g[T])
            if (dg > max(-delta * FNorm(d), -ngT)) or np.isnan(dg):
                d  = -g[T].copy()
                dg = ngT
        else:
            H, D   = func(x0, T, TTc)  # H(T,T) and D(T,TTc)
            rhs    = apply_D(D, x0[TTc]) - g[T]
            d      = solve_on_support(H, rhs, pcgtol, pcgit)

            Fnz    = FNorm(x[TTc]) / (4.0 * tau) if TTc.size else 0.0
            dgT    = float(np.dot(d, g[T]))
            dg     = dgT - float(np.dot(x0[TTc], g[TTc])) if TTc.size else dgT

            delta0 = 1e-4 if (Fnz > 1e-4) else delta
            ngT    = FNorm(g[T])
            if (dgT > max(-delta0 * FNorm(d) + Fnz, -ngT)) or np.isnan(dg):
                d  = -g[T].copy()
                dg = ngT

        # Armijo backtracking
        alpha = 1.0
        obj0  = obj
        x     = np.zeros_like(x0)
        for _ in range(6):
            x[T]   = x0[T] + alpha * d
            obj    = float(func(x, None, None)[0])
            if obj < obj0 + alpha * sigma * dg:
                break
            alpha *= beta

        T0      = T.copy()
        obj, g  = func(x, None, None)
        g       = np.asarray(g, dtype=np.float64).ravel()
        Obj[it] = float(obj)

        # Update tau
        if (it + 1) % 10 == 0:
            OBJ = Obj[it-9:it+1]
            if (Err[it] > 1.0 / (it + 1) ** 2) or (np.count_nonzero(OBJ[1:] > 1.5 * OBJ[:-1]) >= 2):
                tau = tau / (1.25 if (it + 1) < 1500 else 1.5)
            else:
                tau = tau * 1.25

        # Update lambda
        nx = int(np.count_nonzero(x))
        if (it + 1) > 5 and (nx > 2 * int(np.max(Nzx[:it+1-1]) if it >= 1 else 0)) and (Err[it] < 1e-2):
            rate0  = 2.0 / rate
            x      = x0  # rollback
            nx     = int(np.count_nonzero(x0))
            nx0    = Nzx[it-1]
            obj, g = func(x, None, None)
            g      = np.asarray(g, dtype=np.float64).ravel()
            rate   = 1.1
        else:
            rate0  = rate

        if 'nx0' in locals() and nx < nx0:
            rate0  = 1.0

        lam = min(maxlam, lam * (2.0 * (nx >= 0.1 * n) + rate0))

    # Results
    sol     = np.zeros(n, dtype=np.float64)
    sol[T0] = x[T0]
    obj, g  = func(sol, None, None)
    out     = {
        'sol': sol,
        'sp': int(np.count_nonzero(sol)),
        'time': time.time() - t0,
        'iter': it,
        'obj': float(obj),
        'error': FNorm(np.asarray(g, dtype=np.float64).ravel()),
    }
    return out


# ---------- Helpers ----------

def SparseApprox(xT: Array, T: Array) -> Array:
    xabs = np.abs(np.asarray(xT, dtype=np.float64)).ravel()
    nz   = xabs[xabs != 0.0]
    if nz.size == 0:
        return np.array([], dtype=np.int64)
    sx   = np.sort(nz)  # ascending
    if sx.size <= 2:
        th = sx[-1]
    else:
        ratio   = sx[1:] / sx[:-1]
        nr      = np.linalg.norm(ratio)
        ratio_n = ratio / (nr if nr > 0 else 1.0)  # normalize
        itmax   = int(np.argmax(ratio_n))
        mx      = ratio_n[itmax]
        if (mx > 10.0) and (itmax + 1 > 1):
            th  = sx[itmax + 1]
        else:
            th  = 0.0
    # select indices in T whose |x| > th
    take = np.abs(xT).ravel() > th
    return T[take]


def as_linear_operator(H: Union[Array, Callable[[Array], Array]]) -> Callable[[Array], Array]:
    if callable(H):
        return H
    mat = np.asarray(H, dtype=np.float64)
    if sp is not None and sp.issparse(mat):
        return lambda v: mat @ v
    else:
        return lambda v: mat @ v


def solve_on_support(H: Union[Array, Callable[[Array], Array]],
                      rhs: Array, cgtol: float, cgit: int) -> Array:
    """Solve H d = rhs using direct solve if ndarray small, otherwise CG."""
    if callable(H):
        return my_cg(H, rhs, cgtol, cgit, np.zeros_like(rhs))
    else:
        H = np.asarray(H, dtype=np.float64)
        s = H.shape[0]
        if s <= 1000:
            return np.linalg.solve(H, rhs)
        else:
            Hop = lambda v: H @ v
            return my_cg(Hop, rhs, cgtol, cgit, np.zeros_like(rhs))


def apply_D(D: Union[Array, Callable[[Array], Array]], v: Array) -> Array:
    if callable(D):
        return D(v)
    else:
        return np.asarray(D, dtype=np.float64) @ v



def my_cg(fx: Union[Array, Callable[[Array], Array]],
           b: Array, cgtol: float, cgit: int, x0: Array) -> Array:
    """Conjugate gradient on linear operator fx (callable or matrix)."""
    op = as_linear_operator(fx)
    x = x0.copy()
    r = b - op(x) if np.count_nonzero(x) else b.copy()
    e = float(np.dot(r, r))
    t = e
    p = r.copy()
    for _ in range(cgit):
        if e < cgtol * t:
            break
        w = op(p)
        pw = float(np.dot(p, w))
        if pw == 0.0:
            break
        a = e / pw
        x += a * p
        r -= a * w
        e0 = e
        e = float(np.dot(r, r))
        p = r + (e / e0) * p
    return x

# ---------- Objective/gradient/Hessian blocks (matrix or operator A) ----------

def CS(x: Array,
        T1: Optional[Array],
        T2: Optional[Array],
        data: DataDict) -> Tuple[object, Optional[object]]:
    """
    If T1/T2 are None -> returns (f, grad)
    Else -> returns ( H(T1,T1) , D(T1,T2) ) where D is either array or callable
    """
    A = data['A']
    b = np.asarray(data['b'], dtype=np.float64).ravel()
    x = np.asarray(x, dtype=np.float64).ravel()

    # Matrix A (dense or scipy.sparse)
    if not callable(A):
        is_sparse = (sp is not None and sp.issparse(A))

        if T1 is None and T2 is None:
            nnz = np.count_nonzero(x)
            if nnz >= 0.025 * x.size:
                Axb   = (A @ x) - b if not is_sparse else (A.dot(x) - b)
            else:
                Tx    = np.flatnonzero(x)
                Axb = (A[:, Tx] @ x[Tx])-b if not is_sparse else A[:, Tx].dot(x[Tx])-b
            f = 0.5 * float(np.dot(Axb, Axb))
            g = (A.T @ Axb) if not is_sparse else A.T.dot(Axb)
            return f, g

        AT = A[:, T1] if not is_sparse else A[:, T1]
        if T1.size <= 1000:
            H = (AT.T @ AT) if not is_sparse else (AT.T @ AT)
        else:
            H = (lambda v, AT=AT: AT.T @ (AT @ v)) if not is_sparse else (lambda v, AT=AT: AT.T @ (AT @ v))
        if T2 is None:
            return H, None
        else:
            A_T2  = A[:, T2] if not is_sparse else A[:, T2]
            if (T1.size <= 1000) and (T2.size <= 1000):
                D = AT.T @ A_T2
            else:
                D = (lambda v, AT=AT, A_T2=A_T2: AT.T @ (A_T2 @ v))
            return H, D

    if 'At' not in data or 'n' not in data:
        raise ValueError("operator form requires 'At' and 'n' in data")
    Aop: Callable[[Array], Array] = A  # type: ignore
    ATop: Callable[[Array], Array] = data['At']  # type: ignore
    n = int(data['n'])

    if T1 is None and T2 is None:
        Axb = Aop(x) - b
        f   = 0.5 * float(np.dot(Axb, Axb))
        g   = ATop(Axb)
        return f, g

    def fgH(z: Array, t1: Array, t2: Array) -> Array:
        vec     = np.zeros(n, dtype=np.float64)
        vec[t2] = z
        return ATop(Aop(vec))[t1].copy()

    H = (lambda v, t1=T1: fgH(v, t1, T1))
    if T2 is None:
        return H, None
    D = (lambda v, t1=T1, t2=T2: fgH(v, t1, t2))
    return H, D

def AT_sub(Aop: Callable[[Array], Array],
           ATop: Callable[[Array], Array],
           vec: Array, take: Array) -> Array:
    """Compute (A^T A vec)[take] efficiently with linear ops."""
    return ATop(Aop(vec))[take].copy()