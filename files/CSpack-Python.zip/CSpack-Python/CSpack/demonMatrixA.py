# demon CS with matrix A
import numpy as np
from scipy.sparse import issparse
from CSpack import CSpack, PlotRecovery

n           = 10000
m           = int(np.ceil(0.25 * n))
s           = int(np.ceil(0.05 * n))

T           = np.random.permutation(n)[:s]
xopt        = np.zeros(n, dtype=float)
xopt[T]     = (0.25 + np.random.random(s)) * np.sign(np.random.randn(s))

A           = np.random.standard_normal((m, n))
A           = A / (np.log(m) if issparse(A) else np.sqrt(m))
b           = A[:, T] @ xopt[T] + 0.000 * np.random.standard_normal(m)

solver_list = ['GPNP', 'NHTP', 'IIHT', 'NL0R', 'PSNP', 'MIRL1']
solver_name = solver_list[0]
out         = CSpack(A, None, b, n, s, solver_name)  # A is matrix, pass None for At

obj_xopt    = 0.5 * np.linalg.norm(A @ xopt - b) ** 2
print(f" Objective at xopt:       {obj_xopt:.2e}")
print(f" Objective at out.sol:    {out['obj']:.2e}")
print(f" Sparsity of out.sol:     {np.count_nonzero(out['sol']):2d}")
print(f" Computational time:      {out['time']:.3f}sec")
PlotRecovery(xopt, out['sol'], [1500, 0, 600, 250], 1)