# demon CS with function A
import numpy as np
from scipy.sparse import issparse
from CSpack import CSpack, PlotRecovery

n           = 10000
m           = int(np.ceil(0.25 * n))
s           = int(np.ceil(0.05 * n))

T           = np.random.permutation(n)[:s]
xopt        = np.zeros(n)
xopt[T]     = (0.25 + np.random.random(s)) * np.sign(np.random.randn(s))

A_mat       = np.random.randn(m, n)
A_mat       = A_mat / (np.log(m) if issparse(A_mat) else np.sqrt(m))

b           = A_mat[:, T] @ xopt[T] + 0.000 * np.random.randn(m)
A           = lambda var: A_mat @ var  # A(var) = A_mat * var
At          = lambda var: A_mat.T @ var  # At(var) = A_mat' * var

solver_list = ['GPNP', 'NHTP', 'IIHT', 'NL0R', 'PSNP', 'MIRL1']
out         = CSpack(A, At, b, n, s, solver_list[0])  # Call the sixth solver

obj_xopt = np.linalg.norm(A(xopt) - b)**2 / 2  # Objective function value at xopt
print(f" Objective at xopt:       {obj_xopt:.2e}")
print(f" Objective at out.sol:    {out['obj']:.2e}")
print(f" Sparsity of out.sol:     {np.count_nonzero(out['sol']):2d}")
print(f" Computational time:      {out['time']:.3f}sec")

PlotRecovery(xopt, out['sol'], [800, 0, 600, 250], 1)