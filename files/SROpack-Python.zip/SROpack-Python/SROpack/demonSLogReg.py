# demon sparse logistic regression problems 
import os
import numpy as np
import scipy.io as sio
from SROpack import funcLogReg, NL0R, normalization

test = 2

if test == 1: # Generate random data
    n            = 10000
    m            = int(np.ceil(n / 5))
    s            = int(np.ceil(0.05 * n))

    data         = {'A' : np.random.randn(m, n)}
    true_weights = np.random.randn(s, 1)
    I            = np.random.permutation(n)
    T            = I[:s]
    q            = 1.0 / (1.0 + np.exp(-data['A'][:, T] @ true_weights))
    data['b']    = np.array([np.random.choice([0, 1], p=[1 - p_i[0], p_i[0]]) for p_i in q])

elif test == 2: # Load real data
    script_path = os.path.dirname(os.path.abspath(__file__))
    data_folder = os.path.join(script_path, 'SROpack', 'example', 'logistic_regression', 'real_data')
    
    prob        = 'colon-cancer'
    path_A      = os.path.join(data_folder, f'{prob}.mat')
    path_b      = os.path.join(data_folder, f'{prob}_label.mat')

    mat_A       = sio.loadmat(path_A)
    mat_b       = sio.loadmat(path_b)

    A           = mat_A['A']
    b           = mat_b['b'].flatten()
    b[b == -1]  = 0
    m, n        = A.shape

    data        = {'A': normalization(A, 1), 'b': b}

func       = lambda x, key, T1, T2: funcLogReg(x, key, T1, T2, data)
lambda_val = 0.01
pars       = {'eta': 1}
out        = NL0R(func, n, lambda_val, pars)
x_sol      = out['sol']

print(f" {'Logistic loss (objective function value):':<{41}} {out['obj']:.2e}")
print(f" {'CPU time:':<{41}} {out['time']:.3f}sec")
print(f" {'Sample dimension:':<{41}} {m}x{n}")
