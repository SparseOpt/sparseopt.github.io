import time
import numpy as np


def NL0R(func, n, lambda_, pars=None):
    r"""
    ----------------------------------------------------------------------------
    This code aims at solving the L0 norm regularized optimization

            min_{x\in R^n} f(x) + lambda*||x||_0^0

    where f: R^n->R, lambda>0
          ||x||_0^0 counts the number of non-zero entries
    ----------------------------------------------------------------------------
    Inputs:
      func  : A function handle defines                               (REQUIRED)
                       (objective, gradient, sub-Hessian)
      n     : Dimension of the solution x                             (REQUIRED)
      lambda: The penalty parameter                                   (REQUIRED)
      pars  : All parameters are optional                             (OPTIONAL)
              pars['x0']     -- Starting point of x         (default zeros(n,1))
              pars['tol']    -- Tolerance of halting conditions   (default 1e-6)
              pars['maxit']  -- Maximum number of iterations      (default  2e3)
              pars['uppf']   -- An upper bound of final objective (default -Inf)
                                Useful for noisy case
              pars['eta']    -- A positive scalar                    (default 1)
                                Tuning it may improve solution quality
              pars['update'] -- =1 update penalty parameter lambda   (default 1)
                                =0 fix penalty parameter lambda
              pars['disp']   -- =1 show results for each step        (default 1)
                                =0 not show results for each step
    ----------------------------------------------------------------------------
    Outputs:
        out['sol'] :   The sparse solution x
        out['obj'] :   Objective function value at out['sol']
        out['iter']:   Number of iterations
        out['time']:   CPU time
    ----------------------------------------------------------------------------
    """
    if pars is None:
        pars = {}

    x0, eta, tol, maxit, disp, update, uppf, rate = _setparameters(n, pars)
    x      = x0.copy()

    Err    = np.zeros(maxit)
    Obj    = np.zeros(maxit)
    Nzx    = np.zeros(maxit, dtype=int)
    TMP    = np.zeros(3)
    FNorm  = _fro_norm2

    Funcf  = lambda var: func(_col(var), 'f', [], [])
    Funcg  = lambda var: func(_col(var), 'g', [], [])
    FuncH  = lambda var, T, J : func(_col(var), 'h', T, J)

    obj    = Funcf(x)
    g      = Funcg(x)
    g      = _col(g)
    if FNorm(g) == 0.0:
        if disp:
            print('Starting point is a good stationary point, stop !!!')
        return {'sol': x, 'obj': float(obj), 'iter': 0, 'time': 0.0,
                'sparsity': int(np.count_nonzero(x)), 'Obj': Obj[:1]}

    if np.isnan(g).any():
        x          = np.zeros((n, 1))
        rind       = np.random.default_rng().integers(0, n)
        x[rind, 0] = np.random.random()
        obj        = Funcf(x) 
        g          = Funcg(x)
        g          = _col(g)

    t   = 0
    xtg = np.abs(x0 - eta * g)
    while t < 20:
        T   = np.where(xtg.ravel() > np.sqrt(2.0 * eta * lambda_))[0]
        nT  = T.size
        if nT == 0:
            lambda_ = lambda_ / 1.25
        elif nT > 0.12 * n:
            lambda_ = lambda_ * 1.25
        else:
            break
        t += 1

    maxlam = (np.max(np.abs(g)) ** 2) / (2.0 * eta)
    nx     = 0
    pcgit  = 5
    pcgtol = 1e-5
    beta   = 0.5
    sigma  = 5e-5
    delta  = 1e-10
    T0     = np.array([], dtype=int)

    t0     = time.time()
    if disp:
        print(' Start to run the solver -- NL0R ')
        print(' --------------------------------------------------------')
        print('  Iter      Error       Objective    Sparsity    Time(sec)')
        print(' --------------------------------------------------------')

    for iter_ in range(1, maxit + 1):
        x_old = x.copy()
        xtg   = x_old - eta * g
        nT    = 0

        while True:
            T   = np.where(np.abs(xtg).ravel() > np.sqrt(2.0 * eta * lambda_))[0]
            nT  = T.size
            if nT > 0:
                break
            lambda_ = lambda_ / 1.05

        if iter_ > 1 and (nT - T0.size) >= 0 and (nT - T0.size) <= 5 and Err[iter_ - 2] < tol:
            lambda_ = lambda0
            while True:
                T   = np.where(np.abs(xtg).ravel() > np.sqrt(2.0 * eta * lambda_))[0]
                nT  = T.size
                if nT > 0:
                    break
                lambda_ = lambda_ / 1.05

        if iter_ > 0 and nT > max(0.12, 0.2 / np.log2(1 + iter_)) * n:
            Tnew   = _sparse_approx(xtg[T], T)
            nTnew  = Tnew.size
            if Tnew.size > 0 and (nT / nTnew) < 20 and nT != nTnew:
                T  = Tnew
                nT = nTnew

        TTc  = np.setdiff1d(T, T0, assume_unique=False)
        flag = (TTc.size == 0)

        FxT            = np.sqrt(FNorm(g[T]) + FNorm(x[TTc])) if T.size > 0 else 0.0
        Err[iter_ - 1] = FxT / np.sqrt(n)
        Nzx[iter_ - 1] = nx

        if disp and (iter_ < 100 or iter_ % 10 == 0):
            print(f" {iter_:4d}      {Err[iter_-1]:8.2e}     {obj:9.2e}      {nx:4d}      {time.time()-t0:5.3f}sec")

        TMP   = np.concatenate([TMP[1:], [obj]])
        stop1 = (Err[iter_ - 1] < tol) and (np.std(TMP) < 1e-8 * (1 + abs(obj)))
        stop1 = stop1 and (nx == nT) and flag
        stop2 = (obj < uppf) and (nx <= int(np.ceil(nT))) and (iter_ > 3)
        stop3 = (np.linalg.norm(g) < tol) and (nx <= int(np.ceil(nT)))
        if iter_ > 1 and (stop1 or stop2 or stop3):
            if disp and not (iter_ < 100 or iter_ % 10 == 0):
                print(f" {iter_:4d}      {Err[iter_-1]:8.2e}     {obj:9.2e}      {nx:4d}      {time.time()-t0:5.3f}sec")
            break

        if iter_ == 1 or flag:
            H  = FuncH(x_old, T, T)
            gT = _col(g[T])
            if callable(H):
                d = _my_cg(H, -gT, pcgtol, pcgit, np.zeros((nT, 1)))
            else:
                d = -np.linalg.solve(H, gT)
            dg  = float(np.sum(d * gT))
            ngT = FNorm(gT)
            if dg > max(-delta * FNorm(d), -ngT) or np.isnan(dg):
                d  = -gT
                dg = ngT
        else:
            H     = FuncH(x_old, T, T)
            D     = FuncH(x_old, T, TTc)
            x_TTc = _col(x_old[TTc]) if TTc.size > 0 else np.zeros((0, 1))
            gT    = _col(g[T])

            if D is None:
                rhs = -gT
            elif callable(D):
                rhs = _col(D(x_TTc)) - gT
            else:
                rhs = D @ x_TTc - gT

            if callable(H):
                d = _my_cg(H, rhs, pcgtol, pcgit, np.zeros((nT, 1)))
            else:
                d = np.linalg.solve(H, rhs)

            Fnz = FNorm(x[TTc]) / (4.0 * eta) if TTc.size > 0 else 0.0
            dgT = float(np.sum(d * gT))
            dg  = dgT - (float(np.sum(x_old[TTc] * g[TTc])) if TTc.size > 0 else 0.0)

            delta0 = 1e-4 if Fnz > 1e-4 else delta
            ngT    = FNorm(gT)
            if dgT > max(-delta0 * FNorm(d) + Fnz, -ngT) or np.isnan(dg):
                d  = -gT
                dg = ngT

        alpha = 1.0
        x     = np.zeros((n, 1))
        obj0  = obj
        for _ in range(6):
            x[T]       = x_old[T] + alpha * d
            obj_tmp = Funcf(x)
            if obj_tmp < obj0 + alpha * sigma * dg:
                obj = obj_tmp
                break
            alpha *= beta

        T0             = T.copy()
        obj            = Funcf(x)
        g              = Funcg(x)
        g              = _col(g)
        Obj[iter_ - 1] = obj

        if iter_ % 10 == 0:
            OBJ   = Obj[max(0, iter_ - 10): iter_]
            cond1 = Err[iter_ - 1] > 1.0 / (iter_ ** 2)
            cond2 = (OBJ.size >= 2) and (np.sum(OBJ[1:] > 1.5 * OBJ[:-1]) >= 2)
            if cond1 or cond2:
                eta = eta / (1.25 if iter_ < 1500 else 1.5)
            else:
                eta = eta * 1.25

        nx = int(np.count_nonzero(x))
        if iter_ > 5 and (nx > 2 * (Nzx[:iter_ - 1].max() if iter_ > 1 else 0)) and (Err[iter_ - 1] < 1e-2):
            rate0  = 2.0 / rate
            x      = x_old.copy()
            nx     = int(np.count_nonzero(x_old))
            nx0    = int(Nzx[iter_ - 2]) if iter_ > 1 else nx
            obj    = Funcf(x)
            g      = Funcg(x)
            g      = _col(g)
            rate   = 1.1
        else:
            rate0 = rate

        if 'nx0' in locals() and nx < nx0:
            rate0 = 1.0

        lambda0 = lambda_
        if update:
            lambda_ = min(maxlam, lambda_ * (2.0 * (nx >= 0.1 * n) + rate0))

    obj     = Funcf(x) 
    g       = Funcg(x)
    elapsed = time.time() - t0
    out = {
        'sol': x,
        'obj': float(obj),
        'iter': iter_,
        'time': float(elapsed),
        'sparsity': int(np.count_nonzero(x)),
        'Obj': Obj[:iter_],
    }

    if disp:
        print(' --------------------------------------------------------')
        normgrad = float(np.linalg.norm(g))
        if normgrad < 1e-6:
            print(f' A global optimal solution might be found')
            print(f' because of ||gradient|| = {normgrad:5.2e}!')
            print(' --------------------------------------------------------')

    return out

def _col(z):
    z = np.asarray(z)
    return z.reshape(-1, 1) if z.ndim == 1 else z

def _fro_norm2(z):
    """ squared Frobenius (== sum of squares) """
    z = np.asarray(z)
    return float(np.sum(z * z))

def _setparameters(n, pars):
    rate0 = 0.5 if n <= 1000 else 1.0 / np.exp(3.0 / np.log10(n))
    x0    = _col(pars.get('x0',   np.zeros((n, 1))))
    eta   = float(pars.get('eta', 1.0))
    rate  = float(pars.get('rate', rate0))
    disp  = int(pars.get('disp', 1))
    maxit = int(pars.get('maxit', 2000))
    uppf  = float(pars.get('uppf', -np.inf))
    tol   = float(pars.get('tol', 1e-6))
    update= int(pars.get('update', 1))
    return x0, eta, tol, maxit, disp, update, uppf, rate

def _sparse_approx(x0, T0):
    """
    - Only use the "first column" of x0 for thresholding (consistent with MATLAB column priority)
    - Ensure one-to-one correspondence: len(x) == len(T0)
    """
    T0 = np.asarray(T0, dtype=int).reshape(-1)  # 1D index
    a  = np.asarray(x0, dtype=float)

    if a.ndim == 1:
        a = a.reshape(-1, 1)
    elif a.ndim == 2:
        if a.shape[1] != 1:
            a = a[:, :1]
    else:
        a = a.reshape(a.shape[0], -1)[:, :1]

    k = a.shape[0]
    if k != T0.size:
        k_use = min(k, T0.size)
        a     = a[:k_use, :]
        T0    = T0[:k_use]

    x = np.abs(a).reshape(-1)

    sel = x[x != 0.0]
    if sel.size == 0:
        th = 0.0
    elif sel.size <= 2:
        th = sel[-1]
    else:
        r  = sel[1:] / sel[:-1]
        it = int(np.argmax(r))
        mx = float(r[it])
        th = float(sel[it]) if (mx > 10.0 and it >= 1) else 0.0

    mask = (x > th)
    return T0[mask]

def _my_cg(fx, b, cgtol, cgit, x0):
    r"""
    - fx: callable(v)->fx(v) or ndarray matrix
    - b : (k,1)
    - x0: (k,1)
    Returns x
    """
    b = _col(b)
    x = _col(x0)
    if _fro_norm2(b) == 0.0:
        return np.zeros_like(x)

    def _apply(v):
        if callable(fx):
            return _col(fx(_col(v)))
        else:
            return _col(fx @ _col(v))

    r = b - _apply(x) if np.count_nonzero(x) > 0 else b.copy()
    e = _fro_norm2(r)
    t = e
    p = r.copy()
    for _ in range(int(cgit)):
        if e < cgtol * t:
            break
        w  = _apply(p)
        pw = float(np.sum(p * w))
        if pw == 0.0:
            break
        a  = e / pw
        x  = x + a * p
        r  = r - a * w
        e0 = e
        e  = _fro_norm2(r)
        p  = r + (e / e0) * p
    return x