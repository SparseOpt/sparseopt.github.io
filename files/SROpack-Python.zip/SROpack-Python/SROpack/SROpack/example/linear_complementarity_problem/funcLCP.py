import numpy as np

def funcLCP(x, key, T1, T2, data):
    r   = float(data.get('r', 2.0))
    A   = data['A']
    At_ = data.get('At', None)
    q   = _col(data['b'])
    x   = _col(x)
    n   = q.shape[0]

    M, Mt = _get_M_Mt_from_dataA(A, At_)

    if M is not None:
        if not M.flags['F_CONTIGUOUS']:
            M  = np.asfortranarray(M)
        if not Mt.flags['F_CONTIGUOUS']:
            Mt = np.asfortranarray(Mt)

    eps = 0.0
    xr  = x.ravel()
    ip  = np.where(xr >  eps)[0]
    in_ = np.where(xr < -eps)[0]
    ix  = np.union1d(ip, in_)
    
    if M is not None:
        if ix.size > 0:
            Mx = M[:, ix] @ x[ix]
            np.add(Mx, q, out=Mx)
        else:
            Mx = q.copy()
    else:
        if hasattr(A, "matvec"):
            Mx = A.matvec(x)
            np.add(Mx, q, out=Mx)
        else:
            raise TypeError("data['A'] is neither ndarray nor usable LinearOperator")

    Mxr = Mx.ravel()
    tp  = np.where(Mxr >  eps)[0]
    tn  = np.where(Mxr < -eps)[0]
    tt  = np.intersect1d(ip, tp)
    com = (tt.size > 0)

    Mxn = np.abs(Mx[tn])
    xn  = np.abs(x[in_])

    if key == 'f':
        out = (float((xn**r).sum()) + float((Mxn**r).sum())) / r
        if com:
            x_tt  = x[tt]
            Mx_tt = Mx[tt]
            out  += float(((x_tt * Mx_tt)**r).sum()) / r
        return float(out)
        
    elif key == 'g':
        g = np.zeros_like(x)
        if tn.size > 0:
            g      -= Mt[:, tn] @ (Mxn ** (r - 1))
        if in_.size > 0:
            g[in_] -= (xn ** (r - 1))
        if com:
            x_tt    = x[tt]
            Mx_tt   = Mx[tt]
            g      += Mt[:, tt] @ ( (x_tt**r) * (Mx_tt**(r - 1)) )
            g[tt]  += ( (x_tt**(r - 1)) * (Mx_tt**r) )
        return g
            
    elif key == 'h':

        T1  = np.asarray(T1, dtype=int).ravel()
        s1  = T1.size
        mx  = np.maximum(x,  0.0)
        mMx = np.maximum(Mx, 0.0)

        if abs(r - 2.0) >= 1e-12:
            r1 = r - 1.0
            r2 = r - 2.0
            z2 = r1 * (Mxn ** r2)
            if com:
                z1 = r1 * ( (mx[tt] ** r) * (mMx[tt] ** r2) )

        else:
            all_idx = np.arange(n, dtype=int)
            tn0     = np.setdiff1d(all_idx, tp, assume_unique=False)
            if com:
                z1  = (mx[tt] ** 2)
        tem1        = r * ((mx[T1] * mMx[T1]) ** (r - 1.0))
        if np.array_equal(np.ravel(T1), np.ravel(T2)):
            if abs(r - 2.0) >= 1e-12:
                MM       = Mt[np.ix_(T1, tn)] @ (z2.reshape(-1, 1) * M[np.ix_(tn, T1)])
                neg_x_T1 = np.abs(np.minimum(x[T1], 0.0))
                xy       = r1 * ( ( (mx[T1] ** r2) * (mMx[T1] ** r) ) + (neg_x_T1 ** r2) )
            else:
                MM       = Mt[np.ix_(T1, tn0)] @ M[np.ix_(tn0, T1)]
                z        = np.ones((n, 1))
                z[ip]    = (mMx[ip] ** 2)
                xy       = z[T1]

            if com:
                MM += Mt[np.ix_(T1, tt)] @ (z1.reshape(-1, 1) * M[np.ix_(tt, T1)])
            
            out           = (tem1 @ np.ones((1, s1))) * M[np.ix_(T1, T1)]
            out           = out + out.T + MM
            diag_idx      = np.diag_indices(s1)
            out[diag_idx] = out[diag_idx] + xy.ravel()

        else:
            T2  = np.asarray(T2, dtype=int).ravel()
            s2  = T2.size 
            if abs(r - 2.0) >= 1e-12:
                MM  = Mt[np.ix_(T1, tn)] @ (z2.reshape(-1, 1) * M[np.ix_(tn, T2)])
            else:
                MM  = Mt[np.ix_(T1, tn0)] @ M[np.ix_(tn0, T2)]
            if com:
                MM += Mt[np.ix_(T1, tt)] @ (z1.reshape(-1, 1) * M[np.ix_(tt, T2)])   
            tem2           = r * ((mx[T2] * mMx[T2]) ** (r - 1.0))
            out = ( (tem1 @ np.ones((1, s2))) * M[np.ix_(T1, T2)] + (Mt[np.ix_(T1, T2)] * (np.ones((s1, 1)) @ tem2.T))+ MM )
            
        return out

    else:
        raise ValueError("key must be 'fg' or 'h'")

def _col(z):
    z = np.asarray(z)
    return z.reshape(-1, 1) if z.ndim == 1 else z

def _get_M_Mt_from_dataA(A, At):
    """
    Prefer to return real ndarray matrices (M, Mt) to support submatrix indexing.
    - If A is ndarray: directly return (A, At or A.T)
    - If A is LinearOperator and internally has A.A ndarray: return (A.A, At or A.A.T)
    - Otherwise return (None, None) indicating submatrix indexing is not possible (can fall back to matvec/rmatvec)
    """
    if isinstance(A, np.ndarray):
        M  = A
        Mt = At if isinstance(At, np.ndarray) else A.T
        return M, Mt

    if hasattr(A, "A") and isinstance(A.A, np.ndarray):
        M  = A.A
        Mt = At if isinstance(At, np.ndarray) else M.T
        return M, Mt

    return None, None