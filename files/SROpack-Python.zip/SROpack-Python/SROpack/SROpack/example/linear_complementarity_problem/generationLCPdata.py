import time
import numpy as np
import scipy.sparse as sp


def generationLCPdata(example: str, n: int, s: int):
    start = time.time()
    print("Please wait for LCP data generation...")
    rng = np.random.default_rng()
    xopt = None

    if example == 'z-mat':
        M          = np.eye(n, dtype=np.float64) - (np.ones((n, n), dtype=np.float64) / float(n))
        q          = np.ones((n, 1), dtype=np.float64) / float(n)
        q[0, 0]    = 1.0 / float(n) - 1.0
        xopt       = np.zeros((n, 1), dtype=np.float64)
        xopt[0, 0] = 1.0
        Mt         = M

    elif example == 'sdp':
        Z       = rng.standard_normal(size=(n, int(np.ceil(n / 2))))
        M       = Z @ Z.T
        xopt, T = _get_sparse_x(n, s, rng)
        Mx      = M[:, T] @ xopt[T]
        q       = np.abs(Mx)
        q[T, 0] = -Mx[T, 0]
        M       = M / float(n)
        Mt      = M
        q       = q / float(n)

    elif example == 'sdp-non':
        Z       = rng.random(size=(n, int(np.ceil(n / 4))))
        M       = Z @ Z.T
        _, T    = _get_sparse_x(n, s, rng)
        q       = _col(rng.random(size=(n, )))
        q[T, 0] = -rng.random(size=(s, ))
        M       = M / float(n)
        Mt      = M
        q       = q / float(n)

    else:
        raise ValueError("example must be one of {'z-mat','sdp','sdp-non'}")

    M    = np.asarray(M,  dtype=np.float64, order='F')
    Mt   = np.asarray(Mt, dtype=np.float64, order='F')
    q    = np.asarray(q,  dtype=np.float64).reshape(-1, 1)

    Aop  = LinearOperator(M, At=Mt, shape=(n, n), fortran_hint=False)

    data = {'A': Aop, 'At': Mt, 'b': q, 'n': int(n)}
    if xopt is not None:
        data['xopt'] = np.asarray(xopt, dtype=np.float64).reshape(-1, 1, order='F')

    print(f"Data generation used {time.time() - start:0.4f} seconds.\n")
    return data


def _col(x):
    x = np.asarray(x)
    return x.reshape(-1, 1) if x.ndim == 1 else x


def _get_sparse_x(n, s, rng):
    idx     = rng.permutation(n)
    T       = idx[:s]
    x       = np.zeros((n, 1), dtype=np.float64)
    x[T, 0] = 0.1 + np.abs(rng.standard_normal(size=s))
    return x, T


class LinearOperator:
    def __init__(self, A, At=None, shape=None, fortran_hint=True):
        self._is_matrix   = isinstance(A, (np.ndarray, sp.spmatrix))
        self._is_callable = callable(A)
        self.A            = A
        self.At           = At
        if shape is None:
            assert self._is_matrix, "Callable A requires explicit shape"
            shape  = A.shape
        self.shape = shape
        if self._is_matrix and isinstance(A, np.ndarray) and fortran_hint:
            # One-time column-major conversion to improve subsequent GEMV
            self.A = np.asfortranarray(A)

    @staticmethod
    def _col(x):
        x = np.asarray(x)
        return x.reshape(-1, 1) if x.ndim == 1 else x

    def matvec(self, x):
        x = self._col(x)
        if self._is_matrix:
            return self.A @ x
        else:
            return self._col(self.A(x))

    def rmatvec(self, y):
        y = self._col(y)
        if self._is_matrix:
            return (self.A.T @ y) if self.At is None else (self.At @ y)
        else:
            assert self.At is not None, "Callable A requires At"
            return self._col(self.At(y))