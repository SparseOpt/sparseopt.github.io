# demon sparse linear regression problems
import numpy as np
from SROpack import funcLinReg, NL0R, PlotRecovery

n          = 2000
m          = int(np.ceil(0.25 * n))
s          = int(np.ceil(0.05 * n))

Tx         = np.random.choice(n, size=s, replace=False)
xopt       = np.zeros((n, 1))
xopt[Tx]   = ((0.25 + np.random.rand(s, 1)) * np.sign(np.random.randn(s, 1)))

A          = np.random.randn(m, n) / np.sqrt(m)
b          = A @ xopt

func       = lambda x, key, T1, T2 : funcLinReg(x, key, T1, T2, A, b)
lambda_val = 0.01
pars       = {'eta': 1.0}
out        = NL0R(func, n, lambda_val, pars)
PlotRecovery(xopt, out['sol'], (1800, 0, 600, 250), 1)

