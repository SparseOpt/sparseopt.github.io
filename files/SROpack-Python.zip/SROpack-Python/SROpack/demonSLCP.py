# demon sparse linear complementarity problems
import numpy as np
from SROpack import generationLCPdata, funcLCP, NL0R, PlotRecovery

n       = 2000
s       = int(np.ceil(0.05 * n))
mattype = {1: 'z-mat', 2: 'sdp', 3: 'sdp-non'}[2]

data    = generationLCPdata(mattype, n, s)
func    = lambda x, key, T1, T2: funcLCP(x, key, T1, T2, data)
lam     = 0.01
out     = NL0R(func, n, lam, pars=dict(tol=1e-6, maxit=300, disp=1))

print(f" Objective:         {out['obj']:5.2e}")
print(f" CPU time:          {out['time']:.3f}sec")
print(f" Sample size:       {n}x{n}")

PlotRecovery(data['xopt'], out['sol'], (1800, 0, 600, 250), 1)

