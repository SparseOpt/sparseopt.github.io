# demon a simple SRO problem
from SROpack import funcSimpleEx, NL0R

n          = 2
lambda_val = 0.5
pars       = {'eta': 0.1}
out        = NL0R(funcSimpleEx, n, lambda_val, pars)

print(f"{'Objective:':<20} {out['obj']:<12.4f}")
print(f"{'CPU time:':<20} {out['time']:.3f}sec")
print(f"{'iteration count:':<20} {out['iter']:<12d}")
