# demon compressive sensing problems 
import time
import numpy as np
import scipy.sparse as sp

from SROpack import funcCS, PlotRecovery, NL0R

n           = 2000
m           = int(np.ceil(0.25 * n))
s           = int(np.ceil(0.05 * n))
nf          = 0.00

Tx          = np.random.choice(n, size=s, replace=False)
xopt        = np.zeros((n, 1))
xopt[Tx, 0] = (0.25 + np.random.random(s)) * np.sign(np.random.standard_normal(s))

A           = np.random.standard_normal((m, n))
denom       = np.log(m) if sp.issparse(A) else np.sqrt(m)
A           = np.asfortranarray(A / denom)
b           = (A @ xopt) + nf * np.random.standard_normal((m, 1))

data        = {'A': A, 'b': b, 'n': n,}

func        = lambda x, key, T1, T2: funcCS(x, key, T1, T2, data)
pars        = {'eta': 1.0, 'tol': 1e-6, 'maxit': 300, 'disp': 1,}
lambda_     = 0.01
t0          = time.time()
out         = NL0R(func, n, lambda_, pars)
elapsed     = time.time() - t0

true_obj    = 0.5 * (((A @ xopt - b).T @ (A @ xopt - b))).item()
print(f"\n CPU time:          {out['time']:.3f}sec  (wall {elapsed:.3f}s)")
print(f" Objective:         {out['obj']:5.2e}")
print(f" True Objective:    {true_obj:5.2e}")
print(f" Sample size:       {m}x{n}")
print(f" Recovered sparsity:{np.count_nonzero(out['sol']):d}")

PlotRecovery(xopt, out['sol'], (1800, 0, 600, 250), 1)
