To implement this solver, please run demonXXXX.m to solve different problems

This source code contains the algorithm described in:
Shenglong Zhou, Lili Pan, Naihua Xiu, Houduo Qi, 
Quadratic convergence of smoothing Newton's method for 0/1 loss optimization,
SIAM Journal on Optimization, 31(4): 3184–3211, 2021.

Send your comments and suggestions to <<< slzhou2021@163.com >>>                                  
WARNING: Accuracy may not be guaranteed!!!!!  

Please give credits to this paper if you use the code for your research.
