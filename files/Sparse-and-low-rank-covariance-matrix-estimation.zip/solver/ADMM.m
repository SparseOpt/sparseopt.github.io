function [Sigma, time]=ADMM(Example,Sigma_n,opts)
% A solver for sparse and low rank covariance matrix recovery model:
%
% min 0.5||Sigma-Sigman||_F^2 + lambda*||Sigma||_1+tau*||Sigma||_*
%
% Updated by 21/12/2015, Shenglong Zhou
% This Matlab solver was created based on the algorithm proposed by
% S. Zhou, N. Xiu, Z. Luo and L. Kong, Sparse and Low-Rank Covariance Matrix Estimation, 
% Journal of the Operations Research Society of China, vol. 3(2): 231-250, 2015.
%
% --- Input:
%     Sigman  --- an p x p matrix ;
%     Example --- Example=1 stands for Block Structured matrix;
%                 Example=2 stands for Banded Structured matrix;
%     opts   ---  a structure with fields:
%                 opts.lambda -- penalty for sparsity, default one:
%                                0.25 for Example=1 and 0.5 for Example=2; 
%                 opts.tau    -- penalty for low rank, default one:
%                                0.5 for Example=1 and 0.75 for Example=2;
%
%%%%%%%    Send your comments and suggestions to                     %%%%%%
%
%%%%%%%    longnan_zsl@163.com                                       %%%%%%
% 
%%%%%%%    Warning: Accuracy may not be guaranteed!!!!!              %%%%%%

% ========================================================================

% Initialization
if     Example==1; lamda=0.25; tau=0.5; 
elseif Example==2; lamda=0.5;  tau=0.75;
end

if  isfield(opts,'lamda');      lamda= opts.lamda;           end
if  isfield(opts,'tau');        tau  = opts.tau;             end

p     = size(Sigma_n,2);   
eps   = 5e-4;  
itmax = 1000; 
mu    = 1;
mu1   = mu/(mu+1);

Lamda = zeros(p,p); 
Sigma = zeros(p,p);  
Gamma = speye(p); 

% Main Body
tic 
for iter=1:itmax

    % Update Gamma
    [U,Q]  = eig(Sigma+mu*Lamda-mu*tau*eye(p));
    Gamma1 = Gamma; 
    dQ     = diag(Q);
    T      = find(dQ>1e-4);    
    Gamma  = real((U(:,T).*repmat(dQ(T)',[p,1]))*U(:,T)');

    % Update Sigma
    P      = Sigma_n + Gamma/mu - Lamda; 
    Sigma1 = Sigma;    
    Sigma  = sign(P).* max(abs(P)*mu1-lamda*mu1,0);

    % Compute the Stop Criteria 
    time=toc;
    if mod(iter,2)==0
        ErrSigma=sqrt(sum(Sigma-Sigma1).^2)/sqrt(sum(Sigma1.^2));
        ErrGamma=sqrt(sum(Gamma1-Gamma).^2)/sqrt(sum(Gamma1.^2));
        fprintf('Iter:%3d; CPUTime: %2.2f; ErrSigma=:%1.2e; ErrGamma=:%1.2e; \n',...
                 iter,time,ErrSigma,ErrGamma);
        if  ErrSigma<eps & ErrGamma<eps; break;  end    
    end
    
    % Update Lamda
    Lamda = Lamda - (Gamma-Sigma)/mu;
    
end
fprintf('\n----------------------------------------------------------------\n');
end


