clc;clear all;close all;
addpath(genpath(pwd)); warning off

Exp_Type = 1;
p        = 500; 
n        = 50;  
K        = 5; 

if  Exp_Type==1
    opts.lamda=0.25; opts.tau=0.5;
else
	opts.lamda=0.5;  opts.tau=0.75;
end

% Design Sigma0 and Sample matrix Sigman
[Sigman,Sigma0] = Examples(Exp_Type,n,p,K);

% call ADMM solver to solve
[Sigma,time]    = ADMM(Exp_Type,Sigman,opts);

% Result Output
r0        = Approx_rank(Sigma0); 
r         = Approx_rank(Sigma);
Tol       = 1e-4;
sp0       = sum(sum(abs(Sigma0)>=Tol) )/p^2;
sp        = sum(sum(abs(Sigma)>=Tol) )/p^2;
[FPR,TPR] = FTRate(Sigma0,Sigma);
fprintf(' CPU Time: %2.2f(sec); \n',time)
fprintf(' ApproxRank_Sigma0: %d;        ApproxRank_Sigma: %d \n',r0,r)
fprintf(' Sparsity_Sigma0:   %1.4f;   Sparsity_Sigma:   %2.4f  \n',sp0,sp)
fprintf(' False_Posi_Rate:   %1.4f;   True_Posi_Rate:   %2.4f ',FPR,TPR)

% Graph Output
fprintf('\n----------------------------------------------------------------\n');
fprintf('\n Waiting for Graph generation...  \n')
subplot(1,3,1), SubGraph(Sigma0,1);
subplot(1,3,2), SubGraph(Sigman,2);
subplot(1,3,3), SubGraph(Sigma,3);
colormap(summer)


