clc;clear all;close all;
addpath(genpath(pwd)); warning off

ExpType= 1;
p      = 500; 
n      = 50;
K      = 5;   
NoSamp = 2;  
Result = []; 
 
if  ExpType==1
    opts.lamda=0.25; opts.tau=0.5;
else
    opts.lamda=0.5;  opts.tau=0.75;
end

for S=1:NoSamp
   % Design Sigma0 and Sigma0 with Noise
    [Sigman,Sigma0]= Examples(ExpType,n,p,K);
  
    % call ADMM solver to solve
    [Sigma,time]   = ADMM(ExpType,Sigman,opts);
    
    r0       = Approx_rank(Sigma0);  
    r        = Approx_rank(Sigma);  
    sp0      = sum(sum(abs(Sigma0)>=1e-4))/p^2;
    sp       = sum(sum(abs(Sigma)>=1e-4))/p^2;
    [FPR,TPR]= FTRate(Sigma0,Sigma);
    
    Result   = [Result; r0  r sp0 sp FPR TPR  time];
end

% Average Result Output
aver = mean(Result);
fprintf('\n Rank_S0:  %4.4f     Rank_S: %4.4f',aver(1),aver(2))
fprintf('\n Spar_S0:  %4.4f     Spar_S: %4.4f',aver(3),aver(4))
fprintf('\n FPR:      %4.4f     TPR:    %4.4f',aver(5),aver(6))
fprintf('\n CPU Time: %4.2fsec\n\n',aver(7))
