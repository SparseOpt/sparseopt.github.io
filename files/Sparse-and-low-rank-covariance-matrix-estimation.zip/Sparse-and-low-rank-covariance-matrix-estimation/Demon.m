clc;clear all;close all;
addpath(genpath(pwd)); warning off

ExpType= 1;
p      = 1000; 
n      = 50;
K      = 50;   
NoSamp = 5;  
Result = []; 
 
if  ExpType==1
    opts.lamda=0.25; opts.tau=0.5;
else
    opts.lamda=0.5;  opts.tau=0.75;
end

for S=1:NoSamp
   % Design Sigma0 and Sigma0 with Noise
    [Sigman,Sigma0]= Examples(ExpType,n,p,K);
  
    % call ADMM solver to solve
    [Sigma,time]   = ADMM(ExpType,Sigman,opts);
    
    r0       = Approx_rank(Sigma0);  
    r        = Approx_rank(Sigma);  
    sp0      = sum(sum(abs(Sigma0)>=1e-4))/p^2;
    sp       = sum(sum(abs(Sigma)>=1e-4))/p^2;
    [FPR,TPR]= FTRate(Sigma0,Sigma);
    
    Result   = [Result; r0  r sp0 sp FPR TPR  time];
end

% Result Output
fprintf('\n Rank_S0   Rank_S   Spar_S0    Spar_S     FPR      TPR   CPUTime\n')
aver = mean(Result);
fprintf('----------------------------------------------------------------\n');
fprintf('  %2.1f     %2.1f     %1.4f    %1.4f    %1.4f   %1.4f  %1.3f\n',...
        aver(1),aver(2),aver(3),aver(4),aver(5),aver(6),aver(7))



