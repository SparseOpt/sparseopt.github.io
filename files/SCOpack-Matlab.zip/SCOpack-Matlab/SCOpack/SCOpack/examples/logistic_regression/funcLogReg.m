function out = funcLogReg(x,key,T1,T2,data)
  
   n      = length(x);
   if  n <= (4/3)*nnz(x)
       Ax = data.A*x; 
   else
       Tx = find(x); 
       Ax = data.A(:,Tx)*x(Tx); 
   end
    m     = length(data.b);
    eAx   = exp(Ax);
    mu    = 1e-6/m; 
        
    switch key
        case 'f'
            if  sum(eAx)==Inf 
                Tpos = find(Ax>300); 
                Tneg = setdiff(1:m,Tpos);
                obj  = sum(log(1+eAx(Tneg)))+sum(Ax(Tpos))-sum(data.b.*Ax);                
            else
                obj  = sum(log(1+eAx)-data.b.*Ax); 
            end
            out  = obj/m;                                    % objective 
        case 'g'
            fAt  = @(var)(var'*data.A)';
            out  = fAt(1-data.b-1./(1+eAx))/m + mu*x;        % gradient       
        case 'h'
            eXx  = 1./(1+eAx);
            d    = eXx.*(1-eXx)/m; 
            XT   = data.A(:,T1);            
            if  isequal(T1,T2)
                s       = length(T1);
                if  s  <= 1e3 && n <=1e4
                    out = (d.*XT)'*XT + mu*speye(s);        % sub-Hessian indexed by T1 and T1
                else
                    out = @(v)( mu*v+( (d.*(XT*v))'*XT )' );
                end
            else
                out  = @(v)( (d.*(data.A(:,T2)*v))'*XT )';  % sub-Hessian indexed by T1 and T2   
            end
    end
    
    clear data XT
end



