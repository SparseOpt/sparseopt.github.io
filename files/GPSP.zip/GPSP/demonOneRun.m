clc; close all; clear; addpath(genpath(pwd));

n          = 2000;          % Signal dimension 
m          = ceil(0.5*n);   % Number of measurements
s          = ceil(0.01*n);  % Sparsity level
nf         = 0.05;          % Noisy ratio
r          = 0.02;          % Flipping ratio
k          = ceil(r*m);  

[A,b,bo,xo]= random1bcs('Ind',m,n,s,r,nf); % or 'Cor' 

out        = GPSP(A,b,s,k); 
fprintf('Time: %6.3f\n',out.time);
fprintf('SNR:  %6.3f\n',-10*log10(norm(out.solx-xo)^2));
fprintf('HD:   %6.3f\n',nnz(sign(A*out.solx)-b)/m)
fprintf('HE:   %6.3f\n',nnz(sign(A*out.solx)-bo)/m)
RecoverShow(xo,out.solx,[1000 450 500 250])

 