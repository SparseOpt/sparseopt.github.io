
Please run demon_XXXX.m to solve the one-bit comressed sensing problems

This source code contains the algorithm described in:

   Shenglong Zhou, Ziyan Luo, Naihua Xiu, Geoffrey Ye Li,

   Computing One-bit Compressed Sensing via Double Sparsity Constrained Optimization,

   IEEE Transactions on Signal Processing, vol. 70, pp. 1593-1608, 2022.

Please give credits to this paper if you use the code for your research.
