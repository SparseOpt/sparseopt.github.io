# Demon sparse linear complementarity problem
import math
from SCOpack import funcLCP, generationLCPdata, PlotRecovery, SCOpack

n        = 2000
s        = math.ceil(0.05 * n)
mattype  = [ 'sdp', 'z-mat','sdp-non']
data     = generationLCPdata(mattype[0], n, s)

func     = lambda x, key, T1, T2: funcLCP(x, key, T1, T2, data)
pars     = {'eta': 1 + 4 * (n <= 1000), 'neg': 1}
solvers  = ['NHTP', 'GPNP', 'IIHT']
out      = SCOpack(func, n, s, solvers[0], pars)

print(f" Objective:         {out['obj']:5.2e}")
print(f" CPU time:          {out['time']:.3f}sec")
print(f" Sample size:       {n}x{n}")

PlotRecovery(data['xopt'], out['sol'], [900, 500, 500, 250], ind=1)