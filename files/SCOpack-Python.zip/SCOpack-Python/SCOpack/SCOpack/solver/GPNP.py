import time
import numpy as np

def GPNP(func, n, s, pars=None):
    r"""
    This code aims at solving the sparsity constrained optimization,

            min_{x∈R^n} f(x)  s.t.  ||x||₀<=s

    where f: R^n->R and s<<n is an integer.

    Inputs:--------------------------------------------------------------------
        func: A function handle defines                              (REQUIRED)
                      (objective, gradient, sub-Hessain)
        n   : Dimension of the solution x                            (REQUIRED)
        s   : Sparsity level of x, an integer between 1 and n-1      (REQUIRED)
        pars: Parameters are all optional                            (OPTIONAL)
            pars['x0']    --  Starting point of x          (default zeros(n,1))
            pars['eta']   --  A positive scalar for 'NHTP'          (default 1)
                              Tuning it may improve solution quality
            pars['disp']  --  =1: show results for each step        (default 1)
                              =0: not show results for each step
            pars['maxit'] --  Maximum number of iterations       (default 2000)
            pars['tol']   --  Tolerance of stopping criteria     (default 1e-6)
            pars['uppf']  --  An upper bound of final objective  (default -Inf)
                              Useful for noisy case
    Outputs:-------------------------------------------------------------------
        out['sol'] :   The sparse solution x
        out['time']:   CPU time
        out['iter']:   Number of iterations
        out['obj'] :   Objective function value at out['sol']
    ---------------------------------------------------------------------------
    Send your comments and suggestions to <<< slzhou2021@163.com >>>
    WARNING: Accuracy may not be guaranteed!!!!!
    """

    if pars is None:
        pars  = {}

    Funcf     = lambda var: func(_v1(var), 'f', [], [])
    Funcg     = lambda var: func(_v1(var), 'g', [], [])
    FuncH     = lambda var, T: func(_v1(var), 'h', T, T)

    sigma, J, flag, alpha0, gamma, thd, disp, tol, uppf, maxit = _set_parameters(n, s, pars)

    x         = np.zeros(n, dtype=np.float64)
    xo        = np.zeros(n, dtype=np.float64)

    fx        = float(Funcf(x))
    gx        = _v1(Funcg(x))

    Tx        = _topk_abs(gx, s)
    Tx.sort()

    minobj    = np.full(maxit + 2, np.inf, dtype=np.float64)
    minobj[0] = fx
    OBJ       = np.zeros(5, dtype=np.float64)

    if disp:
        print(" Start to run the solver -- GPNP ")
        print(" -------------------------------------------")
        print("  Iter     Error      Objective       Time ")
        print(" -------------------------------------------")

    t0        = time.perf_counter()

    for iter_ in range(1, maxit + 1):
        alpha = alpha0
        u     = None
        subu  = None
        for _ in range(J):
            cand   = x - alpha * gx
            Tu     = _topk_abs(cand, s)
            u      = xo.copy()
            subu   = cand[Tu]
            u[Tu]  = subu
            fu     = float(Funcf(u))
            if fu < fx - sigma * _sum_squares(u - x): break
            alpha *= gamma

        fu         = float(Funcf(u))
        gx         = _v1(Funcg(u))
        normg      = _sum_squares(gx)
        x          = u
        fx         = fu

        sT         = np.sort(Tu)
        mark       = (np.count_nonzero(sT - Tx) == 0)
        Tx         = sT
        eps_stop   = 1e-4

        if ((mark or normg < 1e-4 or alpha0 == 1.0) and s <= 5e4):
            v      = xo.copy()
            H      = FuncH(u, Tu)
            if isinstance(H, tuple): H  = H[0]

            if (s < 200) and (not callable(H)):
                subv     = subu + np.linalg.solve(H, -gx[Tu])
                eps_stop = 1e-8
            else:
                cgit     = min(25, 5 * iter_)
                subv     = subu + _cg(H, -gx[Tu], 1e-10 * n, cgit, np.zeros(s, dtype=np.float64))
            v[Tu]        = subv
            fv           = float(Funcf(v))
            gv           = _v1(Funcg(v))
            if fv <= fu - sigma * _sum_squares(subu - subv):
                x        = v
                fx       = fv
                subu     = subv
                gx       = gv
                normg    = _sum_squares(gx)

        err              = np.sqrt(_sum_squares(gx[Tu])) if Tu.size > 0 else 0.0
        obj              = fx
        OBJ[:-1]         = OBJ[1:]
        OBJ[-1]          = obj

        if disp and (iter_ <= 10 or iter_ % 10 == 0):
            print(f"{iter_:4d}     {err:5.2e}    {fx:9.2e}     {time.perf_counter()-t0:5.3f}sec")

        maxg             = float(np.max(np.abs(gx))) if gx.size else 0.0
        minx             = float(np.min(np.abs(subu))) if (subu is not None and subu.size) else 1.0
        J                = 8
        if err**2 < tol * 1e3 and normg > 1e-2 and iter_ < maxit - 10:
            J            = int(min(8, max(1, np.ceil(maxg / max(minx, 1e-12)) - 1)))

        # "Delayed maxit shrinkage" logic for uppf
        if ('uppf' in pars) and (obj <= uppf) and flag:
            maxit        = int(iter_ + 100 * s / n)
            flag         = 0

        # Track minimum value and check stagnation
        minobj[iter_ + 1] = min(minobj[iter_], fx)
        if fx < minobj[iter_]:
            xmin         = x.copy()
            fmin         = fx

        if iter_ > thd:
            count        = (np.std(minobj[iter_ - thd: iter_ + 1]) < 1e-10)
        else:
            count        = False

        stop1            = (err < tol) and (np.std(OBJ) < eps_stop * (1 + abs(obj)))
        stop2            = (np.sqrt(normg) < tol)
        stop3            = (fx < uppf)

        if iter_ > 1 and (stop1 or stop2 or stop3 or count):
            if count and ('fmin' in locals()) and fmin < fx:
                x        = xmin
                fx       = fmin
            if disp and not (iter_ <= 10 or iter_ % 10 == 0):
                print(f"{iter_:4d}     {err:5.2e}    {fx:9.2e}     {time.perf_counter()-t0:5.3f}sec")
            break

    out = {
        'sol':   x,
        'obj':   fx,
        'iter':  iter_,
        'error': err,
        'time':  time.perf_counter() - t0,
    }

    if disp:
        print(" -------------------------------------------")
        if normg < 1e-10:
            print(f" A global optimal solution may be found")
            print(f" because of ||gradient|| = {np.sqrt(normg):5.3e}!")
            print(" -------------------------------------------")

    return out

def _v1(z):
    a = np.asarray(z, dtype=np.float64)
    return a.reshape(-1)

def _sum_squares(v):
    v = _v1(v)
    return float(np.dot(v, v))

def _topk_abs(x, k):
    """Return indices of the k largest |x| values (unordered), expected O(n) time."""
    x = _v1(x)
    if k <= 0:
        return np.empty(0, dtype=int)
    if k >= x.size:
        return np.arange(x.size, dtype=int)
    idx = np.argpartition(np.abs(x), -k)[-k:]
    return idx
def _cg(Aop, b, tol, iters, x0=None):
    r"""
    Conjugate Gradient: Solve A x = b
    - Aop: ndarray matrix or callable(v)->A v; also supports (H, D) tuple (H is used automatically)
    - b: (k,) 1D array
    - tol: Relative residual threshold
    - iters: Maximum iterations
    - x0: Initial value (optional)
    Returns x (k,) 1D array
    """
    b = _v1(b)
    n = b.size
    if n == 0 or _sum_squares(b) == 0.0:
        return np.zeros(n, dtype=np.float64)

    if x0 is None or x0.size != n:
        x = np.zeros(n, dtype=np.float64)
    else:
        x = _v1(x0).copy()

    def _A(v):
        v = _v1(v)
        A = Aop
        if isinstance(A, tuple):
            A = A[0]
        if callable(A):
            return _v1(A(v))
        else:
            return _v1(A @ v)

    r   = b - _A(x) if np.count_nonzero(x) else b.copy()
    rr  = _sum_squares(r)
    rr0 = rr
    p   = r.copy()

    for _ in range(max(1, iters)):
        if rr <= (tol**2) * rr0:
            break
        Ap    = _A(p)
        denom = float(np.dot(p, Ap))
        if denom == 0.0:
            break
        alpha   = rr / denom
        x      += alpha * p
        r      -= alpha * Ap
        rr_new  = _sum_squares(r)
        beta    = rr_new / rr if rr != 0.0 else 0.0
        p       = r + beta * p
        rr      = rr_new

    return x

def _set_parameters(n, s, pars):
    sigma  = 1e-8
    J      = 1
    flag   = 1
    alpha0 = 5.0
    gamma  = 0.5
    if (s / n) <= 0.05 and n >= 1e4:
        alpha0 = 1.0
        gamma  = 0.1

    if (s / n) <= 0.05:
        thd    = int(np.ceil(np.log2(2 + s) * 50))
    else:
        if n > 1e3:
            thd = 100
        elif n > 500:
            thd = 500
        else:
            thd = int(np.ceil(np.log2(2 + s) * 750))

    disp  = int(pars.get('disp', 1))
    tol   = float(pars.get('tol', 1e-6))
    uppf  = float(pars.get('uppf', -np.inf))
    maxit = int(pars.get('maxit', 10_000))

    return sigma, J, flag, alpha0, gamma, thd, disp, tol, uppf, maxit