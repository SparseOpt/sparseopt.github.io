import time
import numpy as np

def NHTP(func, n, s, pars=None):
    r"""
    ----------------------------------------------------------------------------
    This code aims at solving the sparsity constrained optimization,

            min_{x∈R^n} f(x)  s.t.  ||x||₀<=s

    where f: R^n->R and s<<n is an integer.
    Inputs:---------------------------------------------------------------------
        func: A function handle defines                               (REQUIRED)
                       (objective, gradient, sub-Hessian)
        n   : Dimension of the solution x                             (REQUIRED)
        s   : Sparsity level of x, an integer between 1 and n-1       (REQUIRED)
        pars: Parameters are all optional                             (OPTIONAL)
              pars['x0']    --  Starting point of x         (default zeros(n,1))
              pars['eta']   --  A positive scalar for 'NHTP'         (default 1)
                                Tuning it may improve solution quality
              pars['disp']  --  =1: show results for each step       (default 1)
                                =0: not show results for each step
              pars['maxit'] --  Maximum number of iterations      (default 2000)
              pars['tol']   --  Tolerance of stopping criteria    (default 1e-6)
              pars['uppf']  --  An upper bound of final objective (default -Inf)
                                Useful for noisy case
    Outputs:--------------------------------------------------------------------
        out['sol'] :   The sparse solution x
        out['time']:   CPU time
        out['iter']:   Number of iterations
        out['obj'] :   Objective function value at out['sol']
    ----------------------------------------------------------------------------
    Send your comments and suggestions to <<< slzhou2021@163.com >>>
    WARNING: Accuracy may not be guaranteed!!!!!
    """

    if pars is None:
        pars = {}

    # Interface adaptation
    Funcf    = lambda var: func(_v1(var), 'f', [], [])
    Funcg    = lambda var: func(_v1(var), 'g', [], [])
    FuncH    = lambda var, T, J: func(_v1(var), 'h', T, J)


    # Initialization
    x0, eta, disp, maxit, tol, uppf = _getparameters(n, s, Funcg, pars)
    x        = x0.copy()
    beta     = 0.5
    sigma    = 5e-5
    delta    = 1e-10
    pcgtol   = 0.1 * tol * s

    T0       = np.empty(0, dtype=int)
    Error    = np.zeros(maxit, dtype=np.float64)
    OBJ      = np.zeros(5, dtype=np.float64)

    t0       = time.perf_counter()
    obj      = float(Funcf(x0))
    g        = _v1(Funcg(x0))

    if disp:
        print(" Start to run the solver -- NHTP ")
        print(" -------------------------------------------")
        print("  Iter     Error      Objective       Time ")
        print(" -------------------------------------------")

    # Initial check
    if _sum_squares(g) < 1e-20 and np.count_nonzero(x) <= s:
        if disp:
            print(" Starting point is a good solution. Stop NHTP")
        return {"sol": x, "obj": obj, "iter": 0, "time": time.perf_counter()-t0}

    if np.any(np.isnan(g)):
        x0      = np.zeros(n)
        x0[np.random.randint(n)] = np.random.rand()
        obj     = float(Funcf(x0))
        g       = _v1(Funcg(x0))

    for it in range(1, maxit + 1):
        xtg               = x0 - eta * g
        T                 = _topk_abs(xtg, s)
        T.sort()
        TTc               = np.setdiff1d(T0, T, assume_unique=False)
        flag_same_support = (TTc.size == 0)
        gT                = g[T]

        # Error calculation
        xtaus             = max(0.0, np.max(np.abs(g)) - (np.min(np.abs(x[T])) / eta if T.size>0 else 0.0))
        if flag_same_support:
            FxT           = (_sum_squares(gT)) ** 0.5
            Error[it-1]   = xtaus + FxT
        else:
            FxT           = (_sum_squares(gT) + abs(_sum_squares(x) - _sum_squares(x[T]))) ** 0.5
            Error[it-1]   = xtaus + FxT

        if disp and (it <= 10 or it % 10 == 0):
            print(f"{it:4d}     {Error[it-1]:5.2e}    {obj:9.2e}     {time.perf_counter()-t0:5.3f}sec")

        # Stopping criteria
        OBJ[:-1] = OBJ[1:]
        OBJ[-1]  = obj
        stop1    = (Error[it-1] < tol) and (np.std(OBJ) < 1e-8 * (1 + abs(obj)))
        stop2    = (np.sqrt(_sum_squares(g)) < tol)
        stop3    = (obj < uppf)
        if it > 1 and (stop1 or stop2 or stop3):
            if disp and not (it <= 10 or it % 10 == 0):
                print(f"{it:4d}     {Error[it-1]:5.2e}    {obj:9.2e}     {time.perf_counter()-t0:5.3f}sec")
            break

        # Direction d: use different H/D based on support consistency
        if it == 1 or flag_same_support:
            H        = FuncH(x0, T, T)
            if isinstance(H, tuple):  # Support (H, D) return format
                H    = H[0]
            if callable(H):
                d    = _cg(H, -gT, pcgtol, 25, np.zeros(T.size))
            else:
                d    = np.linalg.solve(H, -gT)
            dg       = float(np.dot(d, gT))
            ngT      = _sum_squares(gT)

            if dg > max(-delta * _sum_squares(d), -ngT) or np.isnan(dg):
                d    = -gT
                dg   = ngT
        else:
            H        = FuncH(x0, T, T)
            D        = FuncH(x0, T, TTc)
            if D is None:
                rhs  = -gT
            elif callable(D):
                rhs  = _v1(D(x0[TTc])) - gT
            else:
                rhs  = _v1(D @ _v1(x0[TTc])) - gT

            if callable(H):
                d    = _cg(H, rhs, pcgtol, 25, np.zeros(T.size))
            else:
                d    = np.linalg.solve(H, rhs)

            Fnz      = _sum_squares(x[TTc]) / (4.0 * eta) if TTc.size > 0 else 0.0
            dgT      = float(np.dot(d, gT))
            dg       = dgT - float(np.dot(x0[TTc], g[TTc])) if TTc.size > 0 else dgT

            delta0   = 1e-4 if Fnz > 1e-4 else delta
            ngT      = _sum_squares(gT)
            if dgT > max(-delta0 * _sum_squares(d) + Fnz, -ngT) or np.isnan(dg):
                d    = -gT
                dg   = ngT

        # Armijo line search
        alpha            = 1.0
        x_new            = np.zeros(n, dtype=np.float64)
        obj0             = obj
        for _ in range(6):
            x_new[:]     = 0.0
            x_new[T]     = x0[T] + alpha * d
            obj_tmp      = Funcf(x_new)
            obj_tmp      = float(obj_tmp)
            if obj_tmp < obj0 + alpha * sigma * dg:
                break
            alpha        *= beta
        x                = x_new
        obj              = obj_tmp

        # HTP fallback: use xtg(T) if obj increases
        fhtp             = 0
        if obj > obj0:
            x[:]         = 0.0
            x[T]         = xtg[T]
            obj          = float(Funcf(x))
            fhtp         = 1

        # "Pause" condition (consistent with original logic)
        flag1            = (abs(obj - obj0) < 1e-6 * (1 + abs(obj)) and fhtp == 1)
        flag2            = (abs(obj - obj0) < 1e-8 * (1 + abs(obj)) and Error[it-1] < 1e-2)
        if it > 10 and (flag1 or flag2):
            if obj > obj0:
                it      -= 1
                x        = x0
                T        = T0
            print(f"{it:4d}     {Error[it-1]:5.2e}    {obj:9.2e}     {time.perf_counter()-t0:5.3f}sec")
            break

        # Prepare for next iteration
        T0               = T
        x0               = x
        obj              = float(Funcf(x))
        g                = _v1(Funcg(x))

        # Update eta
        if it % 50 == 0:
            if Error[it-1] > 1.0 / (it ** 2):
                eta      = (eta / 1.25) if it < 1500 else (eta / 1.5)
            else:
                eta      = eta * 1.15

    out = {
        'time': time.perf_counter() - t0,
        'iter': it,
        'sol':  x,
        'obj':  obj,
    }

    if disp:
        normgrad         = np.sqrt(_sum_squares(g))
        print(" -------------------------------------------")
        if normgrad < 1e-5:
            print(" A global optimal solution might be found")
            print(f" because of ||gradient|| = {normgrad:5.2e}!")
            if out["iter"] > 1500:
                print(f"\n Since the number of iterations reaches to {out['iter']}")
                print(" Try to rerun the solver with setting a smaller pars.eta ")
            print(" -------------------------------------------")

    return out

def _getparameters(n, s, Funcg, pars):
    disp  = int(pars.get('disp', 1))
    maxit = int(pars.get('maxit', 2000))
    tol   = float(pars.get('tol', 1e-6))
    x0    = _v1(pars.get('x0', np.zeros(n, dtype=np.float64)))
    uppf  = float(pars.get('uppf', -np.inf))

    if 'eta' in pars:
        eta          = float(pars['eta'])
    else:
        g1           = Funcg(np.ones(n, dtype=np.float64))
        abg1         = np.abs(_v1(g1))
        T            = np.where(abg1 > 1e-8)[0]
        if T.size == 0:
            eta      = 10.0 * (1.0 + s / n) / min(10.0, np.log(n))
        else:
            maxe     = float(np.sum(1.0 / (abg1[T] + np.finfo(float).eps)) / T.size)
            if maxe > 2:
                eta  = (np.log2(1 + maxe) / np.log2(maxe)) * np.exp((s / n) ** (1 / 3))
            elif maxe < 1:
                eta  = (np.log2(1 + maxe)) * (n / s) ** 0.5
            else:
                eta  = (np.log2(1 + maxe)) * np.exp((s / n) ** (1 / 3))

    return x0, eta, disp, maxit, tol, uppf

def _v1(z):
    a = np.asarray(z, dtype=np.float64)
    return a.reshape(-1)

def _sum_squares(v):
    v = _v1(v)
    return float(np.dot(v, v))

def _topk_abs(x, k):
    """Returns indices of the k largest |x| values (unordered), expected O(n) time."""
    x = _v1(x)
    if k <= 0:
        return np.empty(0, dtype=int)
    if k >= x.size:
        return np.arange(x.size, dtype=int)
    idx = np.argpartition(np.abs(x), -k)[-k:]
    return idx

def _cg(Aop, b, tol, iters, x0=None):
    """
    Conjugate Gradient: Solves A x = b
    - Aop: ndarray matrix or callable(v)->A v
    - b: (k,) 1D array
    - tol: Relative residual threshold
    - iters: Maximum iterations
    - x0: Initial value (optional)
    Returns x (k,) 1D array
    """
    b = _v1(b)
    n = b.size
    if n == 0 or _sum_squares(b) == 0.0:
        return np.zeros(n, dtype=np.float64)

    if x0 is None or x0.size != n:
        x = np.zeros(n, dtype=np.float64)
    else:
        x = _v1(x0).copy()

    def _A(v):
        if callable(Aop):
            return _v1(Aop(_v1(v)))
        else:
            return _v1(Aop @ _v1(v))

    r   = b - _A(x) if np.count_nonzero(x) else b.copy()
    rr  = _sum_squares(r)
    rr0 = rr
    p   = r.copy()

    for _ in range(max(1, iters)):
        if rr <= (tol**2) * rr0:
            break
        Ap       = _A(p)
        denom    = float(np.dot(p, Ap))
        if denom == 0.0:
            break
        alpha    = rr / denom
        x       += alpha * p
        r       -= alpha * Ap
        rr_new   = _sum_squares(r)
        beta     = rr_new / rr if rr != 0.0 else 0.0
        p        = r + beta * p
        rr       = rr_new

    return x