import time
import numpy as np

def IIHT(func, n, s, pars=None):
    r"""
    This code aims at solving the sparsity constrained optimization (SCO),

            min_{x∈R^n} f(x),  s.t. ||x||₀<=s

    or non-negative and sparsity constrained optimization (NSCO):

            min_{x∈R^n} f(x),  s.t. ||x||₀<=s, x>=0

    where f: R^n->R and s<<n is an integer.
    Inputs:--------------------------------------------------------------------
        func: A function handle defines                              (REQUIRED)
                      (objective, gradient, sub-Hessain)
        n   : Dimension of the solution x                            (REQUIRED)
        s   : Sparsity level of x, an integer between 1 and n-1      (REQUIRED)
        pars: Parameters are all OPTIONAL
            pars['x0']    --  Starting point of x          (default zeros(n,1))
            pars['neg']   --  =0 for model (SCO)                    (default 1)
                              =1 for model (NSCO)
            pars['disp']  --  =1: show results for each step        (default 1)
                              =0: not show results for each step
            pars['maxit'] --  Maximum number of iterations       (default 2000)
            pars['tol']   --  Tolerance of stopping criteria     (default 1e-4)
            pars['uppf']  --  An upper bound of final objective  (default -Inf)
                              Useful for noisy case
    Outputs:--------------------------------------------------------------------
        out['sol'] :   The sparse solution x
        out['obj'] :   Objective function value at out['sol']
        out['iter']:   Number of iterations
        out['time']:   CPU time
    ----------------------------------------------------------------------------
    Send your comments and suggestions to <<< slzhou2021@163.com >>>
    WARNING: Accuracy may not be guaranteed!!!!!
    """

    if pars is None:
        pars         = {}

    disp             = int(pars.get('disp', 1))
    maxit            = int(pars.get('maxit', 100))
    tol              = float(pars.get('tol', 1e-6 * np.sqrt(n)))
    neg              = int(pars.get('neg', 0))
    uppf             = float(pars.get('uppf', -np.inf))

    Funcf            = lambda x: func(_v1(x), 'f', [], [])
    Funcg            = lambda x: func(_v1(x), 'g', [], [])

    x                = _v1(pars.get('x0', np.zeros(n, dtype=np.float64)))
    if x.size != n:
        raise ValueError("x0 size mismatch")
    xo               = np.zeros(n, dtype=np.float64)
    OBJ              = np.zeros(5, dtype=np.float64)

    sigma0           = 1e-4

    if disp:
        print(" Start to run the solver -- IIHT ")
        print(" -------------------------------------------")
        print("  Iter     Error      Objective       Time ")
        print(" -------------------------------------------")

    t0               = time.perf_counter()

    # Initial f,g and scaling
    f                = float(Funcf(x))
    g                = _v1(Funcg(x))
    scale            = (max(f, np.linalg.norm(g)) > n)
    scal             = (n if scale else 1)
    fs               = f / scal
    gs               = g / scal

    for it in range(1, maxit + 1):
        x_old         = x.copy()
        fx_old        = fs

        alpha         = np.log1p(it)
        for _ in range(10):
            tp        = x_old - alpha * gs  # Gradient descent step (with scaled gradient gs)

            if neg:
                tp    = np.maximum(0.0, tp)
                T     = _topk_val(tp, s)    # Take s largest values (non-negative case)
            else:
                T     = _topk_abs(tp, s)    # Take s largest absolute values

            x         = xo.copy()
            mx        = tp[T]
            x[T]      = mx

            f_new     = Funcf(x)
            fs        = float(f_new) / scal
            # Armijo condition: fs < fx_old - 0.5*sigma0*||x - x_old||^2
            diff      = x - x_old
            if fs < fx_old - 0.5 * sigma0 * float(np.dot(diff, diff)):
                break
            alpha     *= 0.5

        # Update f,g,fs,gs
        f    = float(Funcf(x))
        g    = _v1(Funcg(x))
        fs   = f / scal
        gs   = g / scal

        OBJ[:-1]  = OBJ[1:]
        OBJ[-1]   = fs
        denom     = max(1.0, np.linalg.norm(mx)) if mx.size > 0 else 1.0
        error     = scal * (np.linalg.norm(gs[T]) if T.size > 0 else 0.0) / denom
        normg     = np.linalg.norm(g)

        if disp and (it <= 10 or it % 10 == 0):
            elapsed = time.perf_counter() - t0
            print(f"{it:4d}     {error:5.2e}    {fs*scal:9.2e}     {elapsed:5.3f}sec")

        # Stopping criteria
        stop1 = (error < tol) and (np.std(OBJ) < 1e-8 * (1 + abs(fs)))
        stop2 = (normg < tol)
        stop3 = (fs * scal < uppf)
        if it > 1 and (stop1 or stop2 or stop3):
            if disp and not (it <= 10 or it % 10 == 0):
                elapsed = time.perf_counter() - t0
                print(f"{it:4d}     {error:5.2e}    {fs*scal:9.2e}     {elapsed:5.3f}sec")
            break

    out = {
        'sol':   x,
        'obj':   fs * scal,
        'iter':  it,
        'time':  time.perf_counter() - t0,
        'error': error,
    }

    if disp:
        print(" -------------------------------------------")
        if normg < 1e-5:
            print(f" A global optimal solution might be found")
            print(f" because of ||gradient||={normg:5.2e}!")
            print(" -------------------------------------------")

    return out
def _v1(z):
    a = np.asarray(z, dtype=np.float64)
    return a.reshape(-1)

def _topk_abs(x, k):
    """Indices of the k largest |x| values (unordered, expected O(n) time)."""
    x = _v1(x)
    if k <= 0:
        return np.empty(0, dtype=int)
    if k >= x.size:
        return np.arange(x.size, dtype=int)
    return np.argpartition(np.abs(x), -k)[-k:]

def _topk_val(x, k):
    """Indices of the k largest values (for non-negativity constraint tp>=0 cases), unordered."""
    x = _v1(x)
    if k <= 0:
        return np.empty(0, dtype=int)
    if k >= x.size:
        return np.arange(x.size, dtype=int)
    return np.argpartition(x, -k)[-k:]