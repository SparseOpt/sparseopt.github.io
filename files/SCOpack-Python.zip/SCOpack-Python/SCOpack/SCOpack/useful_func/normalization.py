import numpy as np
import time
from scipy import sparse as sp

def normalization(X, normal_type=0):
    """
    Normalize the input matrix X.

    Parameters
    ----------
    X : ndarray or scipy.sparse matrix (m x n)
        Input matrix to be normalized.
    normal_type : int
        0: no normalization
        1: row-wise then column-wise normalization
           - dense: (row mean-centering / std) then (column mean-centering / std)
           - sparse: to preserve sparsity, perform std scaling only (no mean-centering)
        2: feature-wise scale to [-1, 1] via column max-abs
        3: feature-wise scale to unit-norm columns (L2=1)

    Returns
    -------
    NX : same type as input
        Normalized matrix. Sparse input yields sparse output; dense input yields ndarray.
    """
    t0 = time.time()
    is_sparse = (sp is not None) and sp.issparse(X)

    if normal_type == 0:
        NX = X.copy() if hasattr(X, "copy") else np.array(X, copy=True)
        if is_sparse:
            NX = _sparse_naninf_to_zero(NX)
        else:
            NX = np.nan_to_num(NX, nan=0.0, posinf=0.0, neginf=0.0)
        print(f"Normalization used {time.time() - t0:.4f} seconds.")
        return NX

    # Sparse branch
    if is_sparse:
        orig_fmt = X.getformat()
        m, n     = X.shape

        if normal_type == 2:
            Xc    = X.tocsc(copy=True)
            denom = _csc_col_max_abs(Xc)
            Dinv  = sp.diags(1.0 / denom, shape=(n, n), format="csc")
            NX    = Xc @ Dinv
            NX    = _sparse_naninf_to_zero(NX)
            NX    = NX.asformat(orig_fmt)
            print(f"Normalization used {time.time() - t0:.4f} seconds.")
            return NX

        if normal_type == 3:
            Xc    = X.tocsc(copy=True)
            denom = _csc_col_l2norm(Xc)
            Dinv  = sp.diags(1.0 / denom, shape=(n, n), format="csc")
            NX    = Xc @ Dinv
            NX    = _sparse_naninf_to_zero(NX)
            NX    = NX.asformat(orig_fmt)
            print(f"Normalization used {time.time() - t0:.4f} seconds.")
            return NX

        if normal_type == 1:
            Xr      = X.tocsr(copy=True)
            row_std = _csr_row_std(Xr, ncols=n)
            Rinv    = sp.diags(1.0 / row_std, shape=(m, m), format="csr")
            X1      = Rinv @ Xr

            X1c     = X1.tocsc()
            col_std = _csc_col_std(X1c, nrows=m)
            Dinv    = sp.diags(1.0 / col_std, shape=(n, n), format="csc")
            NX      = X1c @ Dinv

            NX      = _sparse_naninf_to_zero(NX)
            NX      = NX.asformat(orig_fmt)
            print(f"Normalization used {time.time() - t0:.4f} seconds.")
            return NX

        raise ValueError("Unsupported normal_type for sparse input.")

    # Dense branch
    Xd = np.array(X, dtype=float, copy=True)

    if normal_type == 1:
        C                     = Xd - np.mean(Xd, axis=1, keepdims=True)
        row_std               = np.std(Xd, axis=1, ddof=1, keepdims=True)
        row_std[row_std == 0] = 1.0
        Yrow                  = C / row_std

        Y                     = Yrow.T
        D                     = Y - np.mean(Y, axis=1, keepdims=True)
        col_std               = np.std(Y, axis=1, ddof=1, keepdims=True)
        col_std[col_std == 0] = 1.0
        Ycol = D / col_std
        NX = Ycol.T

        if np.isnan(NX).any() or np.isinf(NX).any():
            denom             = np.sqrt(np.sum(Xd * Xd, axis=0))
            denom[denom == 0] = 1.0
            NX                = Xd * (1.0 / denom)

        NX = np.nan_to_num(NX, nan=0.0, posinf=0.0, neginf=0.0)
        print(f"Normalization used {time.time() - t0:.4f} seconds.")
        return NX

    if normal_type == 2:
        denom = np.max(np.abs(Xd), axis=0)
    elif normal_type == 3:
        denom = np.sqrt(np.sum(Xd * Xd, axis=0))
    else:
        raise ValueError("Unsupported normal_type.")

    denom[denom == 0] = 1.0
    inv               = 1.0 / denom
    n                 = inv.size

    if n <= 10000:
        NX = Xd * inv
    else:
        k         = 5000
        nnz_ratio = np.count_nonzero(Xd) / (Xd.shape[0] * Xd.shape[1])
        if nnz_ratio < 1e-4:
            k = 100000
        K = int(np.ceil(n / k))
        for i in range(K - 1):
            T        = slice(i * k, (i + 1) * k)
            Xd[:, T] = Xd[:, T] * inv[T]
        T        = slice((K - 1) * k, n)
        Xd[:, T] = Xd[:, T] * inv[T]
        NX       = Xd

    NX = np.nan_to_num(NX, nan=0.0, posinf=0.0, neginf=0.0)
    print(f"Normalization used {time.time() - t0:.4f} seconds.")
    return NX


def _sparse_naninf_to_zero(S):
    if sp is not None and sp.issparse(S):
        data = S.data
        bad  = ~np.isfinite(data)
        if np.any(bad):
            data[bad] = 0.0
    return S

def _csr_row_std(csr, ncols):
    m      = csr.shape[0]
    indptr = csr.indptr
    data   = csr.data
    sums   = np.zeros(m, dtype=float)
    sumsq  =  np.zeros(m, dtype=float)
    for i in range(m):
        s, e = indptr[i], indptr[i+1]
        if s < e:
            di       = data[s:e]
            sums[i]  = di.sum()
            sumsq[i] = np.dot(di, di)
    if ncols > 1:
        mean         = sums / ncols
        var          = (sumsq - ncols * (mean ** 2)) / (ncols - 1)
        var[var < 0] = 0.0
        std          = np.sqrt(var)
    else:
        std = np.ones(m, dtype=float)
    std[std == 0] = 1.0
    return std

def _csc_col_std(csc, nrows):
    n      = csc.shape[1]
    indptr = csc.indptr
    data   = csc.data
    sums   = np.zeros(n, dtype=float)
    sumsq  = np.zeros(n, dtype=float)
    for j in range(n):
        s, e = indptr[j], indptr[j+1]
        if s < e:
            dj       = data[s:e]
            sums[j]  = dj.sum()
            sumsq[j] = np.dot(dj, dj)
    if nrows > 1:
        mean         = sums / nrows
        var          = (sumsq - nrows * (mean ** 2)) / (nrows - 1)
        var[var < 0] = 0.0
        std          = np.sqrt(var)
    else:
        std = np.ones(n, dtype=float)
    std[std == 0] = 1.0
    return std

def _csc_col_max_abs(csc):
    n      = csc.shape[1]
    indptr = csc.indptr
    data   = csc.data
    out    = np.zeros(n, dtype=float)
    for j in range(n):
        s, e = indptr[j], indptr[j+1]
        if s < e:
            out[j] = np.max(np.abs(data[s:e]))
    out[out == 0] = 1.0
    return out

def _csc_col_l2norm(csc):
    n      = csc.shape[1]
    indptr = csc.indptr
    data   = csc.data
    out    = np.zeros(n, dtype=float)
    for j in range(n):
        s, e = indptr[j], indptr[j+1]
        if s < e:
            dj = data[s:e]
            out[j] = np.sqrt(np.dot(dj, dj))
    out[out == 0] = 1.0
    return out
