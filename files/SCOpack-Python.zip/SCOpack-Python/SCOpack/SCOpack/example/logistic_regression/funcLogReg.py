import numpy as np
from scipy.sparse import eye as speye

def funcLogReg(x, key, T1, T2, data):

    A  = data['A']
    b  = data['b']
    m  = len(b)
    mu = 1e-6 / m
    
    # Ensure x is a column vector
    if x.ndim == 1:
        x = x.reshape(-1, 1)
    
    # Sparse or dense matrix-vector product
    if np.count_nonzero(x) >= 0.025 * len(x):
        Ax = A @ x
    else:
        Tx = np.flatnonzero(x)
        if len(Tx) > 0:
            Ax = A[:, Tx] @ x[Tx]
        else:
            Ax = np.zeros((m, 1))
    
    # Flatten Ax for element-wise operations
    Ax = Ax.flatten()
    eAx = np.exp(Ax)
    
    if key == 'f' :
        # Handle potential overflow from exp(Ax)
        if np.sum(eAx) == np.inf:
            Tpos = np.where(Ax > 300)[0]
            Tneg = np.setdiff1d(np.arange(m), Tpos)
            
            obj = 0
            if len(Tneg) > 0:
                obj += np.sum(np.log(1 + eAx[Tneg]))
            if len(Tpos) > 0:
                obj += np.sum(Ax[Tpos])
            obj -= np.sum(b * Ax)
        else:
            obj = np.sum(np.log(1 + eAx) - b * Ax)
        
        out = obj / m  # objective function

    elif key == 'g':
        grad_coeff = 1 - b - 1.0 / (1 + eAx)
        out = A.T @ grad_coeff.reshape(-1, 1) / m + mu * x  # gradient
    
    elif key == 'h' :
        eXx = 1.0 / (1 + eAx)
        d   = eXx * (1 - eXx) / m
        # submatrix containing T1 rows and T2 columns of Hessian
        def sub_hessian_func(v):
            AT2v  = A[:, T2] @ v
            dAT2v = d.reshape(-1, 1) * AT2v.reshape(-1, 1)
            return A[:, T1].T @ dAT2v
        if np.array_equal(np.ravel(T1), np.ravel(T2)):
            s = len(T1)
            if s < 1000:
                # submatrix containing T1 rows and T1 columns of Hessian
                dXT = A[:, T1] * d.reshape(-1, 1)
                out = dXT.T @ A[:, T1] + mu * speye(s)
            else:
                def hessian_func(v):
                    return mu * v + sub_hessian_func
                out = hessian_func
        else :
                out = sub_hessian_func
                
    return out
