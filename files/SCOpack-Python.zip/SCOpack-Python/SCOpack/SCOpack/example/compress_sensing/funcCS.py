import numpy as np

def funcCS(x, key, T1, T2, data):
    x = np.asarray(x).reshape(-1)              
    A = data['A']
    b = np.asarray(data['b']).reshape(-1)     

    A_is_callable = callable(A)

    if not A_is_callable:
        if key == 'f':
            if np.count_nonzero(x) >= 0.025 * x.size:
                Axb = A @ x - b
            else:
                Tx = np.flatnonzero(x)
                if Tx.size == 0:
                    Axb = -b
                else:
                    Axb = A[:, Tx] @ x[Tx] - b
            out = 0.5 * np.linalg.norm(Axb)**2

        elif key == 'g':
            if np.count_nonzero(x) >= 0.025 * x.size:
                Axb = A @ x - b
            else:
                Tx = np.flatnonzero(x)
                if Tx.size == 0:
                    Axb = - b
                else:
                    Axb = A[:, Tx] @ x[Tx] - b
            out = A.T @ Axb                  

        elif key == 'h':
            if max(len(T1), len(T2)) <= 1e3 and len(x) <= 5e3:
                out = A[:, T1].T @ A[:, T2]
            else:
                AT1 = A[:, T1].T
                AT2 = A[:, T2]
                out = lambda var: AT1 @ (AT2 @ np.asarray(var).reshape(-1))
        else:
            raise ValueError("key must be 'f'/'g'/'h'")

    else:
        At = data['At']
        if key == 'f':
            Axb = np.asarray(A(x)).reshape(-1) - b
            out = 0.5 * np.linalg.norm(Axb)**2

        elif key == 'g':
            Axb = np.asarray(A(x)).reshape(-1)- b
            out = At(Axb)                     

        elif key == 'h':
            Hess_func = _fgH(data)
            out = lambda var: Hess_func(np.asarray(var).reshape(-1), T1, T2)
        else:
            raise ValueError("key must be 'f'/'g'/'h'")

    return out


def _supp(n, x, T):
    z = np.zeros(n)
    z[np.asarray(T, dtype=int)] = x
    return z

def _fgH(data):
    A, At = data['A'], data['At']
    n = data.get('n')
    if n is None:
        raise ValueError("When data.A is a function, data.n must be provided.")

    def Hess(z, t1, t2):
        z_supp = _supp(n, z, t2)
        Az = A(z_supp)
        Az = np.asarray(Az).reshape(-1)
        AtAz = At(Az)
        return AtAz[np.asarray(t1, dtype=int)]
    return Hess