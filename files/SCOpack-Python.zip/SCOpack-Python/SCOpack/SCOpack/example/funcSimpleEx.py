
import numpy as np

def funcSimpleEx(x, key, T1=None, T2=None):
    r"""
    Python translation of funcSimpleEx.m
    This code provides information for the optimization problem:
        min   x.T @ [[6, 5], [5, 8]] @ x + [1, 9] @ x - sqrt(x.T @ x + 1)
    """
    x     = np.asarray(x).reshape(-1, 1)
    A     = np.array([[6.0, 5.0], [5.0, 8.0]])
    b_row = np.array([1.0, 9.0])
    b_col = b_row.reshape(-1, 1)
    a     = np.sqrt(np.sum(x * x) + 1)
    if key == 'f':
        out = (x.T @ A @ x + b_row @ x - a).item()
    elif key == 'g':
        out = 2 * (A @ x) + b_col - x / a
    elif key == 'h':
        H   = 2 * A + (x @ x.T - a * np.eye(2)) / (a**3)
        out = H[np.ix_(T1, T2)]
    return out