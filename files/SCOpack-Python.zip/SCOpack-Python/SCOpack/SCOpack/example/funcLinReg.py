import numpy as np

def funcLinReg(x, key, T1, T2, A, b, compute_out2=True):
    r"""
    This code provides information for
         min   0.5*||Ax-b||^2
     where A in R^{m x n} and b in R^{m x 1}
    """
    x    = np.asarray(x).ravel()
    nnz  = int(np.count_nonzero(x))
    frac = nnz / max(1, x.size)
    if  key == 'f':
        Tx   = np.nonzero(x)[0]
        if frac < 0.02:
            Axb = A[:, Tx] @ x[Tx] - b.ravel()
        else: 
            Axb = A @ x - b.ravel()
        out  = 0.5 * (Axb @ Axb)
    elif key == 'g':
        Tx   = np.nonzero(x)[0]
        if frac < 0.02:
            Axb = A[:, Tx] @ x[Tx] - b.ravel()
        else:
            Axb = A @ x - b.ravel()
        out  = A.T @ Axb
    elif key == 'h':
        out  = A[:, T1].T @ A[:, T2]
    return out