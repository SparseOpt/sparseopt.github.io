import warnings
from typing import Callable, Dict, Any, Optional
from .solver.GPNP import GPNP
from .solver.IIHT import IIHT
from .solver.NHTP import NHTP


def SCOpack(func: Callable, n: int, s: int, solvername: str, pars: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    r"""
    This code aims at solving the sparsity constrained optimization (SCO),

         min_{x\in R^n} f(x),  s.t. ||x||_0<=s

    or non-negative and sparsity constrained optimization (NSCO):

         min_{x\in R^n} f(x),  s.t. ||x||_0<=s, x>=0

    where f: R^n->R and s<<n is an integer.

    Inputs ----------------------------------------------------------------------------
     func  : A function handle defines                                       (REQUIRED)
                   (objective,gradient,sub-Hessain)
     n     : Dimension of the solution x                                     (REQUIRED)
     s     : Sparsity level of x, an integer between 1 and n-1               (REQUIRED)
     solver: A text string, can be one of {'NHTP','GPNP','IIHT'}             (REQUIRED)
     pars:   Parameters are optional                                         (OPTIONAL)
            --------------- For all solvers -------------------------------------------
            pars['x0']    --  Starting point of x                  (default zeros(n,1))
            pars['disp']  --  =1: show results for each step                (default 1)
                              =0: not show results for each step
            pars['maxit'] --  Maximum number of iterations               (default  2e3)
            pars['tol']   --  Tolerance of halting conditions            (default 1e-6)
            pars['uppf']  --  An upper bound of final objective          (default -Inf)
                              Useful for noisy case
            --------------- Particular for NHTP ---------------------------------------
            pars['eta']   --  A positive scalar                             (default 1)
                              Tuning it may improve solution quality
            --------------- Particular for IIHT ---------------------------------------
            pars['neg']   --  =0: for model (SCO)                           (default 1)
                              =1: for model (NSCO)
    Outputs:---------------------------------------------------------------------------
        out['sol'] :   The sparse solution x
        out['obj'] :   Objective function value at out['sol']
        out['iter']:   Number of iterations
        out['time']:   CPU time
    """
    if pars is None:
        pars = {}

    warnings.filterwarnings('ignore')

    solvers = {
        'NHTP': NHTP,
        'GPNP': GPNP,
        'IIHT': IIHT
    }

    if solvername not in solvers:
        raise ValueError(f"Invalid solver name. Must be one of {list(solvers.keys())}")

    solver = solvers[solvername]
    out    = solver(func, n, s, pars)

    return out