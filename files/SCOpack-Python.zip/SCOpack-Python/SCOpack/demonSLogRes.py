# Demon sparse logistic regression
import math, os
import numpy as np
import scipy.io as sio
from SCOpack import SCOpack, funcLogReg, normalization

test = 1

if test == 1: # Using random data
    n            = 10000
    m            = math.ceil(n / 5)
    s            = math.ceil(0.05 * n)

    data         = {'A': np.random.randn(m, n)}
    true_weights = np.random.randn(s, 1)
    T            = np.random.choice(n,s,False)
    q            = 1.0 / (1.0 + np.exp(-data['A'][:, T] @ true_weights))
    data['b']    = np.array([np.random.choice([0, 1], p=[1 - p_i[0], p_i[0]]) for p_i in q])

elif test == 2: # Using real data
    script_path = os.path.dirname(os.path.abspath(__file__))
    data_folder = os.path.join(script_path, 'SCOpack', 'example', 'logistic_regression', 'real_data')
    prob        = 'colon-cancer'

    path_A      = os.path.join(data_folder, f'{prob}.mat')
    path_b      = os.path.join(data_folder, f'{prob}_label.mat')

    mat_A       = sio.loadmat(path_A)
    mat_b       = sio.loadmat(path_b)

    A           = mat_A['A']
    b           = mat_b['b'].flatten()
    b[b == -1]  = 0

    m, n        = A.shape
    s           = math.ceil(0.25 * m)
    data        = {'A':normalization(A, 1 + (m >= 1000)), 'b': b}

func        = lambda x, key, T1, T2: funcLogReg(x, key, T1, T2, data)
lambda_val  = 0.01
pars        = {'disp': 1, 'eta': 1}
solvers     = ['NHTP', 'GPNP', 'IIHT']
out         = SCOpack(func, n, s, solvers[0], pars)

print(f" Logistic loss:   {out['obj']:5.2e}")
print(f" CPU time:        {out['time']:.3f}sec")
print(f" Sample size:     {m}x{n}")


