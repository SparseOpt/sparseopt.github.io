# demon a simple sparsity constrained problem
from SCOpack import SCOpack, funcSimpleEx

n       = 2
s       = 1
func    = funcSimpleEx
solvers = ['NHTP', 'GPNP', 'IIHT']
pars    = {'eta': 0.1}
out     = SCOpack(func, n, s, solvers[0], pars)

print(f" {'iteration count:':<20}{out['iter']:<4d}")
print(f" {'Objective:':<20}{out['obj']:5.2e}")
print(f" {'CPU time:':<20}{out['time']:.3f}sec")