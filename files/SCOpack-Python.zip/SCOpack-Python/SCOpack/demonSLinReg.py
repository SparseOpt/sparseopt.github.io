# Demon sparse linear regression
import numpy as np
from SCOpack import SCOpack, PlotRecovery, funcLinReg 

n        = 2000
m        = int(np.ceil(0.25 * n))
s        = int(np.ceil(0.05 * n))

Tx       = np.random.choice(n, size=s, replace=False)
xopt     = np.zeros((n, 1))
xopt[Tx] = np.random.standard_normal((s, 1))
A        = np.random.standard_normal((m, n)) / np.sqrt(m)
b        = A @ xopt

func     = lambda x, key, T1, T2: funcLinReg(x, key, T1, T2, A, b)
pars     = {'disp': 1}
solver   = ['NHTP', 'GPNP', 'IIHT']
out      = SCOpack(func, n, s, solver[1], pars)

PlotRecovery(xopt, out['sol'], [900, 500, 500, 250], 1)