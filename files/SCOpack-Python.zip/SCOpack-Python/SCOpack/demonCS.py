# Demon compressive sensing
import numpy as np
import scipy.sparse as sp
from SCOpack import funcCS, PlotRecovery, SCOpack

n         = 20000
m         = int(np.ceil(0.25 * n))
s         = int(np.ceil(0.05 * n))
nf        = 0.00

Tx        = np.random.choice(n, s, replace=False)
xopt      = np.zeros((n,1))
xopt[Tx]  = np.random.randn(s,1)
A         = np.random.randn(m, n)
data      = {'A': A / (np.log(m) if sp.issparse(A) else np.sqrt(m))}
data['b'] = data['A'] @ xopt + nf * np.random.randn(m, 1)

func      = lambda x, key, T1, T2: funcCS(x, key, T1, T2, data)
pars      = {'tol': 1e-6}
if nf > 0: pars['eta'] = 0.5
solver    = ['NHTP', 'GPNP', 'IIHT']
out       = SCOpack(func, n, s, solver[1], pars)

true_obj  = 0.5 * np.linalg.norm(data['A'] @ xopt - data['b'])**2
print(f" CPU time:          {out['time']: .3f}sec")
print(f" Objective:         {out['obj']: .2e}")
print(f" True Objective:    {true_obj: .2e}")
print(f" Sample size:        {m}x{n}")

PlotRecovery(xopt, out['sol'], [900, 500, 500, 250], ind=1)