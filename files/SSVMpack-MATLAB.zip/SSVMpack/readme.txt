
Please run demonXXXX.m to solve the sparse support vector machine problems

This package contains 2 algorithms developed in the following 2 papers:

NM01-----------------------------------------------------------------------
   Shenglong Zhou, Lili Pan, Naihua Xiu and Huoduo Qi, 
   Quadratic convergence of smoothing Newton's method for 0/1 loss optimization, 
   SIAM Journal on Optimization, 31, 3184–3211, 2021.

GPSP-----------------------------------------------------------------------
   Shenglong Zhou, Ziyan Luo, Naihua Xiu, Geoffrey Ye Li,
   Computing one-bit compressed sensing via double sparsity constrained optimization,
   IEEE Transactions on Signal Processing, vol. 70, pp. 1593-1608, 2022.

Please credit them if you use the code for your research.
