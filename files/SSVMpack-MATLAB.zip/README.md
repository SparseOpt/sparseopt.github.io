# 1BCSpack

Please run demon_XXXX.m to solve the one-bit compressive sensing problems

This source code contains 2 algorithms developed in the following 2 papers:

## GPSP 
  Shenglong Zhou, 
  Sparse SVM for sufficient data reduction, 
  IEEE Transactions on Pattern Analysis and Machine Intelligence, 44, 5560-5571, 2022.

## NM01 
   Shenglong Zhou, Lili Pan, Naihua Xiu and Huoduo Qi, 
   Quadratic convergence of smoothing Newton's method for 0/1 loss optimization, 
   SIAM Journal on Optimization, 31, 3184–3211, 2021.

Please credit them if you use the code for your research.


