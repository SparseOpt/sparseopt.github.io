function [out1,out2] = funcLogReg(x,key,T1,T2,data)
  
   if  nnz(x) >= 0.8*length(x)
       Ax  = data.A*x; 
   else
       Tx  = find(x); 
       Ax  = data.A(:,Tx)*x(Tx); 
   end
    m      = length(data.b);
    eAx    = exp(Ax);
    mu     = 1e-6/m; 
        
    switch key
        case 'fg'
            if  sum(eAx)==Inf 
                Tpos = find(Ax>300); 
                Tneg = setdiff(1:m,Tpos);
                obj  = sum(log(1+eAx(Tneg)))+sum(Ax(Tpos))-sum(data.b.*Ax);                
            else
                obj  = sum(log(1+eAx)-data.b.*Ax); 
            end
            out1 = obj/m;                                     %objective function 
            if  nargout == 2 
                fAt   = @(var)(var'*data.A)';
                out2  = fAt(1-data.b-1./(1+eAx))/m + mu*x;         %gradien
            end
        
        case 'h'
            eXx  = 1./(1+eAx);
            d    = eXx.*(1-eXx)/m; 
            XT   = data.A(:,T1);
            s    = length(T1);
            if s < 1000
                out1 = (d.*XT)'*XT + mu*speye(s);           %submatrix  containing T1 rows and T1 columns of Hessian
            else
                out1 = @(v)( mu*v+( (d.*(XT*v))'*XT )' );
            end
            if nargout == 2
                out2 = @(v)( (d.*(data.A(:,T2)*v))'*XT )';  %submatrix  containing T1 rows and T2 columns of Hessian   
            end
    end
     
end



