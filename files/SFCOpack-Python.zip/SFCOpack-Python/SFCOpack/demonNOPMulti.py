# demon NOP problems by multiple runs
from scipy.stats import chi2
import numpy as np
from SNSCOpack import SNSCO, FuncfNOP, FuncGNOP

K     = 10
M     = 10
N     = 100
alpha = 0.05
s     = int(np.ceil(alpha * N))

b     = 5
c     = np.sqrt(2 * b / chi2.ppf((1 - s / N) ** (1 / M), K))

xi    = np.zeros((K, M, N))
if M == 1:
    xi = np.random.randn(K, M, N)
else:
    E  = np.tile(np.arange(1, K + 1).reshape(-1, 1) / K, (1, M))
    C  = 0.5 * np.ones((M, M)) + 0.5 * np.eye(M)

    for n in range(N):
        temp_slice = np.zeros((K, M))
        for k in range(K):
            temp_slice[k, :] = np.random.multivariate_normal(E[k, :], C)
        xi[:, :, n] = temp_slice
lam          = 1 / c / 2
A            = (xi ** 2).reshape((K, M * N), order='F')

Funcf        = lambda x: FuncfNOP(x, lam)
FuncG        = lambda x, W, J: FuncGNOP(x, W, J, A, b, K, M, N)
P            = int(20 - 10 * (alpha == 0.01))
pars         = {'tau0': np.logspace(np.log10(0.05), np.log10(1.5), P)}
out          = SNSCO(K, M, N, s, Funcf, FuncG, 'Box',0,float('inf'),pars)
print(f'\n\n    Solving the problem under the best tau = {out["tau"]:.4f}')
print(' ------------------------------------------------------------')
pars['tau0'] = np.array([out['tau']])
out          = SNSCO(K, M, N, s, Funcf, FuncG, 'Box',0,float('inf'),pars)