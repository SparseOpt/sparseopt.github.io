# demon recovery problems by one run
import numpy as np
from SNSCOpack import SNSCO, FuncfRecovery, FuncGRecovery

K     = 10
M     = 10
N     = 100
alpha = 0.05
s     = int(np.ceil(alpha * N))

# test = 1: Omega = [lb,ub]^n
# test = 2: Omega = {x|norm(x) <= r}
# test = 3: Omega = {x|a'*x <= b}
# test = 4: Omega = {x|Ax = b}
test      = 1
sets_list = ['Box', 'Ball', 'Halfspace', 'Hyperplane']

xopt      = None
if test   == 1:
    input1 = -0.2
    input2 = 0.2
    xopt   = max(-10,input1) + (min(10,input2)-max(-10,input1)) * np.random.rand(K, 1)
elif test == 2:
    input1 = 2
    input2 = None
    xopt   = np.random.randn(K, 1)
    xopt   = input1 / np.linalg.norm(xopt) * xopt
elif test == 3:
    xopt   = np.random.rand(K, 1)
    input1 = np.random.randn(K, 1)
    input2 = (input1.T @ xopt).item() + np.random.rand()
elif test == 4:
    input1 = np.random.randn(int(np.ceil(0.5 * K)), K)
    xopt   = np.random.randn(K, 1)
    input2 = input1 @ xopt

B       = np.random.randn(int(np.ceil(0.25 * K)), K) / np.sqrt(K)
d       = B @ xopt
BtB     = B.T @ B
xi      = np.random.randn(K, M, N)
T       = np.random.choice(N, s, replace=False)
Mat     = np.random.rand(M, N)
D       = (Mat >= 0.5) * np.random.rand(M, N)
D[:, T] = (Mat[:,T]<1/3) * np.random.rand(M, len(T))-(Mat[:,T]>=2/3) * np.random.rand(M,len(T))
A       = xi.reshape((K, M * N), order='F')
C       = np.einsum('imn,i->mn', xi, xopt.flatten())**2 + D


Funcf = lambda x: FuncfRecovery(x, B, d, BtB)                   # f(x) = ||Bx-d||^2 / 2
FuncG = lambda x, W, J: FuncGRecovery(x, W, J, A, C, K, M, N)   # G(x)_ij = <A_ij,x>^2 - C_ij
pars  = {}
if alpha > 0.01:
    pars['tau0'] = np.array([0.05])
else:
    pars['tau0'] = np.array([0.01])
    pars['thd']  = 1e-1 * (test == 4) + 1e-2 * (test != 4)
out     = SNSCO(K, M, N, s, Funcf, FuncG, sets_list[test-1], input1, input2,  pars)
rel_err = np.linalg.norm(out['x'] - xopt) / np.linalg.norm(xopt)
print(f' Relerr:          {rel_err:7.3e}')