import numpy as np


def FuncGNOP(x, W, Ind, A, b, K, M, N):
    r"""
    This code provides information for function G(x): R^K -> R^{M x N)
    (x,W,Ind) are variables
    (A,C,K,M,N) are data and parameters, and need to be input
    For each i=l,...,M and j=1,...,N:
              G_{ij}(x)=<A_{:,(j-1)*M+i}，x>2-C {ij}
    where A_{:,(j-1)*M+i} is the((j-1)*M+i)th column of A
    A \in R^{k by M*N} and C \in R^{M by N}
    """
    G = (((x ** 2) / 2).T @ A - b).reshape((M, N), order='F')   # function

    if Ind is None or Ind.size == 0:
        gradG  = np.array([])
        gradGW = np.zeros((K, 1))                               # gradient
        hessGW = np.zeros((K, 1))                               # Hessian
    else:
        AInd       = A[:, Ind]
        gradG      = x * AInd
        W_selected = W.flatten(order='F')[Ind].reshape(-1, 1)
        hessGW     = AInd @ W_selected
        gradGW     = x * hessGW                                 # gradient
        hessGW     = np.diag(hessGW.flatten())                  # Hessian

    return G, gradG, gradGW, hessGW