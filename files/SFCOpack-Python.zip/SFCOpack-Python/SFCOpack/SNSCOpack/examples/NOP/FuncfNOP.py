import numpy as np


def FuncfNOP(x, lambda_param):
    r"""
    This code provides information for an objective function
        f(x) = (0.5*lambda)*||x||^2-<1,x>
    x is the variable
    lambda is the parameter and needs to be input
    """
    objef = (lambda_param / 2) * np.linalg.norm(x) ** 2 - np.sum(x) # objective

    gradf = lambda_param * x - 1                                    # gradient

    hessf = lambda_param * np.eye(len(x))                           # Hessian

    return objef, gradf, hessf