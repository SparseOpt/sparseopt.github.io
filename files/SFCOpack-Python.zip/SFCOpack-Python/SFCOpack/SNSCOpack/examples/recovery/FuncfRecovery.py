import numpy as np


def FuncfRecovery(x, B, d, BtB):
    r"""
    This code provides information for an objective function
         f(x) = 0.5*||Bx-d||^2
     x is the variable
     (B,d,BtB) are data and need to be input
     B\in R^{m by n}, d\in R^{m by 1}, and BtB = B'*B
     """
    Bxd   = B @ x - d

    objef = np.linalg.norm(Bxd) ** 2 / 2 # objective

    gradf = B.T @ Bxd                    # gradient

    hessf = BtB                          # Hessian

    return objef, gradf, hessf