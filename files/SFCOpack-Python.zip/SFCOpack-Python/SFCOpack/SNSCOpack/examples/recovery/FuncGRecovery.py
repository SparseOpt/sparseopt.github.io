import numpy as np


def FuncGRecovery(x, W, Ind, A, C, K, M, N):
    r"""
    This code provides information for function G(x): R^K -> R^{M x N)
    (x,W,Ind) are variables
    (A,C,K,M,N) are data and parameters, and need to be input
    For each i=l,...,M and j=1,...,N:
              G_{ij}(x)=<A_{:,(j-1)*M+i}，x>2-C {ij}
    where A_{:,(j-1)*M+i} is the((j-1)*M+i)th column of A
    A \in R^{k by M*N} and C \in R^{M by N}
    """
    G0 = x.T @ A
    G  = G0.reshape((M, N), order='F')
    G  = G ** 2 - C                             # function

    if Ind is None or Ind.size == 0:
        gradG  = np.array([])
        gradGW = np.zeros((K, 1))               # gradient
        hessGW = np.zeros((K, 1))               # Hessian
    else:
        AInd   = A[:, Ind]
        gradG  = AInd * G0[0, Ind]
        WInd   = W.flatten(order='F')[Ind]
        gradGW = gradG @ WInd.reshape(-1, 1)    # gradient
        hessGW = AInd @ np.diag(WInd) @ AInd.T  # Hessian

    return G, gradG, gradGW, hessGW