import numpy as np
import time
import warnings
from scipy.linalg import solve as linsolve
from scipy.linalg import LinAlgError

warnings.filterwarnings('ignore', category=RuntimeWarning)


def SNSCO(K, M, N, s, Funcf, FuncG, FeaSet, input1, input2, pars=None):
    r"""
    This solver solves 0/1 constrained optimization in the following form:

          min_{x \in \R^K} f(x),  s.t. \| G(x) \|^+_0<=s, x \in Omega
    where
          f(x) : \R^K --> \R
          G(x) : \R^K --> \R^{M-by-N}
          s << N
          \|Z\|^+_0 counts the number of columns with positive maximal values
          Omega is a closed and convex set
    =========================================================================
    Inputs:
       K       : Dimnesion of variable x                             (REQUIRED)
       M       : Row number of G(x)                                  (REQUIRED)
       N       : Column number of G(x)                               (REQUIRED)
       s       : An integer in [1,N), typical choice ceil(0.01*N)    (REQUIRED)
       Funcf   : Function handle of f(x)                             (REQUIRED)
       FuncG   : Function handle of G(x)                             (REQUIRED)
       FeaSet  : Feasible set for x, must be one of:                 (REQUIRED)
                 'Box'                [lb,ub]^K,
                 'Ball'               {x|norm(x) <= r},
                 'Halfspace',         {x|a'*x <= b},
                 'Hyperplane'.        {x|Ax = b},
                 Default:             R^K
       input1  : A parameter related to FeaSet                      (REQUIRED)
       input2  : A parameter related to FeaSet                      (REQUIRED)
       pars    : All parameters are OPTIONAL
                 pars['x0']      -- Initial point (default:np.ones((K,1)))
                 pars['tau0']    -- A vector containing a number of parameter tau (default:1)
                                    e.g., pars['tau0'] = np.logspace(np.log10(0.5),np.log10(1.75),50);
                 pars['tol']     -- Tolerance of the halting condition (default:1e-6*M*N)
                 pars['maxit']   -- Maximum number of iterations (default: 2000)
                 pars['disp']    -- Display results or not for each iteration (default:1)
    =========================================================================
    Outputs:
          out['x']:     Solution x
          out['obj']:   Objective function value f(x)
          out['G']:     Function value of G(x)
          out['time']:  CPU time
          out['iter']:  Number of iterations
          out['error']: Error
          out['Error']: Error of every iteration
    =========================================================================
    Written by Shenglong Zhou on 30/04/2024 based on the algorithm proposed in
          Shenglong Zhou, Lili Pan, Naihua Xiu, and Geoffrey Ye Li,
          0/1 constrained optimization solving sample average approximation
          for chance constrained programming, arXiv:2210.11889, 2024
    Send your comments and suggestions to <<< slzhou2021@163.com >>>
    WARNING: Accuracy may not be guaranteed!!!!!
    =========================================================================
    """
    if pars is None:
        pars = {}

    gamma0, mu0, I0, r0, maxit, tau0, x0, W0, tol, thd, disp, sepFlag, Proj, JacProj, isInSet, stopflag = \
        GetParameters(K, M, N, s, FeaSet, input1, input2, pars)
    if stopflag:
        return
    mk     = len(tau0)
    iteron = (mk == 1)

    out         = {}
    out['obj']  = np.inf
    out['obj1'] = np.inf
    out['time'] = 0

    if disp:
        print(' Strat to run the solver -- SNSCO')
        print(' ------------------------------------------------------------')
        if mk == 1:
            print('    Iter      Time(sec)       Error       Objective     Level')
        else:
            print('    tau       Time(sec)       Error       Objective     Level')
        print(' ------------------------------------------------------------')
    for i in range(mk):
        outi = SNSCOsingle(x0, W0, s, Funcf, FuncG, sepFlag, Proj, JacProj, isInSet, tau0[i], mu0, gamma0, I0, r0,
                           int(np.ceil(maxit / mk)), tol, thd, iteron)
        out['time'] = out['time'] + outi['time']

        if disp and mk > 1:
            print(
                f'  {tau0[i]:.4f}       {out["time"]:<10.4f}   {outi["error"]:.2e}      {outi["obj"]:<10.4f}  {outi["voil"]:>5d}')

        if mk == 1:
            out        = outi
            out['tau'] = tau0[i]
        else:
            if outi['obj'] < out['obj'] and outi['voil'] <= s:
                out['obj']   = outi['obj']
                out['x']     = outi['x']
                out['G']     = outi['G']
                out['voil']  = outi['voil']
                out['error'] = outi['error']
                out['mark']  = outi['mark']
                out['timeb'] = outi['time']
                out['tau']   = tau0[i]

    print(' ------------------------------------------------------------')
    if 'obj' in out and out['obj'] != np.inf:
        print(f" Objective:      {out.get('obj', float('nan')):10.4f}")
        print(f" Voilations:     {out.get('voil', 'N/A'):10d}")
        print(f" Time:           {out.get('time', float('nan')):6.3f} sec")
        print(f" Best tau:       {out.get('tau', float('nan')):10.4f}")
    else:
        print(" No feasible solution found.")
    print(' ------------------------------------------------------------')

    return out


# --------------------------------------------------------------------------
def GetParameters(K, M, N, s, FeaSet, input1, input2, pars):
    tau0    = np.array([1.0])
    mu0     = 0.125
    x0      = np.ones((K, 1))
    W       = 50 * np.ones((M, N))
    tol     = 1e-6 * M * N
    gamma0  = 1 + (2 - 2 * (s <= 2)) / s
    r0      = 0.5
    i0      = 6 + (M > 1)
    disp    = 1
    thd     = 1e-4

    if 'gamma0' in pars: gamma0 = pars['gamma0']
    if 'tau0' in pars:   tau0 = pars['tau0']
    if 'tol' in pars:    tol = pars['tol']
    if 'x0' in pars:     x0 = pars['x0']
    if 'W0' in pars:     W = pars['W0']
    if 'mu0' in pars:    mu0 = pars['mu0']
    if 'i0' in pars:     i0 = pars['i0']
    if 'r0' in pars:     r0 = pars['r0']
    if 'disp' in pars:   disp = pars['disp']
    if 'thd' in pars:    thd = pars['thd']

    mk = len(tau0)
    maxit = 2e3 * (mk == 1) + 250 * mk * (mk > 1)
    if 'maxit' in pars: maxit = pars['maxit']

    sepFlag = 1
    stopflag = 0
    Proj = None
    JacProj = None
    isInSet = None

    if FeaSet == None:
        FeaSet = 'Box'
        input1  = -float('inf')
        input2  = float('inf')

    if FeaSet == 'Box':
        if (np.isscalar(input1) and np.isscalar(input2) and input1 < input2):
            Proj    = None
            JacProj = None
            if input1==-float('inf') and input2!=float('inf'):
                isInSet = lambda var: np.where(var.flatten() <= input2)[0]
            elif input1!=-float('inf') and input2==float('inf'):
                isInSet = lambda var: np.where(var.flatten() >= input1)[0]
            elif (input1==-float('inf') and input2==float('inf'))or(input1==None and input2==None):
                isInSet = lambda var: list(range(1, K + 1))
            else:
                isInSet = lambda var: np.where((var >= input1) & (var <= input2))[0]
        else:
            print('Notice: input1 or input2 has incorrect input format, no problems will be solved')
            stopflag = 1
            Proj     = None
            JacProj  = None
            isInSet  = None
    elif FeaSet == 'Ball':
        if np.isscalar(input1) and (input2 is None or len(input2) == 0) and input1 > 0:
            isInSet = lambda x: np.linalg.norm(x, 2) <= input1
            Proj    = lambda x, isInSet_flag: ProjBall(x, input1, isInSet_flag)
            JacProj = lambda x, X, isInSet_flag: JacProjBall(x, X, input1, isInSet_flag)
            sepFlag = 0
        elif (input1 is None or len(input1) == 0) and (input2 is None or len(input2) == 0):
            print('Notice: empty input1 and input2, using unit ball constraint (default)')
            isInSet = lambda x: np.linalg.norm(x, 2) <= 1
            Proj    = lambda x, isInSet_flag: ProjBall(x, 1, isInSet_flag)
            JacProj = lambda x, X, isInSet_flag: JacProjBall(x, X, 1, isInSet_flag)
            sepFlag = 0
        else:
            print('Notice: input1 or input2 has incorrect input format, no problems will be solved')
            stopflag = 1
            Proj = None
            JacProj = None
            isInSet = None
    elif FeaSet == 'Halfspace':
        if (hasattr(input1, '__len__') and len(input1) == K) and np.isscalar(input2):
            isInSet = lambda x: np.sum(input1 * x) - input2
            aat     = input1 @ input1.T
            Proj    = lambda x, isInSet_val: ProjHs(x, input1, isInSet_val)
            JacProj = lambda x, X, isInSet_val: JacProjHs(X, input1, aat, isInSet_val)
            sepFlag = 0
        else:
            print('Notice: input1 or input2 has incorrect input format, no problems will be solved')
            stopflag = 1
            Proj = None
            JacProj = None
            isInSet = None
    elif FeaSet == 'Hyperplane':
        input1_arr = np.array(input1)
        if (input1_arr.ndim == 2 and input1_arr.shape[1] == K and
                hasattr(input2, '__len__') and len(input2) == input1_arr.shape[0]):
            isInSet = lambda x: input1 @ x - input2
            AAt     = input1 @ input1.T
            shift   = input1.T @ np.linalg.pinv(AAt)
            projmat = shift @ input1
            Proj    = lambda x, isInSet_val: ProjHp(x, shift, isInSet_val)
            JacProj = lambda x, X, isInSet_val: JacProjHp(X, projmat)
            sepFlag = 0
        else:
            print('Notice: input1 or input2 has incorrect input format, no problems will be solved')
            stopflag = 1
            Proj = None
            JacProj = None
            isInSet = None
    return gamma0, mu0, i0, r0, maxit, tau0, x0, W, tol, thd, disp, sepFlag, Proj, JacProj, isInSet, stopflag



def SNSCOsingle(x, W, s, Funcf, FuncG, sepFlag, Proj, JacProj, isInSet, tau, mu, gamma, I0, r0, maxit, tol, thd,
                disp):
    t0 = time.time()

    K     = len(x)
    M, N  = W.shape
    bestf = np.inf
    besti = 0
    bestE = np.inf
    Err   = np.zeros(maxit)
    fail  = np.zeros(maxit)
    obj   = np.zeros(maxit)
    sol   = np.zeros((K, maxit))
    T     = np.arange(K)
    FwV   = np.zeros((K, 1))
    d     = np.zeros((K, 1))
    JJ    = [None] * maxit

    Fnorm = lambda var: np.linalg.norm(var, 'fro')
    TtauI = lambda Lambda: Ttau(Lambda, M, s)
    funG  = lambda v: FuncG(v, None, None)[0]

    Ind   = TtauI(funG(x) + tau * W)
    fvoil = lambda v: np.count_nonzero(np.max(v, axis=0) > thd)

    iter_idx = 0
    for iter_idx in range(maxit):
        iter_num = iter_idx + 1

        f, gf, hf = Funcf(x)
        G, gG, gGW, hGW = FuncG(x, W, Ind)
        gfG = gf + gGW
        z   = x - tau * gfG

        if sepFlag:
            Tp  = isInSet(z)
            nTp = len(Tp)
            if nTp == K or nTp == 0:
                FTp = -gfG
                FwV = tau * FTp
                Tp  = T
                nTp = K
                Tn  = np.array([], dtype=int)
            else:
                Tn      = np.setdiff1d(T, Tp, assume_unique=True)
                FTp     = -gfG[Tp]
                FTn     = -x[Tn]
                FwV[Tp] = tau * FTp
                FwV[Tn] = FTn
        else:
            setflag = isInSet(z)
            FwV     = Proj(z, setflag) - x

        if Ind.size > 0:
            rows, cols = np.unravel_index(Ind, W.shape, order='F')
            GV         = -G[rows, cols].reshape(-1, 1)
        else:
            GV = np.empty((0, 1))

        Error            = Fnorm(np.vstack([FwV, GV])) if GV.size > 0 else Fnorm(FwV)
        voils            = fvoil(G)
        Err[iter_idx]    = Error
        fail[iter_idx]   = voils
        sol[:, iter_idx] = x.flatten()
        obj[iter_idx]    = f

        if voils <= s and f - 1e-4 < bestf:
            bestf = f
            bestx = x.copy()
            bestG = G.copy()
            bestW = W.copy()
            besti = iter_num
            bestv = voils
            bestE = Error

        if (iter_num % 10 == 0 or iter_num < 10) and disp:
            print(f'  {iter_num:4d}         {time.time() - t0:<10.4f}    {Error:.2e}      {f:<10.4f}  {voils:>5d}')

        stop  = Error < tol and voils <= s
        stop0 = iter_num > 9 and np.std(obj[iter_idx - 9:iter_idx + 1]) < 1e-6 and voils <= s

        if (stop or stop0):
            if not (iter_num % 10 == 0 or iter_num < 10) and disp:
                print(f'  {iter_num:4d}         {time.time() - t0:<10.4f}    {Error:.2e}      {f:<10.4f}  {voils:>5d}')
            break

        nGV     = gG.shape[1] if gG is not None and gG.ndim == 2 else 0
        dir_val = None
        tnan    = False

        if sepFlag:
            if Ind.size == 0:
                if nTp == K:
                    try:
                        dir_val = linsolve(hf, FTp)
                    except LinAlgError:
                        dir_val = FTp
                else:
                    dir_val = np.zeros((K, 1))
                    if nTp > 0:
                        hf_Tp = hf[np.ix_(Tp, Tp)]
                        try:
                            dir_val[Tp] = linsolve(hf_Tp, FTp)
                        except LinAlgError:
                            dir_val[Tp] = FTp
                    if Tn.size > 0:
                        dir_val[Tn] = FTn
            else:
                gG_Tp  = gG[Tp, :]
                hGW_Tp = hGW[np.ix_(Tp, Tp)] if hGW is not None and hGW.ndim == 2 else hGW
                hf_Tp  = hf[np.ix_(Tp, Tp)]

                if nTp != K:
                    GV = GV - (gG[Tn, :].T @ FTn)

                dTp, dV = None, None
                if nTp <= 500 and nGV < 1e5:
                    temp = hGW_Tp + hf_Tp
                    gGt  = gG_Tp.T

                    try:
                        if nGV > 0 and nGV <= nTp * 0.25:
                            solved_block = linsolve(temp, np.hstack((FTp, gG_Tp)))
                            solved_FTp   = solved_block[:, 0:1]
                            solved_gG    = solved_block[:, 1:]

                            rhs = gGt @ solved_FTp - GV
                            D   = gGt @ solved_gG

                            dV = linsolve(D, rhs)
                            if np.linalg.norm(dV) > 1e3 * nGV + 1e5 * (voils == N):
                                dV = linsolve(D + (1e-2 / iter_num) * np.eye(nGV), rhs)
                            dTp = solved_FTp - solved_gG @ dV
                        else:
                            if nGV > 0:
                                D   = gG_Tp @ gGt + mu * temp
                                rhs = mu * FTp + gG_Tp @ GV
                                dTp = linsolve(D, rhs)
                                dV  = (gGt @ dTp - GV) / mu
                            else:
                                dTp = linsolve(temp, FTp)
                                dV  = np.empty((0, 1))
                    except (LinAlgError, ValueError):
                        tnan = True

                if (nTp > 500 or nGV >= 1e5) or tnan:
                    tnan = False
                    try:
                        gGt = gG_Tp.T
                        D   = gG_Tp @ gGt + mu * temp
                        rhs = mu * FTp + gG_Tp @ GV
                        dTp = linsolve(D, rhs)
                        dV  = (gGt @ dTp - GV) / mu
                    except (LinAlgError, ValueError):
                        dir_val = np.vstack([FwV, GV])

                if dir_val is None:
                    if nTp == K:
                        dir_val = np.vstack([dTp, dV])
                    else:
                        d = np.zeros((K, 1))
                        if nTp > 0: d[Tp] = dTp
                        if Tn.size > 0: d[Tn] = FTn
                        dir_val = np.vstack([d, dV])
        else:
            if Ind.size == 0:
                try:
                    U       = np.eye(K) - tau * hf
                    JacP    = np.eye(K) - JacProj(z, U, setflag)
                    dir_val = linsolve(JacP, FwV)
                except LinAlgError:
                    tnan = True
            else:
                JacQ = JacProj(z, gG, setflag)

                if K <= 500 and nGV < 1e5:
                    U      = np.eye(K) - tau * (hf + hGW)
                    JacP   = np.eye(K) - JacProj(z, U, setflag)
                    gGt    = gG.T
                    dx, dV = None, None

                    try:
                        if nGV > 0 and nGV <= 0.25 * K:
                            rhs_block     = np.hstack((FwV, JacQ))
                            solved_block  = linsolve(JacP, rhs_block)
                            JacP_inv_FwV  = solved_block[:, 0:1]
                            JacP_inv_JacQ = solved_block[:, 1:]

                            rhs_dV = gGt @ JacP_inv_FwV - GV
                            D      = gGt @ JacP_inv_JacQ
                            dV     = linsolve(D, rhs_dV)

                            if np.linalg.norm(dV) > 1e3 * nGV + 1e5 * (voils == N):
                                dV = linsolve(D + (1e-2 / iter_num) * np.eye(nGV), rhs_dV)

                            dx = JacP_inv_FwV - JacP_inv_JacQ @ dV
                        elif nGV > 0:
                            D   = JacQ @ gGt + mu * JacP
                            rhs = mu * FwV + JacQ @ GV
                            dx  = linsolve(D, rhs)
                            dV  = (gGt @ dx - GV) / mu
                        else:
                            dx = linsolve(JacP, FwV)
                            dV = np.empty((0, 1))
                    except LinAlgError:
                        tnan = True

                    if tnan:
                        try:
                            tnan = False
                            D   = JacQ @ gGt + mu * JacP + (1e-2 / iter_num) * np.eye(K)
                            rhs = mu * FwV + JacQ @ GV
                            dx  = linsolve(D, rhs)
                            dV  = (gGt @ dx - GV) / mu
                        except LinAlgError:
                            tnan = True

                else:
                    rsh = mu * FwV + JacQ @ GV

                    def fx(v):
                        term1 = (hf + hGW) @ (mu * v)
                        term2 = (1e-2 / iter_num) * v
                        term3 = JacQ @ (gG.T @ v)
                        return term1 + term2 + term3

                    dx = my_cg(fx, rsh, 1e-6, 10, np.zeros((K, 1)))
                    dV = (gG.T @ dx - GV) / mu

                if not tnan:
                    dir_val = np.vstack((dx, dV))

        if dir_val is None or np.any(np.isnan(dir_val)) or Fnorm(dir_val) > 1e8:
            dir_val = np.vstack([FwV, GV]) if GV.size > 0 else FwV
            if np.linalg.norm(dir_val) > 1e-12:
                dir_val = dir_val / np.max(np.abs(dir_val))

        step = 1.0
        xold = x.copy()
        NG   = N * np.ones(I0 + 1)
        ii   = int(max(5, I0 - 2) + 2 * (s / N < 0.1))

        i_linesearch = 0
        for i_linesearch in range(I0):
            x    = xold + step * dir_val[0:K]
            G_ls = funG(x)
            NG[i_linesearch + 1] = fvoil(G_ls)
            if abs(NG[i_linesearch + 1] - s) <= (gamma - 1) * s or \
                    (NG[i_linesearch + 1] != N and i_linesearch + 1 > ii and np.count_nonzero(
                        NG[i_linesearch + 1 - ii:i_linesearch + 1] - NG[i_linesearch + 1]) == 0):
                break
            step = step * r0

        if i_linesearch == I0 - 1:
            positive_NG = NG[NG > 0]
            if positive_NG.size > 0:
                mNG = np.min(np.abs(positive_NG - s))
                t   = np.where(np.abs(s - NG) == mNG)[0]
                if t.size > 0:
                    if mNG == N - s and tnan:
                        step = r0 ** (t[-1])
                    else:
                        step = r0 ** (max(0, t[0] - 1))
            x = xold + step * dir_val[0:K]

        G    = funG(x)
        Wold = W.copy()
        W    = np.zeros((M, N))
        dirW = dir_val[K:]

        if M == 1 and dirW.ndim > 1:
            dirW = dirW.T

        if Ind.size > 0:
            rows, cols = np.unravel_index(Ind, Wold.shape, order='F')
            if step == 1.0:
                W[rows, cols] = Wold[rows, cols] + dirW.flatten()
            else:
                W[rows, cols] = Wold[rows, cols] + step * dirW.flatten()

        Ind = TtauI(G + tau * W)

        if iter_num % 10 == 0:
            gamma = max(1, gamma - 1 / s)
            mu    = max(1e-6, min(0.9995 * mu, 1e2 * N * Error))

        JJ[iter_idx] = Ind
        rep          = 0
        if iter_num > 20:
            rep = np.count_nonzero(np.abs(fail[iter_idx - 10:iter_idx + 1] - voils) < 1)

        if (iter_num > 99 + 100 * (M == 1)) or (rep > 10):
            if rep > 0 or Ind.size == 0 or iter_num > 1e3:
                Jc = Ind.copy()
                for j in range(iter_idx - 2, iter_idx):
                    if j >= 0 and JJ[j] is not None:
                        Jc = np.union1d(Jc, JJ[j])
                Ind = np.unique(Jc).astype(int)
                JJ[iter_idx] = Ind

    if bestf == np.inf or (abs(bestf - f) < 1e-4 and voils <= s and bestE > Error):
        bestf = f
        bestx = x
        bestG = G
        bestW = W
        besti = iter_idx + 1
        bestv = voils

    out = {}
    out['time']  = time.time() - t0
    out['mark']  = (bestf == f)
    out['x']     = bestx
    out['W']     = bestW
    out['obj']   = bestf
    out['G']     = bestG
    out['bit']   = besti
    out['voil']  = bestv
    out['iter']  = iter_idx + 1
    out['error'] = Error
    out['Error'] = Err[:iter_idx + 1]
    out['Obj']   = obj[:iter_idx + 1]
    return out

# calculate J -------------------------------------------------------------
def Ttau(Lambda, M, s):
    t      = 1e-8
    z      = np.max(Lambda, axis=0)
    T_zero = np.where(np.abs(z) <= t)[0]

    Tp = np.where(z > t)[0]
    if len(Tp) > s:
        zTp = np.sum(np.maximum(Lambda[:, Tp], 0) ** 2, axis=0)

        if s > 0:
            Js_indices_in_zTp = np.argpartition(zTp, -s)[-s:]
        else:
            Js_indices_in_zTp = np.array([], dtype=int)

        Js = Tp[Js_indices_in_zTp]

        is_in_Js  = np.isin(Tp, Js)
        Tp_to_add = Tp[~is_in_Js]

        T = np.sort(np.union1d(T_zero, Tp_to_add))
    else:
        T = T_zero

    J = np.array([], dtype=int)
    if T.size > 0:
        rows, idy     = np.where(Lambda[:, T] >= -t)
        original_cols = T[idy]
        J             = original_cols * M + rows

    return np.sort(J)


# Projection functions ----------------------------------------------------
def ProjBall(x, r, isInSet_val):
    y = x.copy()
    if not isInSet_val:
        nrm = np.linalg.norm(y)
        if nrm > 1e-12:
            y = (r / nrm) * y
    return y


def JacProjBall(x, X, r, isInSet_val):
    Jx = X.copy()
    if not isInSet_val:
        nrm = np.linalg.norm(x)
        if nrm > 1e-12:
            Jx = (r / nrm) * Jx - (r / (nrm ** 3)) * (x @ (x.T @ Jx))
    return Jx


def ProjHp(x, shift, isInSet_val):
    y = x.copy()
    if np.linalg.norm(isInSet_val) > 1e-5:
        y = y - shift @ isInSet_val
    return y


def JacProjHp(X, projmat):
    Jx = X - projmat @ X
    return Jx


def ProjHs(x, a, isInSet_val):
    y = x.copy()
    if isInSet_val > 0:
        nrm_sq = np.dot(a.T, a).item()
        if nrm_sq > 1e-12:
            y = y - (isInSet_val / nrm_sq) * a
    return y


def JacProjHs(X, a, aat, isInSet_val):
    Jx = X.copy()
    if isInSet_val > 0:
        nrm_sq = np.trace(aat)
        if nrm_sq > 1e-12:
            Jx = X - (a @ (a.T @ X)) / nrm_sq
    return Jx


# conjugate gradient-------------------------------------------------------
def my_cg(fx, b, cgtol, cgit, x):
    if not callable(fx):
        mat = fx
        fx = lambda v: mat @ v

    if np.count_nonzero(x) > 0:
        r = b - fx(x)
    else:
        r = b.copy()

    e = np.linalg.norm(r) ** 2
    t = e
    p = r.copy()

    for i in range(cgit):
        if e < cgtol * t:
            break
        w = fx(p)
        pw = p * w
        a = e / np.sum(pw)
        x = x + a * p
        r = r - a * w
        e0 = e
        e = np.linalg.norm(r) ** 2
        if e0 < 1e-20:
            break
        p = r + (e / e0) * p

    return x