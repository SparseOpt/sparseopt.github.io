% Before you run the code, please run this code to add the path
 clc; close all; clear all; warning off
 addpath(genpath(pwd));
 
 set(0,'defaultaxesfontsize',10);
 set(0,'defaulttextfontsize',10);
