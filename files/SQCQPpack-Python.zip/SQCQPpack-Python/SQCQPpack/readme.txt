Please run "demonXXXX.py" to solve different problems

This package offers 1 solver for sparse quadratically constrained quadratic programming  
based on the algorithm proposed in the following paper: 

SNSQP----------------------------------------------------------------------
    Shuai Li, Shenglong Zhou, Ziyan Luo, 
    Sparse Quadratically Constrained Quadratic Programming via Semismooth Newton Method, 
    https://arxiv.org/abs/2503.15109, 2025.


Please credit it if you use the code for your research.

===========================================================================
def SNSQP(n: int, s: int, Q0: np.ndarray, q0: np.ndarray,
          Qi: Optional[List[np.ndarray]], qi: Optional[np.ndarray], ci: Optional[np.ndarray],
          ineqA: Optional[np.ndarray], ineqb: Optional[np.ndarray],
          eqA: Optional[np.ndarray], eqb: Optional[np.ndarray],
          lb: any, ub: any, pars: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
# This code aims at solving the sparse SQCQP in the form of
# 
#         min   (1/2)(x' Q0 x) + q0' x
#         s.t.  (1/2)x' Qi[i] x + qi[:,i]' x + ci[i] <= 0,   i = 1,...,k,
#               ineqA @ x - ineqb <= 0,
#               eqA   @ x - eqb   = 0,
#               lb <= x <= ub,
#               ||x||_0 <= s,
# 
# where Qi = [Qi[0], ..., Qi[k-1]],   each Qi[i] ∈ R^{n×n},
#       qi ∈ R^{n×k},  ci ∈ R^k,
#       ineqA ∈ R^{m1×n}, ineqb ∈ R^{m1},
#       eqA   ∈ R^{m2×n}, eqb   ∈ R^{m2},
#       s << n.
# 
# ---------------------------------------------------------------------------------------------------
# Inputs:
#     n:      Dimension of the solution x                                               (required)
#     s:      Sparsity level of x, integer between 1 and n-1                            (required)
#     Q0:     Quadratic objective matrix, shape (n, n)                                  (required)
#     q0:     Quadratic objective vector, shape (n,)                                    (required)
#     Qi:     Quadratic constraint matrices, list of arrays or None, each (n, n)        (optional)
#     qi:     Quadratic constraint vectors, ndarray shape (n, k) or None                (optional)
#     ci:     Quadratic constraint constants, ndarray shape (k,) or None                (optional)
#     ineqA:  Linear inequality constraint matrix, shape (m1, n) or None                (optional)
#     ineqb:  Linear inequality constraint vector, shape (m1,) or None                  (optional)
#     eqA:    Linear equality constraint matrix, shape (m2, n) or None                  (optional)
#     eqb:    Linear equality constraint vector, shape (m2,) or None                    (optional)
#     lb:     Lower bounds of x, ndarray shape (n,) or None                             (optional)
#     ub:     Upper bounds of x, ndarray shape (n,) or None                             (optional)
#             NOTE: 0 must be in [lb, ub]
#     pars:   Dictionary of parameters, all OPTIONAL
#             pars["x0"]       -- Starting point of x                      (default: np.zeros(n))
#             pars["dualquad"] -- Starting point of mu for quadratic cons. (default: np.zeros(k))
#             pars["dualineq"] -- Starting point of λ1 for ineq constraints (default: np.zeros(m1))
#             pars["dualeq"]   -- Starting point of λ2 for eq constraints   (default: np.zeros(m2))
#             pars["dualbd"]   -- Starting point of ν for bounds            (default: np.zeros(n))
#             pars["tau"]      -- Positive scalar                           (default: 1.0)
#                                NOTE: tuning tau may improve solutions
#             pars["itlser"]   -- Maximum number of line search steps       (default: 5)
#             pars["itmax"]    -- Maximum number of iterations              (default: 10000)
#             pars["show"]     -- Verbosity: 1 = show per-iteration results,
#                                0 = silent                                 (default: 1)
#             pars["tol"]      -- Stopping tolerance                        (default: 1e-6)
# 
# Outputs:
#     Out["sol"]:      The sparse solution x
#     Out["sparsity"]: Sparsity level of Out["sol"]
#     Out["error"]:    Error used to terminate solver
#     Out["time"]:     CPU time
#     Out["iter"]:     Number of iterations
#     Out["obj"]:      Objective value at Out["sol"]
# 
# ---------------------------------------------------------------------------------------------------
# This code is based on the algorithm proposed in:
# "Shuai Li, Shenglong Zhou, and Ziyan Luo, Sparse quadratically constrained
#  quadratic programming via semismooth Newton method, arXiv:2503.15109, 2025."
# 
# Send comments/suggestions to: 24110488@bjtu.edu.cn / slzhou2021@163.com
# Warning: Accuracy may not be guaranteed!
# ---------------------------------------------------------------------------------------------------

# Below is one example that you can run
# =========================================================================
# demon sparse portfolio selection (SPS) problems
import numpy as np
from SNSQPpack import SNSQP, DataSPS

n                = 1000
s                = 10

dt               = DataSPS(n)
pars             = {'x0': ((dt['lb'] + dt['ub']) / 2) * np.ones((n, 1))}
pars['tau']      = 1 # decrease this value if the algorithm do not converge
pars['dualquad'] = 0 * np.ones((len(dt['ci']), 1))
pars['dualineq'] = 0.001 * np.ones((len(dt['ineqb']), 1))
pars['dualeq']   = 0.001 * np.ones((len(dt['eqb']), 1))
Out              = SNSQP(n, s, dt['Q0'], dt['q0'], dt['Qi'], dt['qi'], dt['ci'],
                   dt['ineqA'], dt['ineqb'], dt['eqA'], dt['eqb'],
                   dt['lb'], dt['ub'], pars)

print("\n ---- Solver Finished ----")
print(f" Final Objective: {Out['obj']:.6f}")
print(f" Iterations: {Out['iter']}")
print(f" Sparsity of solution: {Out['sparsity']}")
print(f" CPU Time: {Out['time']:.4f} seconds")
print(" ------------------------\n")