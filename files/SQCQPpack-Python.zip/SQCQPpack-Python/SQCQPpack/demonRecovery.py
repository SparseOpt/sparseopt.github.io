# demon recovery problems
import numpy as np
from SNSQPpack import SNSQP, PlotRecovery, DataRecovery

n         = 1000
k         = int(np.ceil(0.001 * n)) # number of quadratic const
m         = int(np.ceil(0.001 * n)) # number of linear const
s         = int(np.ceil(0.01 * n))  # sparsity level

test      = 1 # X = R^n        if test =1
              # X = [-2,2]^n   if test =2
              # X = [0,inf)^n  if test =3

if test == 1:
    lb   = -np.inf
    ub   = np.inf
    xT   = np.random.randn(s, 1)
elif test == 2:
    lb   = -2
    ub   = 2
    xT   = np.random.uniform(lb, ub, (s, 1))
elif test == 3:
    lb   = 0
    ub   = np.inf
    xT   = 1 * np.random.rand(s, 1)

T                = np.random.choice(np.arange(1, n + 1), size=s, replace=False)
xopt             = np.zeros((n, 1))
xopt[T - 1]      = xT
dt               = DataRecovery(n, k, m, xopt, T)

pars             = {'x0':np.zeros((n, 1))}
pars['tau']      = 3 # decrease this value if the algorithm do not converge
pars['dualquad'] = 0.001 * np.ones((k, 1))
pars['dualineq'] = 0.001 * np.ones((m, 1))
pars['itlser']   = 10 # increase this value if the algorithm varies a lot
out              = SNSQP(n, s, dt['Q0'], dt['q0'], dt['Qi'], dt['qi'], dt['ci'],
                   dt['A'], dt['b'], None, None, lb, ub, pars)

print(f"\n Relerr:   {np.linalg.norm(out['sol'] - xopt) / np.linalg.norm(xopt):.4e} \n")
PlotRecovery(xopt, out['sol'], [1800, 50, 500, 250], True)