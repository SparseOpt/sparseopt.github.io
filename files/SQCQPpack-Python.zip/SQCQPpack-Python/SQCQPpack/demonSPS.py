# demon SPS problems
import numpy as np
from SNSQPpack import SNSQP, DataSPS

n                = 1000
s                = 10

dt               = DataSPS(n)
pars             = {'x0': ((dt['lb'] + dt['ub']) / 2) * np.ones((n, 1))}
pars['tau']      = 1 # decrease this value if the algorithm do not converge
pars['dualquad'] = 0 * np.ones((len(dt['ci']), 1))
pars['dualineq'] = 0.001 * np.ones((len(dt['ineqb']), 1))
pars['dualeq']   = 0.001 * np.ones((len(dt['eqb']), 1))
Out              = SNSQP(n, s, dt['Q0'], dt['q0'], dt['Qi'], dt['qi'], dt['ci'],
                   dt['ineqA'], dt['ineqb'], dt['eqA'], dt['eqb'],
                   dt['lb'], dt['ub'], pars)

print("\n ---- Solver Finished ----")
print(f" Final Objective: {Out['obj']:.6f}")
print(f" Iterations: {Out['iter']}")
print(f" Sparsity of solution: {Out['sparsity']}")
print(f" CPU Time: {Out['time']:.4f} seconds")
print(" ------------------------\n")