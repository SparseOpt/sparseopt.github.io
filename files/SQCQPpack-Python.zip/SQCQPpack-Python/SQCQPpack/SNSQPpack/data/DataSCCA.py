import numpy as np
from typing import Dict, Any
from scipy import linalg
from scipy import stats as sp_stats
import warnings


def DataSCCA(nx: int, ny: int, N: int) -> Dict[str, Any]:
    r"""
    Generates data for a Sparse Canonical Correlation Analysis problem.
    """
    warnings.filterwarnings("ignore")
    print(' Data is generating ...')

    v1 = np.zeros((nx, 1))
    v1[0:int(nx / 8)] = 1
    v1[int(nx / 8):int(nx / 4)] = -1

    v2 = np.zeros((ny, 1))
    v2[int(ny - nx / 4):int(ny - nx / 8)] = 1
    v2[int(ny - nx / 8):] = -1

    u = np.random.randn(N, 1)

    X = (v1 + np.random.normal(0, 0.1, (nx, 1))) @ u.T
    Y = (v2 + np.random.normal(0, 0.1, (ny, 1))) @ u.T


    A, B, r, U, V, stats = canoncorr(X.T, Y.T)

    x0     = np.vstack((A, B))
    cov_xy = X @ Y.T
    cov_x  = X @ X.T
    cov_y  = Y @ Y.T

    Qi = [None]

    Qi[0] = np.block([
        [cov_x, np.zeros((nx, ny))],
        [np.zeros((ny, nx)), cov_y]
    ])

    data = {}
    data['Q0'] = np.block([
        [np.zeros((nx, nx)), -cov_xy],
        [-cov_xy.T, np.zeros((ny, ny))]
    ])
    data['q0'] = np.zeros((nx + ny, 1))
    data['Qi'] = Qi
    data['qi'] = np.zeros((nx + ny, 1))
    data['ci'] = np.array([[-1.0]])
    data['x0'] = x0
    data['cxy'] = cov_xy
    data['cx'] = cov_x
    data['cy'] = cov_y
    data['X'] = X
    data['Y'] = Y

    print(' Done data generation !!!')

    return data

def canoncorr(X, Y):
    """
    Parameters
    ----------
    X : (n, p1) array_like
        The first data matrix, where 'n' is the number of observations
        and 'p1' is the number of variables.
    Y : (n, p2) array_like
        The second data matrix, where 'n' is the number of observations
        and 'p2' is the number of variables.

    Returns
    -------
    A : (p1, d) ndarray
        The canonical coefficients for the variables in X.
    B : (p2, d) ndarray
        The canonical coefficients for the variables in Y.
    r : (d,) ndarray
        The canonical correlations.
    U : (n, d) ndarray
        The canonical variables (scores) for X.
    V : (n, d) ndarray
        The canonical variables (scores) for Y.
    stats : dict
        A dictionary containing statistics for hypothesis testing.
        - Wilks: Wilks' lambda statistic.
        - chisq: Bartlett's approximate chi-squared statistic.
        - pChisq: The p-value for the chi-squared test.
        - F: Rao's approximate F statistic.
        - pF: The p-value for the F-test.
        - df1: Degrees of freedom 1 for the chi-squared and F statistics.
        - df2: Degrees of freedom 2 for the F statistic.
    """

    # --- Input Validation ---
    X = np.asarray(X, dtype=float)
    Y = np.asarray(Y, dtype=float)

    n, p1 = X.shape
    if Y.shape[0] != n:
        raise ValueError('X and Y must have the same number of rows (observations).')
    elif n == 1:
        raise ValueError('Not enough data; at least two observations are required.')
    p2 = Y.shape[1]

    # --- Center the variables ---
    X_mean = np.mean(X, axis=0)
    Y_mean = np.mean(Y, axis=0)
    X = X - X_mean
    Y = Y - Y_mean

    # --- QR decomposition to factor the inputs and find a full rank set of columns if necessary ---
    # Use economy-size QR with column pivoting
    Q1, T11, perm1 = linalg.qr(X, pivoting=True, mode='economic')
    rankX = np.sum(np.abs(np.diag(T11)) > np.spacing(np.abs(T11[0, 0])) * max(n, p1))
    if rankX == 0:
        raise ValueError('Input matrix X is rank deficient.')
    elif rankX < p1:
        warnings.warn('Matrix X is not full rank. Dependent columns will be ignored.')
        Q1 = Q1[:, 0:rankX]
        T11 = T11[0:rankX, 0:rankX]

    Q2, T22, perm2 = linalg.qr(Y, pivoting=True, mode='economic')
    rankY = np.sum(np.abs(np.diag(T22)) > np.spacing(np.abs(T22[0, 0])) * max(n, p2))
    if rankY == 0:
        raise ValueError('Input matrix Y is rank deficient.')
    elif rankY < p2:
        warnings.warn('Matrix Y is not full rank. Dependent columns will be ignored.')
        Q2 = Q2[:, 0:rankY]
        T22 = T22[0:rankY, 0:rankY]

    # --- Compute canonical coefficients and correlations ---
    d = min(rankX, rankY)

    # Use economy-size SVD
    L, D, M_h = linalg.svd(Q1.T @ Q2, full_matrices=False)
    M = M_h.T

    # A and B are scaled to give U and V unit variance
    # Using solve_triangular as T11 and T22 are triangular matrices from QR
    A = linalg.solve_triangular(T11, L[:, 0:d], check_finite=False) * np.sqrt(n - 1)
    B = linalg.solve_triangular(T22, M[:, 0:d], check_finite=False) * np.sqrt(n - 1)

    # Remove roundoff errors to keep correlations between 0 and 1
    r = np.clip(D[0:d], 0, 1)

    # --- Restore coefficients to their full size and original order ---
    A_full = np.zeros((p1, d))
    A_padded = np.vstack((A, np.zeros((p1 - rankX, d))))
    A_full[perm1, :] = A_padded
    A = A_full

    B_full = np.zeros((p2, d))
    B_padded = np.vstack((B, np.zeros((p2 - rankY, d))))
    B_full[perm2, :] = B_padded
    B = B_full

    # --- Compute the canonical variates (scores) ---
    U = X @ A
    V = Y @ B

    # --- Compute test statistics ---
    stats = {}
    k = np.arange(d)
    d1k = rankX - k
    d2k = rankY - k

    # Wilks' lambda statistic
    nondegen = np.where(r < 1)[0]
    logLambda = -np.inf * np.ones(d)
    logLambda[nondegen] = np.cumsum(np.log(1 - r[nondegen] ** 2)[::-1])[::-1]
    stats['Wilks'] = np.exp(logLambda)

    # The exponent for Rao's approximation to an F distribution
    s = np.ones(d)
    okCases = np.where(d1k * d2k > 2)[0]
    snumer = d1k[okCases] ** 2 * d2k[okCases] ** 2 - 4
    sdenom = d1k[okCases] ** 2 + d2k[okCases] ** 2 - 5
    s[okCases] = np.sqrt(snumer / sdenom)

    # Degrees of freedom
    stats['df1'] = d1k * d2k
    stats['df2'] = (n - 0.5 * (rankX + rankY + 3)) * s - 0.5 * d1k * d2k + 1

    # Rao's F statistic
    powLambda = stats['Wilks'] ** (1. / s)
    ratio = np.inf * np.ones(d)
    ratio[nondegen] = (1 - powLambda[nondegen]) / powLambda[nondegen]
    stats['F'] = ratio * stats['df2'] / stats['df1']
    stats['pF'] = sp_stats.f.sf(stats['F'], stats['df1'], stats['df2'])

    # Bartlett's chi-squared statistic (with Lawley's modification)
    tmp = np.hstack((0, 1. / r[0:d - 1] ** 2))
    stats['chisq'] = -(n - k - 0.5 * (rankX + rankY + 3) + np.cumsum(tmp)) * logLambda
    stats['pChisq'] = sp_stats.chi2.sf(stats['chisq'], stats['df1'])

    # Legacy fields for backward compatibility (deprecated)
    stats['dfe'] = stats['df1']
    stats['p'] = stats['pChisq']

    return A, B, r, U, V, stats