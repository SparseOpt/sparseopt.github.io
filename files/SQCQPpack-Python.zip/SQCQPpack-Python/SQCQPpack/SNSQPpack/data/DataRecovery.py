import numpy as np
from scipy.sparse.linalg import eigs
from typing import List, Dict, Any


def DataRecovery(n: int, k: int, m: int, x: np.ndarray, T: np.ndarray) -> Dict[str, Any]:
    r"""
    # =========================================================================%
    # INPUTS:                                                                 %
    #       n  -- size of Q0                                                  %
    #       k  -- num of quadratic constraint inequalitys                     %
    #       m  -- num of linear constraint inequalitys                        %
    #       x  -- the ground truth                                            %
    #       T  -- the support set of xopt                                     %
    # OUTPUTS:                                                                %
    #       Q0 -- the quadratic objective matrix in R^{n-by-n}                %
    #       q0 -- The quadratic objective vector in R^n                       %
    #       Qi -- the quadratic constraint matrix in R^{n-by-n}               %
    #       qi -- The quadratic constraint vector in R^n                      %
    #       ci -- The quadratic constraint constant in R                      %
    #       A  -- The linear constraint matrix in R^{m-by-n}                  %
    #       b  -- The linear constraint vector in R^m                         %
    # -------------------------------------------------------------------------%
    """
    print(' Data is generating ...')

    l  = int(np.ceil(n / 4))
    Qi = [None] * k
    qi = np.random.randn(n, k)
    ci = np.zeros((k, 1))


    # B        = np.random.randn(n + 5, n)
    B        = np.random.randn(l, n)
    T_0based = T - 1
    d        = B[:, T_0based] @ x[T_0based]
    Q0       = B.T @ B
    q0       = -(d.T @ B).T

    for i_1based in range(1, k + 1):
        i = i_1based
        if i <= np.ceil(k / 2):
            Qii       = np.random.randn(l, n)
            Qii       = Qii.T @ Qii + 0.01 * np.eye(n)
            Qi[i - 1] = Qii
            term1     = x[T_0based].T @ Qii[np.ix_(T_0based, T_0based)] @ x[T_0based] / 2
            term2     = qi[T_0based, i - 1].T @ x[T_0based]
            ci[i - 1] = -(term1 + term2) - np.random.rand()
        else:
            Qii       = np.random.randn(l, n)
            Qii       = Qii.T @ Qii + 0.01 * np.eye(n)
            Qi[i - 1] = Qii
            term1     = x[T_0based].T @ Qii[np.ix_(T_0based, T_0based)] @ x[T_0based] / 2
            term2     = qi[T_0based, i - 1].T @ x[T_0based]
            ci[i - 1] = -(term1 + term2)

    A               = np.random.randn(m, n)
    bn              = np.random.rand(m, 1)
    idx_to_zero     = int(np.ceil(m / 2)) - 1
    bn[idx_to_zero] = 0
    b               = A @ x + bn
    eigenvalues, _  = eigs(Q0, k=1, which='LM')
    lambda_val      = np.real(eigenvalues[0])

    data = {}
    data['Q0'] = Q0 / lambda_val
    data['q0'] = q0 / lambda_val
    data['Qi'] = Qi
    data['qi'] = qi
    data['ci'] = ci
    data['A']  = A
    data['b']  = b
    data['c0'] = (np.linalg.norm(d)) ** 2 / (2 * lambda_val)

    print(' Done data generation !!!')
    return data