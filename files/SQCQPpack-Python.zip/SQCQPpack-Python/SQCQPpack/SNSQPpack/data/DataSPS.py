import numpy as np
from typing import Dict, Any


def DataSPS(n: int) -> Dict[str, Any]:
    """
    Generates data for a Sparse Portfolio Selection (SPS) problem.
    """

    print(' Data is generating ...')

    B   = 0.01 * np.random.rand(int(np.ceil(n / 4)), n)
    D   = np.diag(0.01 * np.random.rand(n))
    cov = B.T @ B + D
    r   = 0.5 * np.random.randn(1, n)

    Qi    = [None]
    Qi[0] = 2 * D

    data          = {}
    data['Q0']    = 2 * cov
    data['q0']    = np.zeros((n, 1))
    data['Qi']    = Qi
    data['qi']    = np.zeros((n, 1))
    data['ci']    = np.array([[-0.001]])
    data['ineqA'] = -r
    data['ineqb'] = np.array([[-0.002]])
    data['eqA']   = np.ones((1, n))
    data['eqb']   = np.array([[1.0]])
    data['lb']    = 0.0
    data['ub']    = 0.3

    print(' Done data generation !!!')

    return data