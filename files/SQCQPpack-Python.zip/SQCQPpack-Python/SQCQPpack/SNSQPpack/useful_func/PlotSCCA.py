import numpy as np
import matplotlib.pyplot as plt

def PlotSCCA(v: np.ndarray, nn: int):
    r"""
    Plots specific segments of a vector with custom styling.
    """

    n = len(v)

    indices1         = np.arange(0, 50 * nn)
    indices2         = np.arange(n - 150 * nn, n)
    selected_indices = np.concatenate((indices1, indices2))
    v                = v[selected_indices]

    plt.figure(figsize=(8, 4), dpi=100)
    ax = plt.axes([0.07, 0.09, 0.89, 0.88])


    ax.plot(np.arange(1, len(v) + 1), np.zeros(len(v)),
            linestyle='-', linewidth=1, color='#f26419')

    nonzero_indices = np.where(v.ravel() != 0)[0]
    nonzero_values  = v[nonzero_indices]

    markerline, stemlines, baseline = ax.stem(
        nonzero_indices + 1, nonzero_values,
        linefmt='-', markerfmt='o', basefmt=' '
    )
    plt.setp(markerline, color='#1c8ddb', markerfacecolor='#1c8ddb', markersize=6)
    plt.setp(stemlines, color='#1c8ddb', linewidth=1)


    ax.grid(True)
    ymin = np.min(nonzero_values)
    ymax = np.max(nonzero_values)
    y    = max(abs(ymin), abs(ymax))
    ax.axis([1, len(v), -1.05 * y, 1.05 * y])

    if nn == 1:
        ax.set_xticks([1, 50, 150, 200])
        ax.set_xticklabels(['1', '50', '450', '500'])
    else:
        ax.set_xticks([1, 250, 750, 1000])
        ax.set_xticklabels(['1', '250', '2250', '2500'])

    plt.show()