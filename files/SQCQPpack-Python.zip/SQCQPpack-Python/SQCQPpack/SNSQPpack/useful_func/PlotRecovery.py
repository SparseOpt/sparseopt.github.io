import numpy as np
import matplotlib.pyplot as plt
from typing import List

def PlotRecovery(xo: np.ndarray, x: np.ndarray, pos: List[int], ind: bool):
    """
    Args:
        xo: The ground-truth data vector.
        x: The recovered data vector.
        pos: A list [left, bottom, width, height] for the figure, in pixels.
        ind: A boolean flag to control whether to show title and legend.
    """

    plt.figure(figsize=(pos[2] / 100, pos[3] / 100), dpi=100)
    ax         = plt.axes([0.05, 0.1, 0.9, 0.8])
    indices_xo = np.where(xo.ravel() != 0)[0]
    values_xo  = xo[indices_xo]

    markerline, stemlines, baseline = ax.stem(
        indices_xo + 1, values_xo,
        linefmt = '-', markerfmt='o', basefmt=' ',  # Use ' ' for an invisible baseline initially
        label   = 'Ground-Truth'  # Add label for legend
    )
    plt.setp(markerline, 'color', '#f26419', 'markersize', 7, 'markerfacecolor', 'none')  # 'o' is hollow by default
    plt.setp(stemlines, 'color', '#f26419', 'linewidth', 1)

    indices_x = np.where(x.ravel() != 0)[0]
    values_x  = x[indices_x]

    markerline2, stemlines2, baseline2 = ax.stem(
        indices_x + 1, values_x,
        linefmt=':', markerfmt='o', basefmt=' ',
        label='Recovered'
    )

    plt.setp(markerline2, 'color', '#1c8ddb', 'markersize', 4, 'markerfacecolor', '#1c8ddb')
    plt.setp(stemlines2, 'color', '#1c8ddb', 'linewidth', 1)


    ax.grid(True)
    ymin = -0.1
    ymax = 0.2


    xx = np.concatenate((xo.ravel(), x.ravel()))

    if np.count_nonzero(xx < 0) > 0:
        ymin = np.min(xx[xx < 0]) - 0.1

    if np.count_nonzero(xx > 0) > 0:
        ymax = np.max(xx[xx > 0]) + 0.1

    ax.axis([1, len(x), ymin, ymax])

    if ind:
        snr = np.linalg.norm(x - xo) / np.linalg.norm(x)

        st1 = f'Recovery accuracy = {snr:.4g}'

        ax.set_title(st1, fontweight='normal')

        ax.legend()
    plt.show()
