import numpy as np
import scipy.sparse as sp
import time
import warnings
from typing import List, Dict, Any, Optional

def SNSQP(n: int, s: int, Q0: np.ndarray, q0: np.ndarray,
          Qi: Optional[List[np.ndarray]], qi: Optional[np.ndarray], ci: Optional[np.ndarray],
          ineqA: Optional[np.ndarray], ineqb: Optional[np.ndarray],
          eqA: Optional[np.ndarray], eqb: Optional[np.ndarray],
          lb: any, ub: any, pars: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    r"""
    This code aims at solving the sparse SQCQP in the form of

            min   (1/2)(x' Q0 x) + q0' x
            s.t.  (1/2)x' Qi[i] x + qi[:,i]' x + ci[i] <= 0,   i = 1,...,k,
                  ineqA @ x - ineqb <= 0,
                  eqA   @ x - eqb   = 0,
                  lb <= x <= ub,
                  ||x||_0 <= s,

    where Qi = [Qi[0], ..., Qi[k-1]],   each Qi[i] ∈ R^{n×n},
          qi ∈ R^{n×k},  ci ∈ R^k,
          ineqA ∈ R^{m1×n}, ineqb ∈ R^{m1},
          eqA   ∈ R^{m2×n}, eqb   ∈ R^{m2},
          s << n.

    ---------------------------------------------------------------------------------------------------
    Inputs:
        n:      Dimension of the solution x                                               (required)
        s:      Sparsity level of x, integer between 1 and n-1                            (required)
        Q0:     Quadratic objective matrix, shape (n, n)                                  (required)
        q0:     Quadratic objective vector, shape (n,)                                    (required)
        Qi:     Quadratic constraint matrices, list of arrays or None, each (n, n)        (optional)
        qi:     Quadratic constraint vectors, ndarray shape (n, k) or None                (optional)
        ci:     Quadratic constraint constants, ndarray shape (k,) or None                (optional)
        ineqA:  Linear inequality constraint matrix, shape (m1, n) or None                (optional)
        ineqb:  Linear inequality constraint vector, shape (m1,) or None                  (optional)
        eqA:    Linear equality constraint matrix, shape (m2, n) or None                  (optional)
        eqb:    Linear equality constraint vector, shape (m2,) or None                    (optional)
        lb:     Lower bounds of x, ndarray shape (n,) or None                             (optional)
        ub:     Upper bounds of x, ndarray shape (n,) or None                             (optional)
                NOTE: 0 must be in [lb, ub]
        pars:   Dictionary of parameters, all OPTIONAL
                pars["x0"]       -- Starting point of x                      (default: np.zeros(n))
                pars["dualquad"] -- Starting point of mu for quadratic cons. (default: np.zeros(k))
                pars["dualineq"] -- Starting point of λ1 for ineq constraints (default: np.zeros(m1))
                pars["dualeq"]   -- Starting point of λ2 for eq constraints   (default: np.zeros(m2))
                pars["dualbd"]   -- Starting point of ν for bounds            (default: np.zeros(n))
                pars["tau"]      -- Positive scalar                           (default: 1.0)
                                   NOTE: tuning tau may improve solutions
                pars["itlser"]   -- Maximum number of line search steps       (default: 5)
                pars["itmax"]    -- Maximum number of iterations              (default: 10000)
                pars["show"]     -- Verbosity: 1 = show per-iteration results,
                                   0 = silent                                 (default: 1)
                pars["tol"]      -- Stopping tolerance                        (default: 1e-6)

    Outputs:
        Out["sol"]:      The sparse solution x
        Out["sparsity"]: Sparsity level of Out["sol"]
        Out["error"]:    Error used to terminate solver
        Out["time"]:     CPU time
        Out["iter"]:     Number of iterations
        Out["obj"]:      Objective value at Out["sol"]

    ---------------------------------------------------------------------------------------------------
    This code is based on the algorithm proposed in:
    "Shuai Li, Shenglong Zhou, and Ziyan Luo, Sparse quadratically constrained
     quadratic programming via semismooth Newton method, arXiv:2503.15109, 2025."

    Send comments/suggestions to: 24110488@bjtu.edu.cn / slzhou2021@163.com
    Warning: Accuracy may not be guaranteed!
    ---------------------------------------------------------------------------------------------------
    """

    warnings.filterwarnings('ignore')
    t0 = time.time()
    if pars is None: pars = {}

    (dim, existcons, flagbd, lenf, show, x0, dualquad, dualineq, dualeq, dualbd, tau, tol, itmax,
     itlser, gamma, sigma, alpha0, lb, ub) = setparameters(n, s, Qi, ineqA, eqA, lb, ub, pars)

    # The main body
    if show:
        print('\n Start to run the sover -- SNSQP')
        print(' -------------------------------------------------')
        print(' Iter        Error        Objective      Time(sec)')
        print(' -------------------------------------------------')

    Fnorm    = lambda var: np.linalg.norm(var, 'fro') ** 2
    Ffun     = lambda x, T: FuncObj(x, Q0, q0, T)
    FQxq     = lambda x, T: FuncQxq(x, Qi, qi, dim[0], T, n) if existcons[0] else None
    FQxqc    = lambda x, T: FuncQxqc(x, Qi, qi, ci, dim[0], T) if existcons[0] else None
    FIneqAxb = lambda x, T: FuncAxb(x, ineqA, ineqb, T, n)
    FEqAxb   = lambda x, T: FuncAxb(x, eqA, eqb, T, n)
    FGradL   = lambda xT, T, vq, vi, ve, Qxq: GradLag(xT, Q0, q0, Qxq, ineqA, eqA, vq, vi, ve, T, existcons)
    FHessL   = lambda vq, T: HessLagT(Q0, Qi, vq, T, dim[0]) if existcons[0] else Q0[np.ix_(T - 1, T - 1)]
    FHessLc  = lambda vq, T, TTc: HessLagTc(Q0, Qi, vq, T, TTc, dim[0]) if existcons[0] else Q0[np.ix_(T - 1, TTc - 1)]

    if existcons[3]:
        FProjbd = lambda xT: Projbd(xT, lb, ub)
        JProjbd = lambda xT: JacProjbd(xT, lb, ub)

    z, Index, tau0, x = np.zeros((n, 1)), np.arange(1, n + 1), tau, x0
    T0                = np.sort(np.argsort(np.abs(x.flatten()))[-s:]) + 1
    xT, obj           = x[T0 - 1], Ffun(x[T0 - 1], T0)

    if existcons[0]:
        Qxq     = FQxq(xT, T0)
        Qqc     = FQxqc(xT, T0)
        Ncpqual = FuncNcpduad(Qqc, dualquad)
    else:
        Qxq, Ncpqual, Qqc = np.array([]), np.array([]), np.array([])

    if existcons[1]:
        Axb     = FIneqAxb(xT, T0)
        Ncpineq = FuncNcpineq(Axb, dualineq)
    else:
        Ncpineq, Axb = np.array([]), np.array([])

    Lineq = FEqAxb(xT, T0) if existcons[2] else np.array([])

    if existcons[3]:
        dualbdT        = dualbd[T0 - 1]
        xPT            = xT - FProjbd(xT + dualbdT)
        GradL          = FGradL(xT, T0, dualquad, dualineq, dualeq, Qxq)
        GradL[T0 - 1] += dualbdT
    else:
        xPT   = np.array([])
        GradL = FGradL(xT, T0, dualquad, dualineq, dualeq, Qxq)

    Indx, Indqual, Indineq, Indeq = np.arange(s), np.arange(s, s + dim[0]), np.arange(s + dim[0],
                                                                                      s + sum(dim[0:2])), np.arange(
        s + sum(dim[0:2]), s + sum(dim))

    for iter_1based in range(1, itmax + 1):
        iter  = iter_1based
        T     = np.sort(np.argsort(np.abs((x - tau * GradL).flatten()))[-s:]) + 1
        Tc    = np.setdiff1d(Index, T, assume_unique=True)
        TTc   = np.setdiff1d(T0, T)
        flagT = (TTc.size == 0)

        if existcons[3] and not flagT: xPT = x[T - 1] - FProjbd(x[T - 1] + dualbd[T - 1])

        StationEq = np.concatenate(
            [v.flatten() for v in [GradL[T - 1], Ncpqual, Ncpineq, Lineq, xPT] if v.size > 0]).reshape(-1, 1)
        error = np.linalg.norm(StationEq) + np.linalg.norm(x[Tc - 1])

        if show:
            print(f'{iter:4d}       {error:5.2e}      {obj:10.3e}    {time.time() - t0:7.3f}sec')
        if error <= tol: break

        HessTT = FHessL(dualquad, T)

        if existcons[0]:
            QxqT           = Qxq[T - 1, :]
            JPquad, JDquad = JacNcpquad(Qqc, dualquad, dim[0])
            Hquad          = JPquad * QxqT.T
        else:
            Hquad, JPquad, JDquad, QxqT = np.empty((0, s)), np.array([]), np.array([]), np.empty((s, 0))

        if existcons[1]:
            IneqAT         = ineqA[:, T - 1]
            JPineq, JDineq = JacNcpineq(Axb, dualineq, dim[1])
            Hineq          = JPineq * IneqAT
        else:
            Hineq, JPineq, JDineq, IneqAT = np.empty((0, s)), np.array([]), np.array([]), np.empty((0, s))

        EqAT = eqA[:, T - 1] if existcons[2] else np.empty((0, s))

        if existcons[3]:
            projbd     = JProjbd(xT + dualbdT) if flagT else JProjbd(x[T - 1] + dualbd[T - 1])
            U, eU, sbd = np.diag(projbd.flatten()), np.diag(1 - projbd.flatten()), s
        else:
            U, eU, sbd = np.empty((0, 0)), np.empty((0, 0)), 0

        row1 = np.hstack([HessTT, QxqT, IneqAT.T, EqAT.T, np.eye(sbd) if sbd > 0 else np.empty((s, 0))])
        row2 = np.hstack([Hquad, np.diag(JDquad.flatten()), np.zeros((dim[0], dim[1] + dim[2] + sbd))])
        row3 = np.hstack(
            [Hineq, np.zeros((dim[1], dim[0])), np.diag(JDineq.flatten()), np.zeros((dim[1], dim[2] + sbd))])
        row4 = np.hstack([EqAT, np.zeros((dim[2], sum(dim) + sbd))])
        row5 = np.hstack([eU, np.zeros((sbd, sum(dim))), -U])

        HessL = np.vstack([r for r in [row1, row2, row3, row4, row5] if r.size > 0])

        if iter == 1 or flagT or flagbd:
            STEq = -StationEq
        else:
            HessTc  = FHessLc(dualquad, T, TTc)
            STcquad = JPquad * Qxq[TTc - 1, :].T if existcons[0] and len(TTc) > 0 else np.empty((dim[0], len(TTc)))
            STcineq = JPineq * ineqA[:, TTc - 1] if existcons[1] and len(TTc) > 0 else np.empty((dim[1], len(TTc)))
            STceq   = eqA[:, TTc - 1] if existcons[2] and len(TTc) > 0 else np.empty((dim[2], len(TTc)))
            STcbd   = np.zeros((s, len(TTc))) if existcons[3] and len(TTc) > 0 else np.empty((0, len(TTc)))
            update_matrix = np.vstack([HessTc, STcquad, STcineq, STceq, STcbd])
            STEq    = -StationEq + (update_matrix @ x[TTc - 1])

        try:
            d = np.linalg.solve(HessL, STEq) if s < 1000 else my_cg(HessL, STEq, 1e-16, 20, np.zeros((lenf, 1)))
        except np.linalg.LinAlgError:
            d = np.full((lenf, 1), np.nan)

        if np.isnan(d).any():
            A, b = HessL.T @ HessL + (0.01 / iter) * sp.eye(lenf, format='csc'), HessL.T @ STEq
            d    = sp.linalg.spsolve(A, b).reshape(-1, 1) if sp.issparse(A) else np.linalg.solve(A, b)

        mark = 0
        while True:
            xT1 = x[T - 1] + d[Indx]
            dualquad1 = dualquad + d[Indqual]
            dualineq1 = dualineq + d[Indineq]
            dualeq1   = dualeq + d[Indeq]

            if existcons[0]:
                Qxq     = FQxq(xT1, T)
                Qqc     = FQxqc(xT1, T)
                Ncpqual = FuncNcpduad(Qqc, dualquad1)
            if existcons[1]:
                Axb     = FIneqAxb(xT1, T)
                Ncpineq = FuncNcpineq(Axb, dualineq1)
            if existcons[2]:
                Lineq   = FEqAxb(xT1, T)

            if existcons[3]:
                dualbdT1 = dualbd[T - 1] + d[s + sum(dim):]
                xPT      = xT1 - FProjbd(xT1 + dualbdT1)
                gradL1   = FGradL(xT1, T, dualquad1, dualineq1, dualeq1, Qxq);
                gradL1[T - 1] += dualbdT1
            else:
                gradL1   = FGradL(xT1, T, dualquad1, dualineq1, dualeq1, Qxq)

            F1 = np.concatenate(
                [v.flatten() for v in [gradL1[T - 1], Ncpqual, Ncpineq, Lineq, xPT] if v.size > 0]).reshape(-1, 1)

            if np.linalg.norm(F1) < 1e4 * error or mark == 2:
                break
            elif mark != 1:
                mark = 1
                A, b = HessL.T @ HessL + (0.01 / iter) * sp.eye(lenf, format='csc'), HessL.T @ STEq
                d    = sp.linalg.spsolve(A, b).reshape(-1, 1) if sp.issparse(A) else np.linalg.solve(A, b)
            else:
                mark, d = 2, STEq

        alpha, tmp = alpha0, Fnorm(StationEq) + Fnorm(x[Tc - 1])
        for j in range(itlser):
            if Fnorm(F1) < (1 - 2 * sigma * alpha) * tmp: break
            alpha     = alpha * gamma
            xT1       = x[T - 1] + alpha * d[Indx]
            dualquad1 = dualquad + alpha * d[Indqual]
            dualineq1 = dualineq + alpha * d[Indineq]
            dualeq1   = dualeq + alpha * d[Indeq]
            if existcons[0]:
                Qxq     = FQxq(xT1, T)
                Qqc     = FQxqc(xT1, T)
                Ncpqual = FuncNcpduad(Qqc, dualquad1)
            if existcons[1]:
                Axb     = FIneqAxb(xT1, T)
                Ncpineq = FuncNcpineq(Axb, dualineq1)
            if existcons[2]:
                Lineq = FEqAxb(xT1, T)
            if existcons[3]:
                dualbdT1 = dualbd[T - 1] + alpha * d[s + sum(dim):]
                xPT      = xT1 - FProjbd(xT1 + dualbdT1)
                gradL1   = FGradL(xT1, T, dualquad1, dualineq1, dualeq1, Qxq);
                gradL1[T - 1] += dualbdT1
            else:
                gradL1 = FGradL(xT1, T, dualquad1, dualineq1, dualeq1, Qxq)
            F1 = np.concatenate(
                [v.flatten() for v in [gradL1[T - 1], Ncpqual, Ncpineq, Lineq, xPT] if v.size > 0]).reshape(-1, 1)

        obj, x, xT = Ffun(xT1, T), z.copy(), xT1
        x[T - 1]   = xT1
        dualquad, dualineq, dualeq = dualquad1, dualineq1, dualeq1
        if existcons[3]:
            dualbd        = z.copy()
            dualbdT       = dualbdT1
            dualbd[T - 1] = dualbdT1
        GradL, T0 = gradL1, T
        if iter % 200 == 0: tau = max(0.1 * tau0, tau / 1.5)

    Iter_end, runtime = (iter == itmax), time.time() - t0
    Out = {'sol': x, 'sparsity': np.count_nonzero(x), 'error': error, 'time': runtime, 'iter': iter, 'obj': obj,
           'Iter_end': Iter_end}
    if show:
        print(' -------------------------------------------------')
        print(f' Obj :     {Out["obj"]:.4f}')
        print(f' Time:     {Out["time"]:.4f} seconds')
    return Out


def setparameters(n, s, Qi, ineqA, eqA, lb, ub, pars):
    if Qi is None: Qi = []
    if ineqA is None: ineqA = np.empty((0, n))
    if eqA is None: eqA = np.empty((0, n))

    dim = np.array([len(Qi), ineqA.shape[0], eqA.shape[0]])
    existcons = np.ones(4, dtype=bool)
    existcons[0] = dim[0] > 0
    existcons[1] = dim[1] > 0
    existcons[2] = dim[2] > 0

    if lb is None or (isinstance(lb, np.ndarray) and lb.size == 0): lb = -np.inf
    if ub is None or (isinstance(ub, np.ndarray) and ub.size == 0): ub = np.inf

    is_lb_inf    = (isinstance(lb, float) and np.isneginf(lb)) or (isinstance(lb, np.ndarray) and np.all(np.isneginf(lb)))
    is_ub_inf    = (isinstance(ub, float) and np.isposinf(ub)) or (isinstance(ub, np.ndarray) and np.all(np.isposinf(ub)))
    existcons[3] = not (is_lb_inf and is_ub_inf)

    lenf   = s + int(np.sum(dim)) + int(s * existcons[3])
    flagbd = (lb == 0 or ub == 0)

    show   = pars.get('show', 1)
    itmax  = int(pars.get('itmax', 1e4))
    x0     = pars.get('x0', np.zeros((n, 1)))
    tau    = pars.get('tau', 1)
    tol    = pars.get('tol', 1e-6)
    itlser = pars.get('itlser', 5)
    gamma  = pars.get('gamma', 0.5)
    sigma  = pars.get('sigma', 1e-4)
    alpha0 = pars.get('alpha0', 1)

    if 'dualquad' in pars and len(pars['dualquad']) == dim[0]:
        dualquad = pars['dualquad']
    else:
        dualquad = np.zeros((dim[0], 1))

    if 'dualineq' in pars and len(pars['dualineq']) == dim[1]:
        dualineq = pars['dualineq']
    else:
        dualineq = np.zeros((dim[1], 1))

    if 'dualeq' in pars and len(pars['dualeq']) == dim[2]:
        dualeq = pars['dualeq']
    else:
        dualeq = np.zeros((dim[2], 1))

    if existcons[3] and 'dualbd' in pars and len(pars['dualbd']) == n:
        dualbd = pars['dualbd']
    else:
        dualbd = np.zeros((n, 1)) if existcons[3] else np.array([])

    return dim, existcons, flagbd, lenf, show, x0, dualquad, dualineq, dualeq, dualbd, tau, tol, itmax, itlser, gamma, sigma, alpha0, lb, ub


def FuncObj(xT, Q0, q0, T):
    T_0based = T - 1
    sub_Q0   = Q0[np.ix_(T_0based, T_0based)]
    f        = (1 / 2) * xT.T @ sub_Q0 @ xT + np.sum(q0[T_0based] * xT)
    return f.item()


def GradLag(xT, Q0, q0, Qxq, IneqA, EqA, mu, lamb1, lamb2, T, iscons):
    T_0based = T - 1
    g = Q0[:, T_0based] @ xT + q0
    if iscons[2] and EqA is not None: g = g + (lamb2.T @ EqA).T
    if iscons[1] and IneqA is not None: g = g + (lamb1.T @ IneqA).T
    if iscons[0] and Qxq.size > 0: g = g + Qxq @ mu
    return g


def HessLagT(Q0, Qi, mu, T, k):
    T_0based = T - 1
    h = Q0[np.ix_(T_0based, T_0based)]
    for i in range(k): h = h + mu[i] * Qi[i][np.ix_(T_0based, T_0based)]
    return h


def HessLagTc(Q0, Qi, mu, T, TTc, k):
    T_0based, TTc_0based = T - 1, TTc - 1
    hc = Q0[np.ix_(T_0based, TTc_0based)]
    for i in range(k): hc = hc + mu[i] * Qi[i][np.ix_(T_0based, TTc_0based)]
    return hc

def FuncAxb(xT, A, b, T, n):
    if A is None: return -b
    Axb = -b.copy()
    if T.size > 0:
        idx = T - 1
        if xT.size <= int(np.ceil(0.025 * n)):
            Axb = Axb + A[:, idx] @ xT
        else:
            x = np.zeros((n,1))
            x[idx] = xT
            Axb = Axb + A @ x
    return Axb

def FuncQxq(xT, Qi, qi, k, T, n):
    Qxq = qi.copy()
    if T.size > 0:
        idx = T - 1
        small_threshold = int(np.ceil(0.025 * n))
        if xT.size <= small_threshold:
            for i in range(k):
                Qxq[:, i] += (Qi[i][:, idx] @ xT).flatten()
        else:
            x = np.zeros((n,1))
            x[idx] = xT
            for i in range(k):
                Qxq[:, i] = Qxq[:, i] + (Qi[i] @ x).flatten()
    return Qxq


def FuncQxqc(xT, Qi, qi, ci, k, T):
    Qqc = ci.copy()
    if T.size > 0:
        T_0based = T - 1
        tmp = xT.T @ qi[T_0based, :]
        for i in range(k):
            sub_Qi = Qi[i][np.ix_(T_0based, T_0based)]
            Qqc[i] = xT.T @ sub_Qi @ xT / 2 + tmp[0, i] + Qqc[i]
    return Qqc


def FuncNcpduad(Qqc, dualquad): return np.sqrt(Qqc ** 2 + dualquad ** 2) + Qqc - dualquad


def FuncNcpineq(Axb, dualineq): return np.sqrt(Axb ** 2 + dualineq ** 2) + Axb - dualineq


def JacNcpquad(Qqc, dualquad, k):
    zsqrt = np.sqrt(Qqc ** 2 + dualquad ** 2)
    with np.errstate(divide='ignore', invalid='ignore'):
        jprimquad = np.divide(Qqc, zsqrt, out=np.zeros_like(Qqc), where=zsqrt != 0) + 1
        jdualquad = np.divide(dualquad, zsqrt, out=np.zeros_like(dualquad), where=zsqrt != 0) - 1
    for i in range(k):
        if zsqrt[i] == 0:
            angle = np.random.rand() * 2 * np.pi
            r = np.sqrt(np.random.rand())
            jprimquad[i] = r * np.cos(angle) + 1
            jdualquad[i] = r * np.sin(angle) - 1
    return jprimquad, jdualquad


def JacNcpineq(Axb, dualineq, m):
    zsqrt = np.sqrt(Axb ** 2 + dualineq ** 2)
    with np.errstate(divide='ignore', invalid='ignore'):
        jprimineq = np.divide(Axb, zsqrt, out=np.zeros_like(Axb), where=zsqrt != 0) + 1
        jdualineq = np.divide(dualineq, zsqrt, out=np.zeros_like(dualineq), where=zsqrt != 0) - 1
    for i in range(m):
        if zsqrt[i] == 0:
            angle = np.random.rand() * 2 * np.pi
            r = np.sqrt(np.random.rand())
            jprimineq[i] = r * np.cos(angle) + 1
            jdualineq[i] = r * np.sin(angle) - 1
    return jprimineq, jdualineq


def Projbd(xT, lb, rb): return np.clip(xT, lb, rb)


def JacProjbd(xT, lb, ub):
    sx   = len(xT)
    jpbd = np.zeros((sx, 1))
    jpbd[(xT > lb) & (xT < ub)] = 1
    jpbd[(xT == lb) | (xT == ub)] = 0.5
    return jpbd


# --- Conjugate gradient descent to solve linear equations ---
def my_cg(fx, b, cgtol, cgit, x):
    if not callable(fx):
        mat = fx
        fx = lambda v: mat @ v

    if np.count_nonzero(x) > 0:
        r = b - fx(x)
    else:
        r = b.copy()

    e = np.linalg.norm(r) ** 2
    t = e
    p = r.copy()

    for i in range(cgit):
        if e < cgtol * t:
            break
        w = fx(p)
        pw = p * w
        a = e / np.sum(pw)
        x = x + a * p
        r = r - a * w
        e0 = e
        e = np.linalg.norm(r) ** 2
        if e0 < 1e-20:
            break
        p = r + (e / e0) * p

    return x