# demon SCCA problems
import numpy as np
from SNSQPpack import SNSQP, DataSCCA, PlotSCCA

nx = 200
ny = 300
N  = 50
s  = 10
n  = nx + ny
dt = DataSCCA(nx, ny, N)

pars             = {'x0':dt['x0']}
pars['tau']      = 0.01  # decrease this value if the algorithm does not converge
pars['itmax']    = 1000
pars['islter']   = 10
pars['dualquad'] = 0.01 * np.ones((len(dt['Qi']), 1))
out              = SNSQP(n, s, dt['Q0'], dt['q0'], dt['Qi'], dt['qi'], dt['ci'],
                   None, None, None, None, None, None, pars)

print(f" Corr:      {-out['obj']:.4f} \n")
PlotSCCA(out['sol'], int(np.ceil(nx / 200)))