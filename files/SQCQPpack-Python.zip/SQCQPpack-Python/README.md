# SNSQP

This package offers 1 solver for sparse quadratically constrained quadratic programming  
based on the algorithm proposed in the following paper: 

Shuai Li, Shenglong Zhou, Ziyan Luo, 
Sparse Quadratically Constrained Quadratic Programming via Semismooth Newton Method, 
[arXiv:2503.15109](https://arxiv.org/abs/2503.15109), 2025.

Please credit this paper if you use the code for your research.