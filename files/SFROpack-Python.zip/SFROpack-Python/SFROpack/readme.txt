Please run "demonXXXX.py" to solve different problems 

This package offers 1 solver for step function regularized optimization problems  
based on the algorithm proposed in the following paper: 

NM01-----------------------------------------------------------------------
    Shenglong Zhou, Lili Pan, Naihua Xiu, Houduo Qi, 
    Quadratic convergence of smoothing Newton's method for 0/1 loss optimization,
    SIAM Journal on Optimization, 31(4): 3184–3211, 2021.

Please give credits to this paper if you use the code for your research.

===========================================================================
def NM01(func, B, b, lam, pars=None):
# -------------------------------------------------------------------------
# This code aims at solving the support vector machine with form
#
#       min  f(x) + lam * ||(B x + b)_+||_0
#
# where f is twice continuously differentiable
# lam > 0, B ∈ ℝ^{m×n}, b ∈ ℝ^{m×1}
# (z)_+ = (max{0,z1}, ..., max{0,zm})^T
# ||(z)_+||_0 counts the number of positive entries of z
# -------------------------------------------------------------------------
# Inputs:
#   func : A callable defining (objective, gradient, Hessian)   (REQUIRED)
#   B    : A matrix in ℝ^{m×n}                                          (REQUIRED)
#   b    : A vector in ℝ^{m×1}                                          (REQUIRED)
#   lam  : The penalty parameter                                        (REQUIRED)
#   pars : Parameters are all OPTIONAL
#          pars["x0"]     -- Initial point                       (default: np.zeros(n))
#          pars["tau"]    -- A useful parameter                  (default: 1.00)
#          pars["mu0"]    -- Smoothing parameter                 (default: 0.01)
#          pars["maxit"]  -- Max number of iterations            (default: 1000)
#          pars["tol"]    -- Stopping tolerance                  (default: 1e-7 * sqrt(n*m))
#          pars["strict"] -- = 0, loose stopping                 (default)
#                            = 1, strict stopping
#                            strict=1 is useful for low dimensions
# -------------------------------------------------------------------------
# Outputs:
#   out["sol"]  : The solution
#   out["obj"]  : Objective function value
#   out["time"] : CPU time
#   out["iter"] : Number of iterations
# -------------------------------------------------------------------------
# Send your comments and suggestions to <<< slzhou2021@163.com >>>
# WARNING: Accuracy may not be guaranteed!!!!!
# -------------------------------------------------------------------------
# Below is one example that you can run
# =========================================================================
# Solving support vector machine using four synthetic samples
import numpy as np
import matplotlib.pyplot as plt
from SFROpack import NM01, funcSVM

a             = 10
A             = np.array([[0, 0], [0, 1], [1, 0], [1, a]])
c             = np.array([[-1], [-1], [1], [1]])
m, n_features = A.shape

func          = lambda x, key: funcSVM(x, key, 1e-4, A, c)
B             = -c * np.hstack((A, np.ones((m, 1))))
b             = np.ones((m, 1))
lam           = 10
pars          = {'tau': 1, 'strict': 1}
out           = NM01(func, B, b, lam, pars)
x             = out['sol']

fig           = plt.figure(figsize=(3.5, 3.3))
ax            = fig.add_axes([0.08, 0.08, 0.88, 0.88])
ax.scatter([1, 1], [0, a], s=80, marker='+', c='m', label='Positive')
ax.scatter([0, 0], [0, 1], s=80, marker='x', c='b', label='Negative')
if x[0] != 0:
    p1 = -x[2] / x[0]
    ax.plot([p1, p1], [-1, 1.1 * a], color='r')
ax.axis([-.1, 1.1, -1, 1.1 * a])
ax.grid(True)
accuracy = func(x, 'a') * 100
ld       = f"NM01: {accuracy:.0f}%"
ax.plot([], [], color='r', label=ld)
ax.legend(loc='upper left')
plt.show()