# Solving support vector machine using real datasets
import numpy as np
from scipy.io import loadmat
from scipy import sparse
from SFROpack import normalization, NM01, funcSVM

test         = 2
data         = ['arce', 'fabc']
prob         = data[test - 1]
samp         = loadmat(f"SFROpack/examples/svm/data/{prob}.mat")
label        = loadmat(f"SFROpack/examples/svm/data/{prob}_class.mat")
A            = normalization(samp['X'], 2)
c            = label['y']
c[c != 1]    = -1
m, n0        = A.shape

if sparse.issparse(A):
    ones_col = sparse.csr_matrix(np.ones((A.shape[0], 1)))
    Ac       = sparse.hstack([A, ones_col], format="csr")  # 或 "csc"
    B        = Ac.multiply(-c)
    B        = B.tocsr()
else:
    Ac       = np.hstack((A, np.ones((m, 1))))
    B        = -c * Ac

func         = lambda x, key: funcSVM(x, key, 1e-4, A, c)
b            = np.ones((m, 1))
pars         = {'tau': 1}
lam          = 10
out          = NM01(func, B, b, lam, pars)

predictions  = np.sign(Ac @ out['sol'])
acc          = 1 - np.count_nonzero(predictions - c) / m
print(f" Training  Size:        {m} x {n0}")
print(f" Training  Time:        {out['time']:5.3f}sec")
print(f" Training  Accuracy:    {acc*100:5.2f}%")
print(f" Training  Objective:   {out['obj'][0]:5.3e}")