# Solving 1 bit compressive sensing using randomly generated data
import numpy as np
from SFROpack import random1bcs, func1BCS, NM01, refine, PlotRecovery

n            = 1000
m            = int(np.ceil(0.5 * n))
s            = int(np.ceil(0.01 * n))
r            = 0.01
nf           = 0.05

A, c, co, xo = random1bcs('Ind', m, n, s, nf, r, 0.5)

func         = lambda x, key: func1BCS(x, key, 1e-5, 0.5, A, c)
B            = -c * A
b            = min(1.0, n * 10e-5) * np.ones((m, 1)) # reduce 10e-5 if the solver diverges
lam          = 1
pars         = {'tau': 5, 'strict': (n <= 1000)}
out          = NM01(func, B, b, lam, pars)
x            = refine(out['sol'], s, A, c)

PlotRecovery(xo, x, [1800, 50, 500, 250], True)
print(f" Computational time:    {out['time']:.3f}sec")
snr = -20 * np.log10(np.linalg.norm(x - xo))
print(f" Signal-to-noise ratio: {snr:.2f}")
hamming_dist = np.count_nonzero(np.sign(A @ x) - c) / m
print(f" Hamming distance:      {hamming_dist:.3f}")
hamming_err = np.count_nonzero(np.sign(A @ x) - co) / m
print(f" Hamming error:         {hamming_err:.3f}")