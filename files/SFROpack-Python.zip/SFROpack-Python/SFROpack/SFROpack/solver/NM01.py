import numpy as np
import time
import warnings
from math import sqrt
from scipy import sparse

def NM01(func, B, b, lam, pars=None):
    r"""
    -------------------------------------------------------------------------
    This code aims at solving the support vector machine with form

          min  f(x) + lam * ||(B x + b)_+||_0

    where f is twice continuously differentiable
    lam > 0, B ∈ ℝ^{m×n}, b ∈ ℝ^{m×1}
    (z)_+ = (max{0,z1}, ..., max{0,zm})^T
    ||(z)_+||_0 counts the number of positive entries of z
    -------------------------------------------------------------------------
    Inputs:
      func : A callable defining (objective, gradient, Hessian)   (REQUIRED)
      B    : A matrix in ℝ^{m×n}                                 (REQUIRED)
      b    : A vector in ℝ^{m×1}                                 (REQUIRED)
      lam  : The penalty parameter                               (REQUIRED)
      pars : Parameters are all OPTIONAL
             pars["x0"]     -- Initial point        (default: np.zeros(n))
             pars["tau"]    -- A useful parameter  (default: 1.00)
             pars["mu0"]    -- Smoothing parameter (default: 0.01)
             pars["maxit"]  -- Max number of iterations (default: 1000)
             pars["tol"]    -- Stopping tolerance (default: 1e-7 * sqrt(n*m))
             pars["strict"] -- = 0, loose stopping (default)
                               = 1, strict stopping
                               strict=1 is useful for low dimensions
    -------------------------------------------------------------------------
    Outputs:
      out["sol"]  : The solution
      out["obj"]  : Objective function value
      out["time"] : CPU time
      out["iter"] : Number of iterations
    -------------------------------------------------------------------------
    Send your comments and suggestions to <<< slzhou2021@163.com >>>
    WARNING: Accuracy may not be guaranteed!!!!!
    -------------------------------------------------------------------------
    """
    warnings.filterwarnings('ignore')
    if B is None or b is None or lam is None:
        print(' Inputs are not enough !!! \n')
        return
    if pars is None:
        pars = {}

    t0   = time.time()
    m, n = B.shape

    maxit, tau, mu, x, tol, tolcg, strict = GetParameters(m, n, pars)

    Fnorm = lambda var: np.linalg.norm(var, 'fro') ** 2
    obje  = lambda var: func(var, 'f')
    grad  = lambda var: func(var, 'g')
    Hess  = lambda var: func(var, 'h')
    fBxb  = lambda var: B @ var + b

    accu = lambda var: func(var, 'a')
    accu_val = accu(x)
    if accu_val is None or (isinstance(accu_val, np.ndarray) and accu_val.size == 0):
        accu = lambda var: (1 - np.count_nonzero(fBxb(var) > 0) / m)

    z   = np.ones((m, 1))
    u   = x
    Bxb = fBxb(x)
    Bxz = Bxb + tau * z
    lam = max(1 / (2 * tau), lam)
    Acc = np.zeros((maxit, 1))
    Obj = np.zeros((maxit, 1))
    T   = np.array([])

    print(' Start to run the solver -- NM01')
    print(' ------------------------------------------------------------------')
    print('  Iter       Accuracy      Objective        Error        Time(sec) ')
    print(' ------------------------------------------------------------------')

    for iter in range(1, maxit + 1):
        T0           = T
        T, empT, lam = Ttau(Bxz, Bxb, tau, lam)

        if iter > 3 and np.std(Acc[iter - 4:iter - 1], ddof=1) < 1e-8:
            T = np.unique(np.union1d(T0, T)).astype(int)

        nT = T.size
        if T0.size == nT and np.count_nonzero(T0 - T) == 0:
            flag = 0
        else:
            flag = 1

        g = grad(x)
        if empT:
            error = Fnorm(g) + Fnorm(z)
        else:
            if flag:
                BT   = B[T, :]
                fBT  = lambda var: BT @ var
                fBTt = lambda var: BT.T @ var

            zT    = z[T]
            rhs1  = g + fBTt(zT)
            rhs2  = Bxb[T]
            error = Fnorm(rhs1) + Fnorm(rhs2) + Fnorm(z) - Fnorm(z[T])

        error         = error / sqrt(n * m)
        Acc[iter - 1] = accu(x) * 100
        Obj[iter - 1] = obje(x)
        if iter < 10 or iter % 10 == 0:
            print(
                f'  {iter:3d}       {Acc[iter - 1][0]:8.3f}       {Obj[iter - 1][0]:8.4f}       {error:8.3e}       {(time.time() - t0):.3f}sec')

        stop = 0
        if iter > 5 and strict:
            stop = max(error, Fnorm(u)) < tol
        elif iter > 5 and not strict:
            stop1 = min(error, Fnorm(u)) < tol
            stop2 = np.std(Acc[iter - 6:iter - 1],ddof=1) < 1e-10
            stop3 = np.std(Obj[iter - 6:iter - 1],ddof=1) < 1e-4 * (1 + sqrt(abs(Obj[iter - 1])))
            stop  = stop1 or (stop2 and stop3)

        if stop:
            if iter > 10 and iter % 10 != 0:
                print(
                    f'  {iter:3d}       {Acc[iter - 1][0]:8.3f}       {Obj[iter - 1][0]:8.4f}       {error:8.3e}       {(time.time() - t0):.3f}sec')
            break

        if empT:
            u = -g
            v = -z
        else:
            H              = Hess(x)
            isfunH         = callable(H)
            is_diag_matrix = False
            if sparse.issparse(H):
                if H.nnz == np.count_nonzero(H.diagonal()):
                    is_diag_matrix = True
            elif isinstance(H, np.ndarray) and H.ndim == 2:
                is_diag_matrix = np.all(H == np.diag(np.diag(H)))

            if not isfunH and n <= 1e3 and nT <= 1e4:
                u    = np.linalg.solve(BT.T @ BT + mu * H, -mu * rhs1 - fBTt(rhs2))
                v    = -z
                v[T] = (fBT(u) + rhs2) / mu
            elif not isfunH and n > 1e3 and is_diag_matrix and n <= 5e3:
                invH = np.diag(H).copy()
                invH[np.abs(invH) < 1e-8] = 1e-4 / iter
                invH = 1. / invH
                D = BT @ (invH[:, np.newaxis] * BT.T)
                np.fill_diagonal(D, np.diag(D) + mu)
                vT = np.linalg.solve(D, rhs2 - fBT(invH[:, np.newaxis] * rhs1))
                v = -z
                v[T] = vT
                u = -invH[:, np.newaxis] * (rhs1 + fBTt(vT))
            else:
                if isfunH:
                    fx = lambda var: fBTt(fBT(var)) + mu * H(var)
                else:
                    fx = lambda var: fBTt(fBT(var)) + mu * (H @ var)
                u = my_cg(fx, -mu * rhs1 - fBTt(rhs2), tolcg, 20, np.zeros((n, 1)))
                v = -z
                v[T] = (fBT(u) + rhs2) / mu

        alpha = 1.0
        x0    = x
        z0    = z
        obj0 = obje(x)
        for i in range(4):
            x = x0 + alpha * u
            if obje(x) < obj0:
                break
            alpha = 0.8 * alpha
        z = z0 + alpha * v
        Bxb = fBxb(x)
        if iter % 5 == 0:
            mu  = max(1e-8, mu / 1.1)
            tau = max(1e-4, tau / 1.1)
            lam = lam * 1.1
        Bxz = Bxb + tau * z

    print(' ------------------------------------------------------------------')
    out         = {}
    out['sol']  = x
    out['obj']  = obje(x)
    out['time'] = time.time() - t0
    out['iter'] = iter
    return out


# --------------------------------------------------------------------------
def GetParameters(m, n, pars):
    maxit  = 1000
    mn     = m * n
    tolcg  = 1e-8 * sqrt(mn)
    tol    = 1e-7 * sqrt(mn)
    tau    = 1.00
    mu     = 0.01
    x0     = np.zeros((n, 1))
    strict = 0
    if 'maxit' in pars: maxit = pars['maxit']
    if 'tau' in pars: tau = pars['tau']
    if 'x0' in pars: x0 = pars['x0']
    if 'tol' in pars: tol = pars['tol']
    if 'mu0' in pars: mu = pars['mu0']
    if 'strict' in pars: strict = pars['strict']
    return maxit, tau, mu, x0, tol, tolcg, strict


# select the index set T----------------------------------------------------
def Ttau(Bxz, Bxb, tau, lam):
    tl   = sqrt(tau * lam / 2)
    T    = np.where(np.abs(Bxz - tl) <= tl)[0]
    empT = T.size == 0

    if empT:
        zp = Bxb[Bxb >= 0]
        T  = np.array([])
        if zp.size > 0:
            s_idx = int(np.ceil(0.01 * zp.size)) - 1
            s_idx = max(0, min(s_idx, len(zp) - 1))
            s_val = np.sort(zp)[s_idx]
            tau   = (s_val) ** 2 / 2 / lam
            tl    = sqrt(tau * lam / 2)
            T     = np.where(np.abs(Bxb - tl) < tl)[0]
        empT = T.size == 0

    return T, empT, lam


# Set initial lam----------------------------------------------------------
def Initialam(m, n, z, tau):
    zp    = z[z > 0]
    s_idx = min(m, 20 * n, zp.size) - 1
    s_idx = max(0, s_idx)
    s_val = np.sort(zp)[s_idx]
    lam   = max(5, max((s_val) ** 2, 1) / (2 * tau))
    return lam


# conjugate gradient-------------------------------------------------------
def my_cg(fx, b, cgtol, cgit, x):
    if np.linalg.norm(b) == 0:
        return np.zeros_like(x)
    if not callable(fx):
        fx_mat = fx
        fx     = lambda v: fx_mat @ v

    r = b
    if np.count_nonzero(x) > 0:
        r = b - fx(x)

    e = np.linalg.norm(r) ** 2
    t = e
    p = r
    for i in range(cgit):
        if e < cgtol * t:
            break
        w = fx(p)
        pw = p * w
        a = e / np.sum(pw)
        x = x + a * p
        r = r - a * w
        e0 = e
        e = np.linalg.norm(r) ** 2
        p = r + (e / e0) * p
    return x

