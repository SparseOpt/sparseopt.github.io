import numpy as np


def random1bcs(type, m, n, s, nf, r, v):
    """
    This file aims at generating data of 2 types of Guassian samples
    for 1-bit compressed sensing
    Inputs:
        type     -- can be 'Ind','Cor'
        m        -- number of samples
        n        -- number of features
        s        -- sparsity of the true singnal, e.g., s=0.01n
        nf       -- nosie factor
        r        -- flipping ratio, 0~1, e.g., r=0.05
        v        -- corrolation factor, 0~1, e.g., v=0.5
    Outputs:
        X        --  samples data, m-by-n matrix
        xopt     --  n-by-1 vector, i.e., the ture singnal
        y        --  m-by-1 vector, i.e., sign(X*xopt+noise)
        yf       --  m-by-1 vector, y after flapping some signs

    written by Shenglong Zhou, 19/07/2020
    """
    if type == 'Ind':
        X = np.random.randn(m, n)
    elif type == 'Cor':
        j = np.arange(1, n + 1).reshape(1, -1)
        i = np.arange(1, n + 1).reshape(-1, 1)
        S = v ** (np.abs(i - j))
        X = np.random.multivariate_normal(np.zeros(n), S, m)

    xopt, T = sparse(n, s)
    y       = np.sign(X[:, T] @ xopt[T] + nf * np.random.randn(m, 1))
    yf      = flip(y, r)

    return X, yf, y, xopt


def sparse(n, s):
    """
    generate a sparse vector
    """
    T    = np.random.choice(n, s, replace=False)
    x    = np.zeros((n, 1))
    x[T] = 0.5 + np.random.randn(s, 1)
    x[T] = x[T] + np.sign(x[T])
    x[T] = x[T] / np.linalg.norm(x[T])
    return x, T


def flip(yopt, r):
    yf          = yopt.copy()
    m           = len(yopt)
    num_to_flip = int(np.ceil(r * m))
    T           = np.random.choice(m, num_to_flip, replace=False)
    yf[T]       = -yf[T]
    return yf


