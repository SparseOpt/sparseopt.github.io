import numpy as np


def refine(x, sp, A0, c):
    """
    x:  a vector, NumPy array of shape (n, 1)        (REQUIRED)
    sp: a positive integer or None.                    (REQUIRED)
    A0: a matrix, NumPy array of shape (m, n)          (REQUIRED if sp is not None)
    c:  a vector, NumPy array of shape (m, 1)          (REQUIRED if sp is not None)
    """
    if sp is not None:
        m, n = A0.shape
        K    = 6

        abs_x_flat = np.abs(x.flatten())
        Ts         = np.argsort(abs_x_flat)[::-1][:sp + K - 1]
        sx         = abs_x_flat[Ts]
        HD         = np.ones(K)
        X          = np.zeros((n, K))

        if sx[sp - 1] - sx[sp] <= 5e-2:
            tem = Ts[sp - 1:]
            for i in range(K):
                X[:, i]           = np.zeros(n)
                X[Ts[:sp - 1], i] = x.flatten()[Ts[:sp - 1]]
                X[tem[i], i]      = x.flatten()[tem[i]]

                norm_Xi = np.linalg.norm(X[:, i])
                if norm_Xi > 0:
                    X[:, i] = X[:, i] / norm_Xi

                HD[i] = np.count_nonzero(np.sign(A0 @ X[:, i] - c.flatten())) / m

            i_min = np.argmin(HD)
            refx  = X[:, i_min]
            refx  = refx.reshape(-1, 1)
        else:
            refx                    = np.zeros((n, 1))
            top_sp_indices          = Ts[:sp]
            values                  = x[top_sp_indices, 0]
            refx[top_sp_indices, 0] = values / np.linalg.norm(values)
    else:
        refx      = SparseApprox(x.copy())
        norm_refx = np.linalg.norm(refx)
        if norm_refx > 0:
            refx = refx / norm_refx

    if np.any(np.isnan(refx)):
        refx      = SparseApprox(x.copy())
        norm_refx = np.linalg.norm(refx)
        if norm_refx > 0:
            refx = refx / norm_refx

    return refx


def SparseApprox(x0):
    """
    get the sparse approximation of x
    """
    n  = len(x0)
    x  = np.abs(x0[x0 > 1e-2 / n])
    sx = np.sort(x[x != 0])

    th = 0
    if len(sx) > 1:
        ratios = sx[1:] / sx[:-1]

        mx    = np.max(ratios)
        it_py = np.argmax(ratios)
        it_ml = it_py + 1
        if mx > 10 and it_ml > 1:
            th = sx[it_py]

    x0[np.abs(x0) <= th] = 0
    return x0