import numpy as np

def func1BCS(x, key, eps, q, A, c):
    if key == 'f':
        out = np.sum((x ** 2 + eps) ** (q / 2))
    elif key == 'g':
        out = q * x * (x ** 2 + eps) ** (q / 2 - 1)
    elif key == 'h':
        def Hv(v):
            x2 = x * x
            diag_vector = ((x2 + eps) ** (q / 2 - 2)) * ((q - 1) * x2 + eps)
            v           = diag_vector*v
            return v
        out = Hv
    elif key == 'a':
        acc = lambda var: np.count_nonzero(np.sign(A @ var) - c)
        out = 1 - acc(x) / len(c)
    else:
        out = None

    return out