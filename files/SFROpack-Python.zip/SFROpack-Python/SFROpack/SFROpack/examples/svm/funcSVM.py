import numpy as np


def funcSVM(x, key, w, A, c):
    n = len(x)

    if key == 'f':
        out = np.linalg.norm(x) ** 2 - (1 - w) * x[n - 1] ** 2

    elif key == 'g':
        out        = x.copy()
        out[n - 1] = w * x[n - 1]

    elif key == 'h':
        def Hv(v):
            v        = np.asarray(v).copy()
            v[n - 1] = w * v[n - 1]
            return v
        out = Hv

    elif key == 'a':
        acc = lambda var: np.count_nonzero(np.sign((A @ var[:n - 1] + var[n - 1])) - c)
        out = 1 - acc(x) / len(c)

    else:
        out = None

    return out