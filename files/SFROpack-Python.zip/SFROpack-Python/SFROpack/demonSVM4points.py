# Solving support vector machine using four synthetic samples
import numpy as np
import matplotlib.pyplot as plt
from SFROpack import NM01, funcSVM

a             = 10
A             = np.array([[0, 0], [0, 1], [1, 0], [1, a]])
c             = np.array([[-1], [-1], [1], [1]])
m, n_features = A.shape

func          = lambda x, key: funcSVM(x, key, 1e-4, A, c)
B             = -c * np.hstack((A, np.ones((m, 1))))
b             = np.ones((m, 1))
lam           = 10
pars          = {'tau': 1, 'strict': 1}
out           = NM01(func, B, b, lam, pars)
x             = out['sol']

fig           = plt.figure(figsize=(3.5, 3.3))
ax            = fig.add_axes([0.08, 0.08, 0.88, 0.88])
ax.scatter([1, 1], [0, a], s=80, marker='+', c='m', label='Positive')
ax.scatter([0, 0], [0, 1], s=80, marker='x', c='b', label='Negative')
if x[0] != 0:
    p1 = -x[2] / x[0]
    ax.plot([p1, p1], [-1, 1.1 * a], color='r')
ax.axis([-.1, 1.1, -1, 1.1 * a])
ax.grid(True)
accuracy = func(x, 'a') * 100
ld       = f"NM01: {accuracy:.0f}%"
ax.plot([], [], color='r', label=ld)
ax.legend(loc='upper left')
plt.show()