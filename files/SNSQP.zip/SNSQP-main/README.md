# SNSQP

This solver was created based on the algorithm proposed by

Shuai Li, Shenglong Zhou, Ziyan Luo, Sparse Quadratically Constrained Quadratic Programming via Semismooth Newton Method, [arXiv:2503.15109](https://arxiv.org/abs/2503.15109), 2025.

Please credit this paper if you use the code for your research.
