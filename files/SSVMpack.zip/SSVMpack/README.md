# SSVMpack

This package offers 2 solvers for sparse support vector machine problems 
based on the algorithms proposed in the following 2 papers: 

## NM01 
   Shenglong Zhou, Lili Pan, Naihua Xiu and Huoduo Qi, 
   Quadratic convergence of smoothing Newton's method for 0/1 loss optimization, 
   SIAM Journal on Optimization, 31, 3184–3211, 2021.

## NSSVM 
   Shenglong Zhou, 
   Sparse SVM for sufficient data reduction, 
   IEEE Transactions on Pattern Analysis and Machine Intelligence, 44, 5560-5571, 2022.

Please credit them if you use the code for your research.


