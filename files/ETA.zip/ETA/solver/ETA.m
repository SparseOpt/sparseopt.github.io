function out = ETA(n, func, pars)
% This code aims at solving the sparse complementarity problem (CL) with form
%
%                  min    ||x-z||^2 + lambda ||x||_1
%                  s.t.   z = max(0, x-F(x))
%
% where x\in\R^n, F(x):\R^n-->\R^n.  
%
% Inputs:
%     n       : Dimension of the solution x, (required)
%     func    : function handle defines the function F(x). For example,
%               A linear CP:    F(x) = M*x+q, where M\R^{n*n},q\R^{n}
%                               func = @(x,T)(M(:,T)*x(T)+q);                
%               A nonlinear CP: F(x) = a.*arctan(x)+M*x+q, where a\R^{n},M\R^{n*n},q\R^{n}
%                               func = @(x,T)(a.*atan(x)+M(:,T)*x(T)+q); 
%               
%     pars:     Parameters are all OPTIONAL
%               pars.iteron --  Results will  be shown for each iteration if pars.iteron=1 (default)
%                               Results won't be shown for each iteration if pars.iteron=0 
%               pars.maxit  --  Maximum nonumber of iteration.  pars.maxit=5000 (default) 
%               pars.tol    --  Tolerance of stopping criteria. pars.maxit=1e-5 (default) 
%
% Outputs:
%     out.x:             The sparse solution x 
%     out.Fx:            F(x)
%     out.xFx:           x'*F(x)
%     out.time           CPU time
%     out.iter:          Number of iterations
%
% This solver was created based on the algorithm proposed by  
% Shang, M., Zhou, S. & Xiu N, Extragradient thresholding methods for sparse 
% solutions of co-coercive NCPs, Journal of Inequalities and Applications, vol. 34, 2015.
%
%%%%%%%    Send your comments and suggestions to                     %%%%%%
%%%%%%%    shenglong.zhou@soton.ac.uk                                %%%%%% 
%%%%%%%    Warning: Accuracy may not be guaranteed!!!!!              %%%%%%

warning off;

if nargin<2; error('Imputs are not enough!\n'); end
if nargin<3; pars=[]; end
if isfield(pars,'iteron');iteron = pars.iteron; else; iteron = 1;     end
if isfield(pars,'maxit'); maxit  = pars.maxit;  else; maxit  = 5000;  end
if isfield(pars,'tol');   tol    = pars.tol;    else; tol    = 1e-5;  end  
   
t0      = tic; 
lambda  = 0.5;  
mu      = 0.1; 
z       = zeros(n,1); 

if iteron 
   fprintf(' Start to run the sover -- ETA\n'); 
   fprintf('------------------------------------\n');
   fprintf(' Iter          Error          Time \n'); 
   fprintf('------------------------------------\n');
end

% Main Body
for iter=1:maxit

	if  mod(iter,10)==0
        lambda=lambda*0.75;
    end

    x     = max(0, z-lambda/2); 
	Fx    = func(x,x>0); 
	alpha = .1;  

	for j  = 1:5       
        y  = max(0,x-alpha*Fx);
        Fy = func(x,y>0); 
        if norm(Fx-Fy)<=mu*norm(x-y)/alpha; break; end
        alpha = alpha/2;
    end
 
	error = norm(x-z)/max(1,norm(x));
    if mod(iter,10)==0 && iteron
       fprintf('%4d         %5.2e       %5.2fsec\n',iter,error,toc(t0)); 
    end
        
	if error<tol && iter>1; break; end
        
	z = max(0,x-alpha*Fy);
        
end 
fprintf('------------------------------------\n');    
x        = sparse(x,n);
out.x    = x;
out.Fx   = Fx;
out.xFx  = sum(x(x>0).*Fx(x>0));
out.iter = iter;
out.time = toc(t0);
out.sparsity = nnz(x);
end

% get the sparse approximation of x----------------------------------------
function sx = sparse(x,n)
x(x<0)  = 0;
T       = find(x);
[sx,id] = sort(x(T),'descend'); 
y       = 0;
nx      = sum(x(T));
nT      = nnz(T);
t       = zeros(nT-1,1);
for i   = 1:nT
    if y > 0.9995*nx; break; end
    y    = y + sx(i); 
    if i < nT
    t(i) = sx(i)/sx(i+1);
    end
end
if  i  < nT
    j  = find(t==max(t)); 
    i  = j(1);
else
    i  = nT;
end
sx = zeros(n,1);
sx(T(id(1:i))) = x(T(id(1:i)));
end
