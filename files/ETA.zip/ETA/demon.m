clc; close all; clear all; warning off
addpath(genpath(pwd));
 
exmpno    = 2; 
matype    = {'LC-zmat','LC-sdp','NC-atan','NC-exp'};
exmpna    = matype{exmpno};
n         = 2000;
s         = ceil(0.05*n);
data      = CPdata(n,s,exmpna); 

switch exmpna
case {'LC-zmat', 'LC-sdp'};     func = @(x,T)(data.M(:,T)*x(T)+data.q);
case 'NC-atan'; func = @(x,T)(data.a.*atan(x)+data.M(:,T)*x(T)+data.q);
case 'NC-exp';  func = @(x,T)(data.a.*exp(-x)+data.M(:,T)*x(T)+data.q);
end
  
outETA   = ETA(n,func);

if isfield(data,'xopt') && s<=500
   ReoveryShow(data.xopt,outETA.x,[1000 250 500 250],1)
end 