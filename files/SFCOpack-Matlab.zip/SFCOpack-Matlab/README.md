# SNSCO
This Matlab package solves sample average approximation for chance constrained programming  based on the $0/1$ constrained optimization.

It was created based on the algorithm proposed by

*Shenglong Zhou, Lili Pan, Naihua Xiu, and Geoffrey Ye Li, 0/1 constrained optimization solving sample average approximation for chance constrained programming, [Math Oper Res](https://pubsonline.informs.org/doi/10.1287/moor.2023.0149), 2024.*

Please give credit to this paper if you use the code for your research.


