function [objef, gradf, hessf] = FuncfNOP(x,lambda)  
    % This code provides information for an objective function
    %     f(x) = (0.5*lambda)*||x||^2 - <1,x> 
    % x is the variable 
    % lambda is the parameter and needs to be input
    
    objef = (lambda/2)*norm(x)^2-sum(x); % objective
    if  nargout>1
        gradf = lambda*x-1;              % gradient
        hessf = lambda*eye(length(x));   % Hessian
    end
end
