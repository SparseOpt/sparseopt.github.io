function [G,gradG,gradGW, hessGW] = FuncGNOP(x,W,Ind,A,b,K,M,N)
    % This code provides information for function G(x): R^K -> R^{M x N}
    % (x,W,Ind) are variables
    % (A,b K,M,N) are parameters and need to be input 
    % For each i=1,...,M and j=1,...,N:
    %           G_{ij}(x) = 0.5 <A_{:,(j-1)*M+i}, x.*x> - b 
    % where A_{:,(j-1)*M+i} is the ((j-1)*M+i)th column of A
    % A \in R^{K x M*N} and b>0 is a scalar 
    
    G   = reshape((x.*x/2)'*A-b,M,N); 
    if  nargout > 1
        if  isempty(Ind) 
            gradG   = [];
            gradGW  = zeros(K,1); 
            hessGW  = zeros(K,1);
        else 
            AInd    = A(:,Ind);    
            gradG   = x.*AInd; 
            hessGW  = AInd*reshape(W(Ind),length(Ind),1);   
            gradGW  = x.*hessGW;  
            hessGW  = diag(hessGW); 
        end
    end  
    clear A b K M N
end

