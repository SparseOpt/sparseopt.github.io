function [objef, gradf, hessf] = FuncfRecovery(x,B,d,BtB)
    Bxd   = B*x-d;
    objef = norm(Bxd)^2/2;
    if  nargout>1
        gradf = (Bxd'*B)';
        hessf = BtB;  
    end
end
