function [G,gradG,gradGW, hessGW] = FuncGRecovery(x,W,Ind,A,c,K,M,N) 
    G0  = x'*A;
    G   = reshape(G0,M,N);
    G   = G.^2-c;
    if  nargout > 1
        if  isempty(Ind) 
            gradG   = [];
            gradGW  = zeros(K,1); 
            hessGW  = zeros(K,1);
        else 
            AInd    = A(:,Ind);    
            gradG   = AInd.*G0(Ind); 
            WInd    = W(Ind);
            gradGW  = gradG*reshape(WInd,length(Ind),1); 
            hessGW  = AInd*diag(WInd)*AInd.';   
        end
    end  
end

