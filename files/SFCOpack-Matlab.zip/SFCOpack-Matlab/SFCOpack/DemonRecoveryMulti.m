% demon recovery problems
clc; close all; clear all; warning off
addpath(genpath(pwd));

K     = 10; 
M     = 10; 
N     = 100;
alpha = 0.05;
s     = ceil(alpha*N);
sets  = {'Box','Ball','Halfspace','Hyperplane'};
test  = 1;  % Omega = [lb,ub]^n         if test = 1 
            % Omega = {x|norm(x) <= r}  if test = 2 
            % Omega = {x|a'*x <= b}     if test = 3 
            % Omega = {x|Ax = b}        if test = 4 
switch sets{test}
    case 'Box'
        input1  = -2;
        input2  = 2;
        xopt    = input1 + (input2-input1)*rand(K,1); 
    case 'Ball'
        input1  = 2;
        input2  = [];
        xopt    = randn(K,1);
        xopt    = input1/norm(xopt)*xopt;
    case 'Halfspace'
        xopt    = rand(K,1);
        input1  = randn(K,1);
        input2  = sum(input1.*xopt)+rand(1); 
    case 'Hyperplane'
        xopt    = randn(K,1);
        input1  = randn(ceil(0.5*K),K);
        input2  = input1*xopt; 
end

% Generate data
B           = randn(ceil(0.25*K),K)/sqrt(K);
d           = B*xopt;
BtB         = B'*B;
xi          = randn(K,M,N);
T           = randperm(N,s);
Mat         = rand(M,N);
Delta       = (Mat>=0.5) .* rand(M,N);
Delta(:,T)  = (Mat(:,T)<1/3).*rand(M,nnz(T))-(Mat(:,T)>=2/3).*rand(M,nnz(T)); 
A           = reshape(xi,K,M*N);
c           = (squeeze(sum(xi .* xopt, 1))).^2 + Delta;

Funcf      = @(x)FuncfRecovery(x,B,d,BtB);            % f(x)= \|Bx-d\|^2/2
FuncG      = @(x,W,J)FuncGRecovery(x,W,J,A,c,K,M,N);  % G(x)_ij = (<a_ij,x>)^2 <= c_ij

P          = 10;
if alpha   > 0.01
    pars.tau0  = logspace(log10(0.5),log10(1.75),P);
else
    pars.tau0  = logspace(log10(0.01),log10(0.1),P);
    pars.thd   = 1e-1*(test==4)+1e-2*(test~=4);
end
out  = SNSCO(K,M,N,s,Funcf,FuncG,sets{test},input1,input2,pars);

% Solving problem under the best tau
fprintf(' \n\n Solving the problem under the best tau = %.4f\n',out.tau)
fprintf(' -------------------------------------------------------\n')
pars.tau0  = out.tau; 
out  = SNSCO(K,M,N,s,Funcf,FuncG,sets{test},input1,input2,pars);
fprintf(' Relative error: %7.3e \n', norm(out.x-xopt)/norm(xopt));
    