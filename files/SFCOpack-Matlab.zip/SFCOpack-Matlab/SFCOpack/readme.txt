Please run "demonXXXX.m" to solve different problems 

This package offers 1 solver for sparse quadratically constrained quadratic programming  
based on the algorithm proposed in the following paper: 

SNSCO----------------------------------------------------------------------
    Shenglong Zhou, Lili Pan, Naihua Xiu, and Geoffrey Ye Li, 
    0/1 constrained optimization solving sample average approximation for chance constrained programming, 
    Math Oper Res, 2024.

 
Please credit it if you use the code for your research.

===========================================================================
function out = SNSCO(K,M,N,s,Funcf,FuncG,FeasSet,input1,input2,pars)
% This solver solves 0/1 constrained optimization in the following form:
%
%         min_{x\in\R^K} f(x),  s.t. \| G(x) \|^+_0<=s, x\in Omega 
%
% where 
%      f(x) : \R^K --> \R
%      G(x) : \R^K --> \R^{M-by-N}
%      s << N 
%      \|Z\|^+_0 counts the number of columns with positive maximal values
%      Omega is a closed and convex set
% =========================================================================
% Inputs:
%   K      : Dimnesion of variable x                             (REQUIRED)
%   M      : Row number of G(x)                                  (REQUIRED)
%   N      : Column number of G(x)                               (REQUIRED)
%   s      : An integer in [1,N), typical choice ceil(0.01*N)    (REQUIRED)
%   Funcf  : Function handle of f(x)                             (REQUIRED)
%   FuncG  : Function handle of G(x)                             (REQUIRED)
%   FeasSet: Feasible set for x, must be one of:                 (REQUIRED)
%            'Box'                [lb,ub]^K,
%            'Ball'               {x|norm(x) <= r}, 
%            'Halfspace',         {x|a'*x <= b},
%            'Hyperplane'.        {x|Ax = b},
%            default: R^n
%   input1 : A parameter related to FeasSet                      (REQUIRED)
%   input2 : A parameter related to FeasSet                      (REQUIRED)
%   pars   : All parameters are OPTIONAL  
%            pars.x0      -- Initial point (default:ones(K,1)) 
%            pars.tau0    -- A vector containing a number of parameter \tau (default:1)
%                            e.g., pars.tau0 =logspace(log10(0.5),log10(1.75),50);
%            pars.tol     -- Tolerance of the halting condition (default:1e-6*M*N)
%            pars.maxit   -- Maximum number of iterations (default: 2000) 
%            pars.display -- Display results or not for each iteration (default:1)
% =========================================================================
% Outputs:
%     out.x:      Solution x
%     out.obj:    Objective function value f(x)
%     out.G:      Function value of G(x) 
%     out.time:   CPU time
%     out.iter:   Number of iterations 
%     out.error:  Error
%     out.Error:  Error of every iteration
% =========================================================================
% Written by Shenglong Zhou on 30/04/2024 based on the algorithm proposed in
%     Shenglong Zhou, Lili Pan, Naihua Xiu, and Geoffrey Ye Li, 
%     0/1 constrained optimization solving sample average approximation 
%     for chance constrained programming, Math Oper Res, 2024    	
% Send your comments and suggestions to <<< slzhou2021@163.com >>>                                  
% WARNING: Accuracy may not be guaranteed!!!!!  
% =========================================================================
# Below is one example that you can run
# =========================================================================
# demon NOP problems
clc; close all; clear all; warning off
addpath(genpath(pwd));

K     = 10; 
M     = 10; 
N     = 100;
alpha = 0.05;
s     = ceil(alpha*N);

b     = 5;
c     = sqrt(2*b/chi2inv((1-s/N)^(1/M),K));
xi    = zeros(K,M,N);     

if  M  ==1  
    xi    = randn(K,M,N);         % iid data
else
    E     = repmat((1:K)'/K,1,M);
    C     = 0.5*ones(M,M)+0.5*eye(M); 
    for n = 1:N
        xi(:,:,n) = mvnrnd(E,C);  % non-iid data
    end 
end
lam        = 1/c/2; 
A          = reshape(xi.*xi,K,M*N);      
Funcf      = @(x)FuncfNOP(x,lam);
FuncG      = @(x,W,J)FuncGNOP(x,W,J,A,b,K,M,N); 
P          = 50-25*(alpha==0.01);    
pars.tau0  = 1; 
out        = SNSCO(K,M,N,s,Funcf,FuncG,'Box',0,Inf,pars);