# SROpack

This package offers 1 solver for sparsity regularized optimization problems  
based on the algorithm proposed in the following paper: 

## NL0R
    Shenglong Zhou, Lili Pan, and Naihua Xiu, 
    Newton method for l_0 regularized optimization,
    Numerical Algorithms, 88, 1541-1570, 2021

Please credit it if you use the code for your research.