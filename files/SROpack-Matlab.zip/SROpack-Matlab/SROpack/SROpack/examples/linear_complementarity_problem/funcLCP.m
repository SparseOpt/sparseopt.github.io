function out = funcLCP(x,key,T1,T2,data)
    
    if isfield(data,'r') 
        r   = data.r ;
    else
        r   = 2;
    end
    M   = data.A;
    Mt  = data.At;
    q   = data.b; 
    n   = length(q);   
    clear data; 
    
    eps =  0;
    ip  = find(x>eps);
    in  = find(x<-eps);
    ix  = union(ip,in); 
    Mx  = M(:,ix)*x(ix) + q;    
    tp  = find(Mx>eps);  
    tn  = find(Mx<-eps);  
    tt  = intersect(ip,tp); 
 
    if isempty(tt); com=0; else; com=1; end
    Mxn = abs(Mx(tn));     
    xn  = abs(x(in)); 
    
    switch key
        case 'f'         
            out =  (sum(xn.^r) + sum(Mxn.^r) )/r ;                 %objective function    
            if  com
                out =  out + sum( ( x(tt).* Mx(tt) ).^r )/r;  
            end
        case 'g'         
            out     = - Mt(:,tn)* ( Mxn.^(r-1) );
            out(in) = out(in) - xn.^(r-1) ; 
            if  com
                out     = out +  Mt(:,tt)*( x(tt).^r.*(Mx(tt).^(r-1)) ); 
                out(tt) = out(tt) + ( x(tt).^(r-1) ).*( Mx(tt).^r ); 
            end       
        case 'h'
            s1   = length(T1);
            mx   = max(x,0);       
            mMx  = max(Mx,0);

            if r~=2
                r1  = r-1; 
                r2  = r-2;          
                z2  = r1* ( Mxn.^r2 ) ;                
                if  com
                    z1 = r1* ( mx(tt).^r.*( mMx(tt).^r2 ) );    
                end
            else   
                tn0 = setdiff(1:n,tp);
                if  com
                    z1 = mx(tt).^r ; 
                end
            end  
            
            tem1 = r*( mx(T1).*mMx(T1) ).^(r-1);     
            if  isequal(T1, T2)
                if r  ~=  2              
                    MM = Mt(T1,tn)*( repmat(z2,1,s1).*M(tn,T1) );
                    xy = r1*( ( mx(T1).^r2 ).*( mMx(T1).^r ) + (abs(min(x(T1),0))).^r2 );
                else                  
                    MM = Mt(T1,tn0)*M(tn0,T1) ;
                    z  = ones(n,1);  z(ip) = mMx(ip).^2;  
                    xy = z(T1);
                end 
                if  com
                    MM = MM+ Mt(T1,tt)*( repmat(z1,1,s1).*M(tt,T1) );    
                end
                out    = repmat(tem1,1,s1).*M(T1,T1);
                out    = out + out' + MM;         
                out(1:(s1+1):end) = out(1:(s1+1):end) + xy';   % sub-Hessian indexed by T1 and T1  
            else
                s2     = length(T2) ;    
                if  r ~= 2
                    MM = Mt(T1,tn)*(repmat(z2,1,s2).*M(tn,T2));
                else
                    MM = Mt(T1,tn0)*M(tn0,T2);    
                end
                if  com
                    MM = MM + Mt(T1,tt)*(repmat(z1,1,s2).*M(tt,T2));   
                end    
                tem2   = r*( mx(T2).*mMx(T2) ).^(r-1);      
                out    = repmat(tem1,1,s2).*M(T1,T2) + Mt(T1,T2).*repmat(tem2',s1,1) + MM; % sub-Hessian indexed by T1 and T2 
            end
    end

    clear ip in tp tn MM M Mt;
end


