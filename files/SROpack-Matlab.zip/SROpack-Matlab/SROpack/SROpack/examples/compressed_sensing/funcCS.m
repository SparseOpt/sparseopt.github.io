function  out = funcCS(x,key,T1,T2,data)

if ~isa(data.A, 'function_handle') % A is a matrix 
    n = length(x);
    switch key
        case 'f'
            if  n  <= (4/3)*nnz(x) 
                Axb = data.A*x-data.b;
            else
                Tx  = find(x); 
                Axb = data.A(:,Tx)*x(Tx)-data.b;
            end
            out     = (Axb'*Axb)/2;                % objective 
        case 'g'
            if  n  <= (4/3)*nnz(x) 
                Axb = data.A*x-data.b;
            else
                Tx  = find(x); 
                Axb = data.A(:,Tx)*x(Tx)-data.b;
            end
            fAt     = @(var)(var'*data.A)';
            out     = fAt(Axb);                    % gradient  
        case 'h'        
            if  n  <= 5e3 && max(length(T1),length(T2))<=1e3 
                out = data.A(:,T1)'*data.A(:,T2);  % sub-Hessian indexed by T1 and T2
            else
                out = @(var)((data.A(:,T2)*var)'*data.A(:,T1))';  
            end         
    end
else  % A is a function handle A*x=A(x)  
    if ~isfield(data,'At') 
        disp('The transpose-data.At-is missing'); return; 
    end
    if ~isfield(data,'n')  
        disp('The dimension-data.n-is missing');  return;  
    end   
    switch key
        case 'f'
            Axb  = data.A(x)-data.b;
            out = (Axb'*Axb)/2;              % objective 
       case 'g'
            Axb  = data.A(x)-data.b;
            out  = data.At(Axb);             % gradient
        case 'h'
            func = fgH(data);    
            out = @(var)func(var,T1,T2);     % sub-Hessian indexed by T1 and T2     
    end
end

clear data Axb

end

function Hess = fgH(data)
    suppz     = @(z,t)supp(data.n,z,t);
    sub       = @(z,t)z(t,:);
    Hess      = @(z,t1,t2)(sub( data.At( data.A(suppz(z,t2))),t1)); 
end

function z = supp(n,x,T)
    z      = zeros(n,1);
    z(T)   = x;
end



