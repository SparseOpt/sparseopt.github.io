import numpy as np
import matplotlib.pyplot as plt

def plot2D(Atr, ctr, x, text, acc, ax=None, title_suffix="", pos=None):
    r"""
    Plot 2D classification results.

    Parameters:
        Atr          -- Sample matrix
        ctr          -- Labels {-1,1}
        x            -- Classifier weight vector (including bias)
        text         -- Classifier name
        acc          -- Classification accuracy
        ax           -- matplotlib.axes object (if None, create new figure)
        title_suffix -- Title suffix
        pos          -- MATLAB-style [left, bottom, width, height] for window position
    """
    if ax is None:
        if pos is not None and len(pos) == 4:
            fig = plt.figure(figsize=(pos[2] / 100, pos[3] / 100), dpi=100)
            try:
                mngr = plt.get_current_fig_manager()
                mngr.window.wm_geometry(f"+{pos[0]}+{pos[1]}")
            except Exception:
                pass
            ax = fig.add_subplot(111)
        else:
            fig, ax = plt.subplots(figsize=(5, 5))

    siz = 50
    at1 = Atr[ctr == 1, :]
    at2 = Atr[ctr == -1, :]
    x0  = np.array([-2, 2])
    y0  = 2.5 * x0

    ax.scatter(at1[:, 0], at1[:, 1], siz, marker="+", c="m", linewidths=1.5, label="Positive")
    ax.scatter(at2[:, 0], at2[:, 1], siz, marker="x", c="b", linewidths=1.5, label="Negative")
    ax.plot(x0, y0, "k:", linewidth=1.5, label="Bayes")
    ax.grid(True)
    ax.set_xlim(-2, 2)
    ax.set_ylim(min([at1[:, 1].min(), at2[:, 1].min()]),
                max([at1[:, 1].max(), at2[:, 1].max()]))

    if x is not None:
        y_line = -x[0] / x[1] * x0 - x[2] / x[1]
        ax.plot(x0, y_line, "g-", linewidth=1.5, label=text)
        ax.legend(loc="best")
        ax.set_title(f"Accuracy: {acc * 100:.2f}% {title_suffix}")

    for spine in ax.spines.values():
        spine.set_visible(True)