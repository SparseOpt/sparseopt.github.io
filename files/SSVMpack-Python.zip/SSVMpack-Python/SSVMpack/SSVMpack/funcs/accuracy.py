import numpy as np
from typing import Any
from numpy import ndarray, dtype

def accuracy(X: np.ndarray, w: np.ndarray, y: np.ndarray) -> tuple[float, float, ndarray[Any, dtype[Any]]] | tuple[
    float | Any, int, Any]:

    X = np.asarray(X)
    if X.size == 0:
        return float('nan'), float('nan'), np.array(float('nan'))

    w                 = np.asarray(w).ravel()
    y                 = np.asarray(y).ravel()
    z                 = X @ w[:-1] + w[-1]
    sz                = np.sign(z)
    sz[sz == 0]       = 1.0
    y_std             = np.sign(y)
    y_std[y_std == 0] = 1.0

    mis = int(np.count_nonzero(sz - y_std))
    acc = 1.0 - mis / y_std.size
    return acc, mis, sz