import numpy as np

def randomData(data_type: str, m: int, n: int, r: float):
    """
    This file aims at generating data of 3 examples

    Inputs:
          type    -- can be '2D','3D' or 'nD'
          m       -- number of samples
          n       -- number of features
          r       -- flipping ratio

    Outputs:
          Atr     -- training samples data,    m/2-by-n
          ctr     -- training samples classes, n-by-1
          Ate     -- testing  samples data,    m/2-by-n
          cte     -- testing  samples classes, n-by-1

    written by Shenglong Zhou, 10/05/2020
    """
    m2  = int(np.ceil(m / 2))
    rng = np.random

    if data_type == '2D':
        A_top = np.column_stack([
            0.5 + np.sqrt(0.5) * rng.standard_normal(m2),
            -3.0 + np.sqrt(3.0) * rng.standard_normal(m2),
        ])
        A_bottom = np.column_stack([
            -0.5 + np.sqrt(0.5) * rng.standard_normal(m2),
            3.0 + np.sqrt(3.0) * rng.standard_normal(m2),
        ])
        A = np.vstack([A_top, A_bottom])
        c = np.concatenate([-np.ones(m2), np.ones(m2)])

    elif data_type == '3D':
        rho   = 0.5 + 0.03 * rng.standard_normal(m2)
        t     = 2 * np.pi * rng.random(m2)
        data1 = np.column_stack([rho * np.cos(t), rho * np.sin(t), rho * rho])

        rho   = 0.5 + 0.03 * rng.standard_normal(m2)
        t     = 2 * np.pi * rng.random(m2)
        data2 = np.column_stack([rho * np.cos(t), rho * np.sin(t), -rho * rho])

        A     = np.vstack([data1, data2])
        c     = np.concatenate([np.ones(m2), -np.ones(m2)])

    elif data_type == 'nD':
        c         = np.ones(m)
        I         = rng.permutation(m)[:m2]
        c[I]      = -1.0
        row_scale = (c * rng.random(m))[:, None]  # (m,1)
        A         = row_scale.repeat(n, axis=1) + rng.standard_normal((m, n))
    else:
        raise ValueError("data_type must be one of {'2D','3D','nD'}")

    T   = rng.permutation(m)
    Atr = A[T[:m2], :]
    ctr = c[T[:m2]].copy()
    Ate = A[T[m2:], :]
    cte = c[T[m2:]].copy()

    ctr = _filp(ctr, r, rng)

    return Atr, ctr, Ate, cte


def _filp(fc: np.ndarray, r: float, rng: np.random.Generator) -> np.ndarray:
    r"""
    Flip the sign of approximately r*len(fc) elements in vector fc (in-place copy version).
    Consistent with MATLAB's filp function semantics: only flips when r > 0.
    """
    fc = fc.copy()
    if r > 0:
        mc = fc.size
        k  = int(np.ceil(r * mc))
        if k > 0:
            idx = rng.permutation(mc)[:k]
            fc[idx] = -fc[idx]
    return fc