from __future__ import annotations
from typing import Dict, Optional
import numpy as np
from .solvers.NSSVM import NSSVM
from .solvers.NM01 import NM01



def SSVMpack(A, y, solver: str, pars: Optional[Dict] = None) -> Dict:
    r"""
    This package aims to solve the binary classification problems
    Inputs ---------------------------------------------------------------------
     A     :  The sample matrix \in R^{m-by-n},                       (REQUIRED)
     y     :  The binary label \in R^m, b_i\in{-1,1}                  (REQUIRED)
     solver:  A text string, can be one of {'NM01','NSSVM'}           (REQUIRED)
     pars  :  Parameters are optional                                 (OPTIONAL)
              -------------  For NSSVM -----------------------------------------
              pars['alpha'] --  Starting point in \R^m      (default zeros(m,1))
              pars['s0']    --  The initial sparsity    (default n(log(m/n))^2))
              pars['C']     --  A positive scalar in (0,1]        (default  1/4)
              pars['c']     --  A positive scalar in (0,1]        (default 1/40)
              pars['tune']  --  Tune the sparsity level
                                Do not tune the sparsity level       (default 0)
              pars['maxit'] --  Maximum number of iterations      (default 1000)
              pars['tol']   --  Tolerance of the halting criteria (default 1e-4)
              pars['disp']  --  Display results for each step        (default 1)
                                Do not display results for each step
              ------------- For NM01 -------------------------------------------
              pars['x0']    --  The initial point           (default zeros(n,1))
              pars['C']     --  The penalty parameter                (default 1)
              pars['tau']   --  A useful parameter                   (default 5)
              pars['maxit'] --  Maximum number of iterations      (default 1000)
              pars['tol']   --  Tolerance of the halting criteria (default 1e-4)
              pars['disp']  --  Display results for each step        (default 1)
                                Do not display results for each step
    Outputs --------------------------------------------------------------------
        out['w']   :   The solution of the primal problem, i.e., the classifier
        out['sv']  :   Number of support vectors
        out['time']:   CPU time
        out['iter']:   Number of iterations
        out['acc'] :   Classification accuracy
    """
    if pars is None:
        pars = {}
    else:
        pars = dict(pars)

    y             = np.asarray(y).ravel()
    uniq          = np.unique(y)
    if not np.all(np.isin(uniq, [-1, 1])):
        y         = np.sign(y)
        y[y == 0] = 1.0

    m, n = A.shape if hasattr(A, "shape") else (len(y), None)
    if m is not None and n is not None and m < 0.1 * n and solver.upper() != "NM01":
        solver = "NM01"

    solver     = solver.upper()
    if solver not in {"NSSVM", "NM01"}:
        raise ValueError("solver must be 'NSSVM' or 'NM01'。")

    if solver == "NSSVM":
        out = NSSVM(A, y, pars)

    else:  # "NM01"
        if "C" in pars and "lam" not in pars:
            pars["lam"] = max(0.1, float(pars["C"]))
        out = NM01(A, y, pars)

    return out