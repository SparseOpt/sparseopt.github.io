from .SSVMpack import SSVMpack
from .solvers.NM01 import NM01 
from .solvers.NSSVM import NSSVM
from .funcs.accuracy import accuracy
from .funcs.normalization import normalization
from .funcs.randomData import randomData
from .funcs.plot2D import plot2D

__add__ = ["SSVMpack", "NM01", "NSSVM", "accuracy", "normalization", "randomData", "plot2D"]