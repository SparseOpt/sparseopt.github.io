import numpy as np
import time
from scipy.sparse import issparse, spdiags, eye as sparse_eye
from scipy.optimize import fmin


def NSSVM(A, y, pars=None):
    r"""
    Inputs -------------------------------------------------------------------
        A   : The sample data in R^(m-by-n)                         (REQUIRED)
        y   : The classes of the sample data in R^m                 (REQUIRED)
              y_i in {+1,-1}, i=1,2,...,m             
        pars: Parameters are all optional                           (OPTIONAL)
              pars['alpha'] --  Starting point in R^m
                                Default value = zeros(m,1)
              pars['s0']    --  The initial sparsity level in [1,m]
                                Default value = n(log(m/n))^2)
              pars['C']     --  A positive scalar in (0,1]
                                Default value = 1/4
              pars['c']     --  A positive scalar in (0,1]
                                Default value = 1/8
              pars['disp']  --  Display or not display results for each step
                                Default value = 1 (display)
              pars['tune']  --  Tune or not tune the sparsity level
                                Default value = 0 (not tune)
              pars['maxit'] --  Maximum number of iterations
                                Default value = 2000
              pars['tol']   --  Tolerance of the halting condition
                                Default value = 1e-6*sqrt(n*m)
    Outputs ------------------------------------------------------------------
        out['alpha']:  The sparse solution alpha
        out['w']    :  The solution of the primal problem, i.e., the classifier
        out['s']    :  Sparsity level of the solution, i.e., nnz(out['alpha'])
        out['sv']   :  Number of support vectors
        out['time'] :  CPU time
        out['iter'] :  Number of iterations
        out['acc']  :  Classification accuracy
    """
    t0 = time.perf_counter()
    if pars is None:
        pars = {}

    A    = np.asarray(A, dtype=float) if not issparse(A) else A
    y    = np.asarray(y, dtype=float).ravel()
    m, n = A.shape if not issparse(A) else A.shape

    if issparse(A) and (A.nnz / (m * n)) > 0.1:
        A      = A.toarray()
    if n < 3e4:
        Qt     = y[:, None] * A
    else:
        diag_y = spdiags(y, 0, m, m)
        Qt     = diag_y.dot(A)
    Q = Qt.T

    Fnorm = lambda var: np.sum(var * var) if not issparse(var) else var.power(2).sum()

    maxit, alpha, tune, disp_flag, tol, eta, s0, C, c = GetParameters(m, n, pars)

    T1       = np.flatnonzero(y == 1.0)
    T2       = np.flatnonzero(y == -1.0)
    nT1, nT2 = T1.size, T2.size
    s        = int(s0)

    if nT1 < s:
        T    = np.concatenate([T1, T2[:(s - nT1)]])
    elif nT2 < s:
        T    = np.concatenate([T1[:(s - nT2)], T2])
    else:
        T    = np.concatenate([T1[:int(np.ceil(s / 2))], T2[:(s - int(np.ceil(s / 2)))]])
    T = np.sort(T[:s])

    b      = 1.0 if nT1 >= nT2 else -1.0
    bb     = b
    w      = np.zeros(n, dtype=float)
    gz     = -np.ones(m, dtype=float)
    ERR    = np.zeros(maxit, dtype=float)
    ACC    = np.zeros(maxit + 2, dtype=float)
    ACC[1] = 1.0 - np.count_nonzero(np.sign(b) - y) / m
    ET     = np.ones(s, dtype=float) / C

    maxACC = 0.0
    flag   = 1
    j      = 1
    r      = 1.1
    count  = 1
    count0 = 2
    iter0  = -1

    if disp_flag:
        print("\n Start to run the solver -- NSSVM")
        print(" ------------------------------------------")
        print("  Iter          Accuracy          CPUTime ")
        print(" ------------------------------------------")

    for iter_idx in range(1, maxit + 1):
        if iter_idx == 1 or flag:
            QT  = Q[:, T] if not issparse(Q) else Q[:, T].toarray()
            QtT = Qt[T, :] if not issparse(Qt) else Qt[T, :].toarray()
            yT  = y[T]
            ytT = yT.T

        alphaT = alpha[T] if alpha.size > 0 else np.zeros(s, dtype=float)
        gzT    = -gz[T]
        alyT   = -np.dot(ytT, alphaT)

        alpha_norm        = Fnorm(alpha) if alpha.size > 0 else 0.0
        err               = (abs(alpha_norm - Fnorm(alphaT)) + Fnorm(gzT) + alyT ** 2) / (m * n)
        ERR[iter_idx - 1] = np.sqrt(err)

        if tune and iter_idx < 30 and m <= 1e8:
            stop1 = (iter_idx > 5) and (err < tol * s * np.log2(m) / 100.0)
            stop2 = (s != s0) and (abs(ACC[iter_idx] - np.max(ACC[1:iter_idx])) <= 1e-4)
            stop3 = (s != s0) and (iter_idx > 10) and (np.max(ACC[iter_idx - 5:iter_idx + 1]) < maxACC)
            stop4 = (count != count0 + 1) and (ACC[iter_idx] >= ACC[1])
            stop  = stop1 and (stop2 or stop3) and stop4
        else:
            stop1 = err < tol * np.sqrt(s) * np.log10(m)
            stop2 = (iter_idx > 4) and (np.std(ACC[iter_idx - 1:iter_idx + 1]) < 1e-4)
            stop3 = (iter_idx > 20) and (abs(np.max(ACC[max(1, iter_idx - 8):iter_idx + 1]) - maxACC) <= 1e-4)
            stop  = (stop1 and stop2) or stop3

        if disp_flag:
            cpu_time = time.perf_counter() - t0
            print(f"  {iter_idx:3d}          {ACC[iter_idx]:8.5f}          {cpu_time:.3f}sec")

        if ACC[iter_idx] > 0 and (ACC[iter_idx] >= 0.99999 or stop):
            break

        ET0 = ET.copy()
        ET  = np.where(alphaT >= 0, 1.0 / C, 1.0 / c)

        if min(n, s) > 1e3:
            b_cg = np.concatenate([gzT, np.array([alyT], dtype=float)])
            d    = my_cg(QT, yT, ET, b_cg, 1e-10, 50, np.zeros(s + 1, dtype=float))
            dT   = d[:s]
            dend = d[-1]
        else:
            if s <= n:
                if iter_idx == 1 or flag:
                    PTT0  = np.dot(QtT, QT)
                PTT       = PTT0 + np.diag(ET)
                K         = np.zeros((s + 1, s + 1), dtype=float)
                K[:s, :s] = PTT
                K[:s, -1] = yT
                K[-1, :s] = ytT
                rhs       = np.concatenate([gzT, np.array([alyT], dtype=float)])
                d         = np.linalg.solve(K, rhs)  # Solve linear system
                dT        = d[:s]
                dend      = d[-1]
            else:
                ETinv = 1.0 / ET
                flag1 = np.count_nonzero(ET0) != np.count_nonzero(ET)
                flag2 = (np.count_nonzero(ET0) == np.count_nonzero(ET)) and (np.count_nonzero(ET0 - ET) == 0)

                if iter_idx == 1 or flag or flag1 or not flag2:
                    EQtT = np.dot(np.diag(ETinv), QtT)
                    P0   = sparse_eye(n).toarray() if n > 1e3 else np.eye(n)
                    P0  += np.dot(QT, EQtT)

                Ey           = ETinv * yT
                QT_Ey        = np.dot(QT, Ey)
                P0_inv_QT_Ey = np.linalg.solve(P0, QT_Ey)
                Hy           = Ey - np.dot(EQtT, P0_inv_QT_Ey)
                denom        = np.dot(ytT, Hy)
                dend         = (np.dot(gzT, Hy) - alyT) / denom if denom != 0 else 0.0

                tem           = ETinv * (gzT - dend * yT)
                QT_tem        = np.dot(QT, tem)
                P0_inv_QT_tem = np.linalg.solve(P0, QT_tem)
                dT            = tem - np.dot(EQtT, P0_inv_QT_tem)

        alpha    = np.zeros(m, dtype=float)
        alphaT  += dT
        alpha[T] = alphaT
        b       += dend

        w   = np.dot(QT, alphaT)
        Qtw = np.dot(Qt, w) if not issparse(Qt) else Qt.dot(w).toarray().ravel()
        tmp = y * Qtw

        gz    = Qtw - 1.0 + b * y
        ET1   = np.where(alphaT >= 0, 1.0 / C, 1.0 / c)
        gz[T] = alphaT * ET1 + gz[T]

        j      = iter_idx + 1
        ACC[j] = 1.0 - np.count_nonzero(np.sign(tmp + b) - y) / m

        if m <= 1e7:
            bb         = np.mean(yT - tmp[T])
            ACCb       = 1.0 - np.count_nonzero(np.sign(tmp + bb) - y) / m
            if ACC[j] >= ACCb:
                bb     = b
            else:
                ACC[j] = ACCb

        if m < 6e6 and ACC[j] < 0.5:
            def obj_fun(t):
                return np.sum((np.sign(tmp + t) - y) ** 2)

            opt  = {'maxiter': 10 if m >= 1e6 else 20, 'disp': 0}
            b0   = fmin(obj_fun, bb, **opt)
            b0   = b0[0] if isinstance(b0, np.ndarray) else b0
            acc0 = 1.0 - np.count_nonzero(np.sign(tmp + b0) - y) / m
            if ACC[j] < acc0:
                bb     = b0
                ACC[j] = acc0

        if ACC[j] >= maxACC:
            maxACC = ACC[j]
            alpha0 = alpha.copy()
            tmp0   = tmp.copy()
            maxwb  = np.concatenate([w, np.array([bb], dtype=float)])

        T0   = T.copy()
        mark = 0
        if tune and (err < tol or (iter_idx % 10 == 0)) and (iter_idx > iter0 + 2) and (count < 10):
            count0 = count
            count  = count + 1
            s      = min(m, int(np.ceil(r * s)))
            iter0  = iter_idx
            count_thresh = (1 if (m >= 1e6 or n < 3) else 0) + (1 if (m < 1e6 and n >= 5) else 0)
            if count > count_thresh:
                alpha = np.zeros(m, dtype=float)
                gz    = -np.ones(m, dtype=float)
                mark  = 1
        else:
            count0    = count

        if s != m:
            scores = np.abs(alpha - eta * gz)
            if m < 5e8:
                sorted_indices = np.argsort(-scores)
                T = sorted_indices[:s]
            else:

                sorted_scores, sorted_indices = np.sort(scores)[::-1], np.argsort(-scores)
                T = sorted_indices[:s]
            T = np.sort(T[:s])

            if mark:
                nT = np.count_nonzero(y[T] == 1.0)
                if nT == s:
                    if nT2 <= 0.75 * s:
                        T = np.concatenate([T[:s - int(np.ceil(nT2 / 2))], T2[:int(np.ceil(nT2 / 2))]])
                    else:
                        T = np.concatenate([T[:int(np.ceil(s / 4))], T2[:s - int(np.ceil(s / 4))]])
                elif nT == 0:
                    if nT1 <= 0.75 * s:
                        T = np.concatenate([T[:s - int(np.ceil(nT1 / 2))], T1[:int(np.ceil(nT1 / 2))]])
                    else:
                        T = np.concatenate([T[:int(np.ceil(s / 4))], T1[:s - int(np.ceil(s / 4))]])
                T = np.sort(T[:s])
        else:
            T = np.arange(m, dtype=int)

        flag  = 1
        flag3 = (T0.size == s)
        if flag3:
            flag3 = (np.count_nonzero(T - T0) == 0)
        if flag3 or (T0.size == m):
            flag  = 0
            T     = T0

    wb  = np.concatenate([w, np.array([bb], dtype=float)])
    acc = ACC[j]

    if m <= 1e7 and iter_idx > 1:
        def obj_fun_final(t):
            return np.linalg.norm(np.sign(tmp0 + t) - y)

        opt  = {'maxiter': 20, 'disp': 0}
        b0   = fmin(obj_fun_final, maxwb[-1], **opt)
        b0   = b0[0] if isinstance(b0, np.ndarray) else b0
        acc0 = 1.0 - np.count_nonzero(np.sign(tmp0 + b0) - y) / m
        if acc < acc0:
            wb  = np.concatenate([maxwb[:-1], np.array([b0], dtype=float)])
            acc = acc0

    if acc < maxACC - 1e-4:
        alpha = alpha0
        wb    = maxwb
        acc   = maxACC

    if disp_flag:
        print(" ------------------------------------------")

    Out = {
        's': int(s),
        'w': wb,
        'sv': int(s),
        'ACC': float(acc),
        'iter': int(iter_idx),
        'time': float(time.perf_counter() - t0),
        'alpha': alpha
    }

    return Out


def GetParameters(m, n, pars):
    """
    Initial parameters for NSSVM (consistent with MATLAB's GetParameters)
    """
    maxit = int(1e3)
    alpha = np.zeros(m, dtype=float)
    tune  = 0
    disp  = 1
    tol   = 1e-6
    eta   = min(1.0 / m, 1e-4)
    beta  = 1.0

    if max(m, n) < 1e4:
        beta = 1.0
    elif m <= 5e5:
        beta = 0.05
    elif m <= 1e8:
        beta = 10.0

    ratio = np.maximum(m / np.maximum(n, 1e-12), 1e-12)
    s0    = int(np.ceil(beta * n * (np.log2(ratio)) ** 2))
    C     = np.log10(m) if m > 5e6 else 0.5

    if 'maxit' in pars:
        maxit = int(pars['maxit'])
    if 'alpha' in pars:
        alpha = np.asarray(pars['alpha'], dtype=float).ravel()
    if 'disp' in pars:
        disp  = int(pars['disp'])
    if 'tune' in pars:
        tune  = int(pars['tune'])
    if 'tol' in pars:
        tol   = float(pars['tol'])
    if 'eta' in pars:
        eta   = float(pars['eta'])
    if 's0' in pars:
        s0    = int(min(m, pars['s0']))
    if 'C' in pars:
        C     = float(pars['C'])

    c = 0.01 * C

    return maxit, alpha, tune, disp, tol, eta, s0, C, c


def my_cg(Q, y, E, b, cgtol, cgit, x):
    """
    Conjugate gradient method for solving block-structured system:
        [Q^T Q + diag(E), y; y^T, 0] * [dT; dend] = [bT; b_end]
    Consistent with MATLAB's my_cg function
    """
    r = b.copy()
    e = np.sum(r * r)
    t = e

    for i in range(1, int(cgit) + 1):
        if e < cgtol * t:
            break
        if i == 1:
            p = r.copy()
        else:
            p = r + (e / e0) * p

        p1  = p[:-1]
        p2  = p[-1]
        Qp  = np.dot(Q, p1)
        top = np.dot(Q.T, Qp) + E * p1 + p2 * y
        bot = np.sum(y * p1)
        w   = np.concatenate([top, np.array([bot], dtype=float)])

        a   = e / np.sum(p * w)
        x   = x + a * p

        r   = r - a * w
        e0  = e
        e   = np.sum(r * r)

    return x
