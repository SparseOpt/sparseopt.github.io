from __future__ import annotations
import time
from typing import Dict, Optional, Tuple, Callable
import numpy as np

try:
    import scipy.sparse as sp
except Exception:
    sp = None

Array = np.ndarray

def NM01(A: Array, y: Array, pars: Optional[Dict] = None) -> Dict:
    """
    Inputs ---------------------------------------------------------------------------------
    A    : (m, n0) ndarray or scipy sparse: Sample matrix (without bias column)   (REQUIRED)
    y    : (m,1) ndarray: Labels in {+1, -1}                                      (REQUIRED)
    pars : Parameters are all optional                                            (OPTIONAL)
           pars['x0']     --  initial x (default zeros(n0+1,1))
           pars['lam']    --  penalty parameter (default via initial lam)
           pars['tau']    --  smoothing parameter (default 5)
           pars['maxit']  --  max iterations (default 1000)
           pars['tol']    --  not used directly
           pars['acc']    --  target accuracy (default 1)

    Outputs -----------------------------------------------------------------------------
           out['w']    -- solution x (n0+1 dimensions including bias)
           out['z']    -- dual-like variable
           out['obj']  -- ||D x||^2
           out['time'] -- CPU time (sec)
           out['Acc']  -- best accuracy achieved
           out['sv']   -- number of "support vectors" |T|
           out['iter'] -- iterations performed
    """
    t0   = time.perf_counter()
    pars = {} if pars is None else dict(pars)

    if sp is not None and sp.issparse(A):
        m, n0       = A.shape
        A_is_sparse = True
    else:
        A           = np.asarray(A, dtype=np.float64, order='C')
        m, n0       = A.shape
        A_is_sparse = False
    y = np.asarray(y, dtype=np.float64).ravel()
    if y.size != m:
        raise ValueError("Length of y must equal number of rows in A (m).")

    ny       = -y
    ones_col = np.ones((m, 1), dtype=np.float64)
    if not A_is_sparse:
        Any  = np.hstack((A, ones_col))
        Any *= ny[:, None]
    else:
        if sp is None:
            raise RuntimeError("scipy.sparse required to handle sparse A.")
        Dny      = sp.diags(ny, 0, shape=(m, m), dtype=np.float64)
        Any_left = (Dny @ A).tocsr()
        Any      = sp.hstack([Any_left, ny[:, None]], format='csr')

    n = n0 + 1
    maxit, tau, w, mu, disp, acc0, x, cgtol = get_parameters(m, n, pars)

    # ---------- Initialization ----------
    z   = np.ones(m, dtype=np.float64)
    ACC = np.zeros(maxit, dtype=np.float64)

    # Ax = Any @ x + 1 or initialize as ones
    if np.dot(x, x) == 0.0:
        Ax = np.ones(m, dtype=np.float64)
    else:
        Ax = A_times_x(Any, x) + 1.0

    H      = np.ones(n, dtype=np.float64)
    H[-1]  = w
    H1     = np.ones(n, dtype=np.float64)
    H1[-1] = 1.0 / max(w, 1e-18)

    Axz = Ax + tau * z
    lam = float(pars['lam']) if ('lam' in pars) else initial_lambda(m, n, Axz, tau)

    if A_is_sparse:
        sp_ratio = Any.nnz / (m * n)
        if (sp_ratio > 0.2 and n < 100) or (sp_ratio > 0.4):
            Any         = Any.toarray(order='C')
            A_is_sparse = False

    maxAcc  = 0.0
    maxx    = x.copy()
    maxiter = 0
    last_T  = np.array([], dtype=int)

    if disp:
        print("\n Start to run the solver -- NM01")
        print(" ------------------------------------------")
        print("  Iter          Accuracy          CPUTime ")
        print(" ------------------------------------------")

    for iter_k in range(1, maxit + 1):
        T, empT, lam = Ttau(Axz=Axz, Ax=Ax, tau=tau, lam=lam)

        # Gradient g = [x1, ..., x_{n-1}, w x_n]
        g     = x.copy()
        g[-1] = w * x[-1]

        # raw for stopping criterion
        if empT:
            raw = 0.0
        else:
            P     = row_select(Any, T)  # (|T|, n)
            zJ    = z[T]                 # (|T|,)
            tmp1  = g + (P.T @ zJ)       # (n,)
            tmp2  = Ax[T]                # (|T|,)
            raw   = float(np.dot(tmp2, tmp2)) / m

        # Calculate classification accuracy
        sb        = np.sign(ny * (Ax - 1.0))
        sb[sb==0] = -1.0
        acc       = 1.0 - (np.count_nonzero(sb + ny) / m)

        x0 = x
        if (iter_k > 1) and (acc < min(0.5, ACC[iter_k - 2])):
            acc = 1.0 - acc
            x0  = -x

        ACC[iter_k - 1] = acc
        if acc >= maxAcc:
            maxAcc  = acc
            maxx    = x0.copy()
            maxiter = iter_k

        if disp:
            print(f"  {iter_k:3d}          {acc:8.5f}          {time.perf_counter() - t0:6.3f}sec")

        stop1 = (iter_k > 4) and (abs(acc - ACC[iter_k - 2]) <= 5e-5)
        stop2 = (raw < 1e-1) and (maxiter < iter_k - 4)
        stop3 = (raw < 1e-8) and (acc > 0.5) and (iter_k > 4)
        if stop1 or (acc >= acc0 - 1e-5) or stop2 or stop3:
            last_T = T
            break

        # Calculate step (u,v)
        if empT:
            u   = -g
            v   = -z
        else:
            rhs = -(mu * tmp1 + (P.T @ tmp2))

            nT = T.size
            if (n > 5e3) or ((m <= n) and (n > 2e3)):
                if m > 1e3:
                    def fx_u(vv: Array) -> Array:
                        return (P.T @ (P @ vv)) + mu * (H * vv)

                    u    = my_cg(fx_u, rhs, cgtol=cgtol, cgit=25, x0=np.zeros(n))
                    v    = -z
                    v_T  = (tmp2 + P @ u) / mu
                    v[T] = v_T
                else:
                    if A_is_sparse and (nT > 500):
                        def fx_vT(vv: Array) -> Array:
                            return P @ (H1 * (P.T @ vv)) + mu * vv
                        vT = my_cg(fx_vT, (tmp2 - P @ (H1 * tmp1)), cgtol=cgtol, cgit=25, x0=np.zeros(nT))
                    else:
                        D  = P @ (H1 * P.T)
                        if sp is not None and sp.issparse(D):
                            D = D.toarray()
                        D[np.diag_indices_from(D)] += mu
                        vT = np.linalg.solve(D, (tmp2 - P @ (H1 * tmp1)))

                    v     = -z
                    v[T]  = vT
                    u     = -(H1 * (tmp1 + (P.T @ vT)))
            else:
                if (A_is_sparse and (n > 501)) or (n > 2e3):
                    def fx_u(vv: Array) -> Array:
                        return (P.T @ (P @ vv)) + mu * (H * vv)

                    u = my_cg(fx_u, rhs, cgtol=cgtol, cgit=25, x0=np.zeros(n))
                else:
                    D = P.T @ P
                    if sp is not None and sp.issparse(D):
                        D = D.toarray()
                    D[np.diag_indices_from(D)] += mu * H
                    u                           = np.linalg.solve(D, rhs)
                v    = -z
                v[T] = (tmp2 + P @ u) / mu

        x  += u
        z  += v
        Ax  = A_times_x(Any, x) + 1.0

        if (iter_k % 5) == 0:
            mu   = max(1e-10, mu / 2.0)
            tau  = max(1e-4, tau / 1.5)
            lam *= 1.1

        Axz    = Ax + tau * z
        last_T = T

    if disp:
        print(" ------------------------------------------")

    x   = maxx
    out = {
        'w'   : x,
        'z'   : z,
        'obj' : float(np.dot(H * x, x)),
        'time': time.perf_counter() - t0,
        'Acc' : float(maxAcc),
        'sv'  : int(last_T.size),
        'iter': int(iter_k),
    }
    return out

def A_times_x(Any, x: Array) -> Array:
    """Compute Any @ x, compatible with sparse/dense."""
    if sp is not None and sp.issparse(Any):
        return Any @ x
    else:
        return Any.dot(x) if hasattr(Any, "dot") else Any @ x


def get_parameters(m: int, n: int, pars: Dict) -> Tuple[int, float, float, float, int, float, Array, float]:
    maxit = int(pars.get('maxit', 1000))
    w     = float(pars.get('w', 1e-8))
    disp  = int(pars.get('disp', 1))
    acc0  = float(pars.get('acc', 1.0))
    tau   = float(pars.get('tau', 5.0))
    mn    = max(m, n)
    if mn < 500:
        mu = 0.001
    else:
        mu = 0.01 if (m < n) else 10.0
    x0 = np.asarray(pars.get('x0', np.zeros(n, dtype=np.float64)), dtype=np.float64)
    if x0.size != n:
        raise ValueError("pars['x0'] dimension must equal n = A.shape[1] + 1")
    cgtol = 1e-10 * np.sqrt(float(mn))
    return maxit, tau, w, mu, disp, acc0, x0, cgtol


def Ttau(Axz: Array, Ax: Array, tau: float, lam: float) -> Tuple[np.ndarray, bool, float]:
    """
    Select index set T (threshold interval near tl), and adapt tau/lam when empty (consistent with MATLAB)
    """
    tl = np.sqrt(tau * lam / 2.0)
    # T = find(abs(Axz - tl) < tl)
    T    = np.where(np.abs(Axz - tl) < tl)[0]
    empT = (T.size == 0)
    if empT:
        zp = Ax[Ax >= 0.0]
        if zp.size > 0:
            s = int(np.ceil(0.01 * zp.size))
            s_idx = min(max(s - 1, 0), zp.size - 1)
            tau   = (zp[s_idx] ** 2) / (2.0 * lam)
            tl    = np.sqrt(tau * lam / 2.0)
            T     = np.where(np.abs(Ax - tl) < tl)[0]
            empT  = (T.size == 0)
    return T.astype(int), empT, lam


def initial_lambda(m: int, n: int, z: Array, tau: float) -> float:
    """
    Initial lam: take the s-th smallest of z>0 (s = min(m, 20n, nnz(z>0))) and apply formula
    """
    zp = z[z > 0.0]
    s  = min(m, 20 * n, int((zp > 0).sum()))
    if s <= 0:
        return 5.0
    zz   = np.sort(zp, kind='mergesort')
    val  = zz[min(s - 1, zz.size - 1)]
    return max(5.0, max(val * val, 1.0) / (2.0 * tau))


def row_select(M, idx: np.ndarray):
    """Select several rows of M; compatible with sparse/dense."""
    if sp is not None and sp.issparse(M):
        return M[idx, :]
    else:
        return M[idx, :]


def my_cg(fx: Callable[[Array], Array], b: Array, cgtol: float, cgit: int, x0: Array) -> Array:
    x = x0.copy()
    r = b - (fx(x0) if np.count_nonzero(x0) else 0.0)
    if isinstance(r, (int, float)):
        r = b.copy()
    e = float(np.dot(r, r))
    t = e
    p = r.copy()
    for _ in range(int(cgit)):
        if e < cgtol * t:
            break
        w     = fx(p)
        denom = float(np.dot(p, w))
        if denom == 0.0:
            break
        a  = e / denom
        x  = x + a * p
        r  = r - a * w
        e0 = e
        e  = float(np.dot(r, r))
        if e0 == 0.0:
            break
        p  = r + (e / e0) * p
    return x