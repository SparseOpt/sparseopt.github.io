# Classify 4 points with 1 outlier
import numpy as np
import matplotlib.pyplot as plt
from SSVMpack import SSVMpack, accuracy

a           = 10.0
A           = np.array([[0.0, 0.0],[0.0, 1.0],[1.0, 0.0],[1.0, a],], dtype=float)
y           = np.array([-1, -1, 1, 1], dtype=float)

pars        = {'C': 1.0, 'disp': 1}
solver_list = ['NM01', 'NSSVM']
t           = 1
out         = SSVMpack(A, y, solver_list[t], pars)

pos         = np.array([[1.0, 0.0], [1.0, a]])
neg         = np.array([[0.0, 0.0], [0.0, 1.0]])

w           = out['w']
fig         = plt.figure(figsize=(3.5, 3.3))
mngr        = plt.get_current_fig_manager()
ax  = fig.add_axes([0.08, 0.08, 0.88, 0.88])
ax.scatter([1, 1], [0, a], s=80, marker='+', c='m', label='Positive')
ax.scatter([0, 0], [0, 1], s=80, marker='x', c='b', label='Negative')
ax.axis([-0.1, 1.1, -1, 1.1 * a])
ax.grid(True)
ld = f"{solver_list[t]}: {accuracy(A, w, y)[0] * 100.0:.0f}%"
ax.plot([-w[2]/w[0], -w[2]/w[0]], [-1, 1.1 * a], color='r', label=ld)
ax.legend(loc='upper left')
plt.show()
