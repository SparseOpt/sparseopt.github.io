# demon randomly generated data
import matplotlib.pyplot as plt
from SSVMpack import SSVMpack, accuracy
from SSVMpack.funcs.randomData import randomData
from SSVMpack.funcs.plot2D import plot2D

type_id = 1    # 1 -> '2D', 2 -> '3D', 3 -> 'nD'
Ex      = ['2D', '3D', 'nD']
m0      = int(4e2)
n0      = 100

Atrain, ytrain, Atest, ytest = randomData(Ex[type_id - 1], m0, n0, r=0)
m, n            = Atrain.shape
t               = 0
solver          = ['NM01', 'NSSVM']
pars            = {'C': 0.25}
out             = SSVMpack(Atrain, ytrain, solver=solver[t - 1], pars=pars)

acc_train, _, _ = accuracy(Atrain, out['w'], ytrain)
acc_test, _, _  = accuracy(Atest,  out['w'], ytest)

print(f" Training  Time:             {out['time']:.3f}sec")
print(f" Training  Size:             {m}x{n}")
print(f" Training  Accuracy:         {acc_train * 100:.2f}%")
print(f" Testing   Size:             {Atest.shape[0]}x{n}")
print(f" Testing   Accuracy:         {acc_test * 100:.2f}%")
print(f" Number of Support Vectors:  {out['sv']}")

if Ex[type_id - 1] == '2D' and m < 400:
    plot2D(Atrain, ytrain, out['w'], solver[t], acc_train, pos=[1000, 0, 400, 400])
    plt.xlabel('Training data')
    plot2D(Atest,  ytest,  out['w'], solver[t], acc_test, pos=[1800, 0, 400, 400])
    plt.xlabel('Testing data')
plt.show()