# demon real data
import numpy as np
from pathlib import Path
from scipy.io import loadmat
from SSVMpack import SSVMpack, accuracy, normalization

data_dir = Path(__file__).resolve().parent / 'SSVMpack' / 'data'
mat_A    = loadmat(data_dir / 'dhrb.mat')
mat_y    = loadmat(data_dir / 'dhrbclass.mat')

A        = None
y        = None
for k, v in mat_A.items():
    if k.lower() == 'a':
        A = v
        break
for k, v in mat_y.items():
    if k.lower() == 'y':
        y = v
        break

if A is None or y is None:
    raise ValueError('Cannot find variables A or y in the mat file. Please verify the variable names in the .mat file.')

y               = np.asarray(y, dtype=float).ravel()
A               = np.asarray(A, dtype=float)
m0, n           = A.shape
A               = normalization(A, 2)
m               = int(np.ceil(0.9 * m0))

rng             = np.random.default_rng()
idx             = rng.permutation(m0)
train_idx       = idx[:m]
test_idx        = idx[m:]

Atrain          = A[train_idx, :]
Atest           = A[test_idx, :]
ytrain          = y[train_idx]
ytest           = y[test_idx]

solver_list     = ['NM01', 'NSSVM']
pars            = {'C': 0.25, 'disp': 1}
out             = SSVMpack(Atrain, ytrain,  solver_list[0], pars=pars)

acc_train, _, _ = accuracy(Atrain, out['w'], ytrain)
acc_test,  _, _ = accuracy(Atest,  out['w'], ytest)

print(f" Training  Time:             {out['time']:.3f}sec")
print(f" Training  Size:             {Atrain.shape[0]}x{Atrain.shape[1]}")
print(f" Training  Accuracy:         {acc_train * 100:.2f}%")
print(f" Testing   Size:             {Atest.shape[0]}x{Atest.shape[1]}")
print(f" Testing   Accuracy:         {acc_test * 100:.2f}%")
print(f" Number of Support Vectors:  {out['sv']}")