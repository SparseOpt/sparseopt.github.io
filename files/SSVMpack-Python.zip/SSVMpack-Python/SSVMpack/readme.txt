Please run "demonXXXX.py" to solve different problems

This package offers 2 solvers for sparse support vector machine problems 
based on the algorithms proposed in the following 2 papers: 

NM01---------------------------------------------------------------------------
   Shenglong Zhou, Lili Pan, Naihua Xiu and Huoduo Qi, 
   Quadratic convergence of smoothing Newton's method for 0/1 loss optimization
   SIAM Journal on Optimization, 31, 3184–3211, 2021.

NSSVM--------------------------------------------------------------------------
   Shenglong Zhou, 
   Sparse SVM for sufficient data reduction, 
   IEEE Trans Pattern Anal Mach Intell, 44, 5560-5571, 2022.

Please credit them if you use the code for your research.

==============================================================================
def SSVMpack(A, y, solver: str, pars: Optional[Dict] = None) -> Dict:
# ----------------------------------------------------------------------------
# This package aims to solve the binary classification problems
# Inputs:
#  A      : The sample matrix \in R^{m-by-n},                       (REQUIRED)
#  y      : The binary label \in R^m, b_i\in{-1,1}                  (REQUIRED)
#  solver : A text string, can be one of {'NM01','NSSVM'}           (REQUIRED)
#  pars   : Parameters are optional                                 (OPTIONAL)
#           -------------  For NSSVM -----------------------------------------
#           pars['alpha'] --  Starting point in \R^m      (default zeros(m,1))
#           pars['s0']    --  The initial sparsity    (default n(log(m/n))^2))
#           pars['C']     --  A positive scalar in (0,1]        (default  1/4)
#           pars['c']     --  A positive scalar in (0,1]        (default 1/40)
#           pars['tune']  --  Tune the sparsity level
#                             Do not tune the sparsity level       (default 0)
#           pars['maxit'] --  Maximum number of iterations      (default 1000)
#           pars['tol']   --  Tolerance of the halting criteria (default 1e-4)
#           pars['disp']  --  Display results for each step        (default 1)
#                             Do not display results for each step
#           -------------  For NM01 ------------------------------------------
#           pars['x0']    --  The initial point           (default zeros(n,1))
#           pars['C']     --  The penalty parameter                (default 1)
#           pars['tau']   --  A useful parameter                   (default 5)
#           pars['maxit'] --  Maximum number of iterations      (default 1000)
#           pars['tol']   --  Tolerance of the halting criteria (default 1e-4)
#           pars['disp']  --  Display results for each step        (default 1)
#                             Do not display results for each step
# ----------------------------------------------------------------------------
# Outputs:
#     out['w']   :   The solution of the primal problem, i.e., the classifier
#     out['sv']  :   Number of support vectors
#     out['time']:   CPU time
#     out['iter']:   Number of iterations
#     out['acc'] :   Classification accuracy
# ----------------------------------------------------------------------------
# Send your comments and suggestions to <slzhou2021@163.com>
# Warning: Accuracy may not be guaranteed !!!!!!
# ----------------------------------------------------------------------------

# Below is one example that you can run
# ============================================================================
# Classify 4 points with 1 outlier
import numpy as np
import matplotlib.pyplot as plt
from SSVMpack import SSVMpack, accuracy

a           = 10.0
A           = np.array([[0.0, 0.0],[0.0, 1.0],[1.0, 0.0],[1.0, a],], dtype=float)
y           = np.array([-1, -1, 1, 1], dtype=float)

pars        = {'C': 1.0, 'disp': 1}
solver_list = ['NM01', 'NSSVM']
t           = 1
out         = SSVMpack(A, y, solver_list[t], pars)

pos         = np.array([[1.0, 0.0], [1.0, a]])
neg         = np.array([[0.0, 0.0], [0.0, 1.0]])

w           = out['w']
fig         = plt.figure(figsize=(3.5, 3.3))
mngr        = plt.get_current_fig_manager()
ax  = fig.add_axes([0.08, 0.08, 0.88, 0.88])
ax.scatter([1, 1], [0, a], s=80, marker='+', c='m', label='Positive')
ax.scatter([0, 0], [0, 1], s=80, marker='x', c='b', label='Negative')
ax.axis([-0.1, 1.1, -1, 1.1 * a])
ax.grid(True)
ld = f"{solver_list[t]}: {accuracy(A, w, y)[0] * 100.0:.0f}%"
ax.plot([-w[2]/w[0], -w[2]/w[0]], [-1, 1.1 * a], color='r', label=ld)
ax.legend(loc='upper left')
plt.show()